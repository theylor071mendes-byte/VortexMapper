@echo off
where gradle >nul 2>&1
if %errorlevel% neq 0 (
  echo Gradle 8.9 nao encontrado. Instale o Gradle ou use o GitHub Actions.
  exit /b 1
)
gradle :app:assembleDebug
if %errorlevel% neq 0 exit /b %errorlevel%
echo APK: app\build\outputs\apk\debug\app-debug.apk
