package com.vortex.mapper;

import org.json.JSONException;
import org.json.JSONObject;

/** Posição relativa à tela (x/y de 0 a 1). */
public final class Mapping {
    public static final int MOUSE_LEFT = -10;
    public static final int MOUSE_RIGHT = -11;
    public static final int JOYSTICK = -100;
    public static final int AIM = -101;

    public int code;
    public String label;
    public float x, y;
    public boolean hold;

    public Mapping(int code, String label, float x, float y, boolean hold) {
        this.code = code;
        this.label = label;
        this.x = x;
        this.y = y;
        this.hold = hold;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("code", code); o.put("label", label);
        o.put("x", x); o.put("y", y); o.put("hold", hold);
        return o;
    }

    public static Mapping fromJson(JSONObject o) {
        return new Mapping(o.optInt("code"), o.optString("label", "?"),
                (float)o.optDouble("x", 0.5), (float)o.optDouble("y", 0.5), o.optBoolean("hold"));
    }

    public boolean isJoystick() { return code == JOYSTICK; }
    public boolean isAim() { return code == AIM; }
}
