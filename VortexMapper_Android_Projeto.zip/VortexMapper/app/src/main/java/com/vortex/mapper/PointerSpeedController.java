package com.vortex.mapper;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;

/** Opcional: ajusta a velocidade do ponteiro do sistema somente durante o jogo.
 *  Efeitos dependem do fabricante do Android; sem permissao nao altera nada.
 */
public final class PointerSpeedController {
    private static final String SPEED_KEY="pointer_speed";
    private static final String SAVED="original_pointer_speed_v3";
    private static final String ACTIVE="pointer_modified_v3";
    private PointerSpeedController() {}

    public static boolean allowed(Context c) {
        return Build.VERSION.SDK_INT>=23 && Settings.System.canWrite(c);
    }
    public static boolean applyForGame(Context c) {
        if(!Store.autoSystemPointer(c) || !allowed(c))return false;
        try {
            SharedPreferences pref=Store.prefs(c);
            if(!pref.getBoolean(ACTIVE,false)) {
                int original=Settings.System.getInt(c.getContentResolver(),SPEED_KEY,0);
                pref.edit().putInt(SAVED,original).putBoolean(ACTIVE,true).commit();
            }
            boolean ok=Settings.System.putInt(c.getContentResolver(),SPEED_KEY,Store.systemPointerSpeed(c));
            if(!ok)restore(c);
            return ok;
        } catch (SecurityException ex) { restore(c);return false; }
    }
    public static void restore(Context c) {
        SharedPreferences pref=Store.prefs(c);
        if(!pref.getBoolean(ACTIVE,false))return;
        if(!allowed(c))return; // Tenta novamente na proxima abertura, caso acesso tenha sido revogado.
        try {
            if(Settings.System.putInt(c.getContentResolver(),SPEED_KEY,pref.getInt(SAVED,0))) {
                pref.edit().remove(ACTIVE).remove(SAVED).commit();
            }
        } catch(SecurityException ignored) { }
    }
}
