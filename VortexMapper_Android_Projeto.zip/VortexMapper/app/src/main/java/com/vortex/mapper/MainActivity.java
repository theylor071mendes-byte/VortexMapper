package com.vortex.mapper;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.InputDevice;
import android.hardware.input.InputManager;
import android.os.Handler;
import android.os.Looper;
import android.content.res.Configuration;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.content.res.ColorStateList;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int BG=0xFFE1E3FF, PANEL=0xFFF4F4FF, MUTED=0xFF616A98,
            WHITE=0xFF20264F, MINT=0xFF505EF2, BLUE=0xFF7C84FA, BORDER=0xFFCACDF3;
    private static final int ON_PURPLE=0xFFFFFFFF, PURPLE_DARK=0xFF3E49AA;
    private LinearLayout body, headerBadgeRow;
    private TextView mouseStatus, keyboardStatus;
    private int selectedGame=0, activeTab=0;
    private boolean landscape=false;
    private InputManager inputManager;
    private boolean inputListenerRegistered=false;
    private final InputManager.InputDeviceListener inputListener=new InputManager.InputDeviceListener(){
        @Override public void onInputDeviceAdded(int deviceId){updateConnections();}
        @Override public void onInputDeviceRemoved(int deviceId){updateConnections();}
        @Override public void onInputDeviceChanged(int deviceId){updateConnections();}
    };
    private LinearLayout screen, gamesList;
    private ScrollView mainScroll;
    private View gamesAnchor, mouseAnchor, helpAnchor;
    private TextView accessStatus, countText;
    private final List<AppEntry> launchable = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        // Recupera eventual configuracao temporaria apos encerramento inesperado.
        PointerSpeedController.restore(this);
        createScreen();
    }
    @Override protected void onResume() {
        super.onResume();
        if(body!=null)refresh();
        inputManager=(InputManager)getSystemService(INPUT_SERVICE);
        if(inputManager!=null && !inputListenerRegistered){
            inputManager.registerInputDeviceListener(inputListener,new Handler(Looper.getMainLooper()));
            inputListenerRegistered=true;
        }
    }
    @Override protected void onPause() {
        if(inputListenerRegistered && inputManager!=null)inputManager.unregisterInputDeviceListener(inputListener);
        inputListenerRegistered=false;
        super.onPause();
    }
    @Override public void onBackPressed() {
        if(activeTab!=0){activeTab=0;renderPage();}
        else super.onBackPressed();
    }

    private int dp(float n) { return (int)(n*getResources().getDisplayMetrics().density+.5f); }
    private GradientDrawable background(int color, float radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private GradientDrawable gradient() {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF233C63,0xFF142D46,0xFF112B2D});
        d.setCornerRadius(dp(26)); d.setStroke(dp(1),0xFF416578); return d;
    }
    private TextView text(String t, int size, int color, boolean bold) {
        TextView v=new TextView(this); v.setText(t); v.setTextColor(color);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP,size);
        if(bold) v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v;
    }
    private LinearLayout vertical() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
    private void gap(LinearLayout l,int size){View spacer=new View(this);l.addView(spacer,lp(1,size));}
    private TextView button(String title, boolean primary, View.OnClickListener action) {
        TextView b=text(title,13,primary?BG:WHITE,true);b.setGravity(Gravity.CENTER);
        b.setBackground(background(primary?MINT:0xFF24384A,12,primary?0:0xFF355063));
        pad(b,14,12,14,12);b.setOnClickListener(action);return b;
    }
    private GradientDrawable violetGradient(int radius) {
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF7783FA,0xFF5F6FE8,0xFF3E48B0});
        d.setCornerRadius(dp(radius));return d;
    }
    private TextView purpleButton(String label, boolean filled, View.OnClickListener action) {
        TextView b=text(label,14,filled?ON_PURPLE:PURPLE_DARK,true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(filled?violetGradient(12):background(0xFFF5F6FF,12,0xFF9DA6EE));
        pad(b,15,12,15,12); b.setOnClickListener(action);return b;
    }
    private void createScreen() {
        landscape=getResources().getConfiguration().orientation==Configuration.ORIENTATION_LANDSCAPE;
        getWindow().setStatusBarColor(0xFFDFE1FA);
        getWindow().setNavigationBarColor(0xFF4654BE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        LinearLayout root=vertical();root.setBackgroundColor(BG);
        setContentView(root);
        LinearLayout top=horizontal();pad(top,landscape?24:15,14,landscape?24:15,12);
        top.setBackgroundColor(0xFFEBECFF);
        TextView heading=text("JOGOS",landscape?26:23,0xFF181D45,true);
        heading.setTypeface(Typeface.create("sans-serif-black",Typeface.BOLD));
        top.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
        TextView mark=text("VORTEX  /  PRO 4.0",landscape?12:10,PURPLE_DARK,true);
        mark.setGravity(Gravity.CENTER);pad(mark,10,9,10,9);
        mark.setBackground(background(0xFFD4D9FF,12,0));top.addView(mark);
        root.addView(top);

        headerBadgeRow=horizontal();headerBadgeRow.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        pad(headerBadgeRow,landscape?24:12,8,landscape?24:12,8);
        mouseStatus=connectionChip("◉  MOUSE  —",false);
        keyboardStatus=connectionChip("⌨  TECLADO  —",false);
        headerBadgeRow.addView(mouseStatus);
        LinearLayout.LayoutParams kp=lp(-2,-2);kp.leftMargin=dp(8);
        headerBadgeRow.addView(keyboardStatus,kp);
        root.addView(headerBadgeRow);

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);mainScroll=scroll;
        body=vertical();pad(body,landscape?22:13,landscape?7:14,landscape?22:13,15);
        scroll.addView(body);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout footer=horizontal();footer.setBackground(violetGradient(0));
        String[] names={"♧  INICIAR JOGO","♙  CONTA","✧  LOTERIA","⚙  CONFIGURAÇÕES"};
        for(int i=0;i<names.length;i++){
            final int tab=i;
            TextView item=text(names[i],landscape?15:10,ON_PURPLE,i==0);
            item.setGravity(Gravity.CENTER);pad(item,1,8,1,8);
            item.setOnClickListener(v->{activeTab=tab;renderPage();});
            if(i>0){View line=new View(this);line.setBackgroundColor(0x445D6AB9);footer.addView(line,lp(1,43));}
            footer.addView(item,new LinearLayout.LayoutParams(0,dp(landscape?57:62),1));
        }
        root.addView(footer);
        renderPage();updateConnections();
    }
    private TextView connectionChip(String value,boolean connected) {
        TextView chip=text(value,landscape?13:11,ON_PURPLE,true);
        chip.setBackground(background(connected?0xFF45A987:0xFF7785E7,24,0xFFABB4FF));
        pad(chip,landscape?13:9,7,landscape?13:9,7);return chip;
    }
    private void updateConnections() {
        if(mouseStatus==null||keyboardStatus==null)return;
        boolean mouse=false,keyboard=false;
        for(int id:InputDevice.getDeviceIds()){
            InputDevice dev=InputDevice.getDevice(id);
            if(dev==null || dev.isVirtual())continue;
            if((dev.getSources() & InputDevice.SOURCE_MOUSE)==InputDevice.SOURCE_MOUSE)mouse=true;
            if((dev.getSources() & InputDevice.SOURCE_KEYBOARD)==InputDevice.SOURCE_KEYBOARD &&
                dev.getKeyboardType()!=InputDevice.KEYBOARD_TYPE_NONE)keyboard=true;
        }
        mouseStatus.setText("◉  "+(mouse?"MOUSE CONECTADO":"MOUSE DESCONECTADO"));
        keyboardStatus.setText("⌨  "+(keyboard?"TECLADO CONECTADO":"TECLADO DESCONECTADO"));
        mouseStatus.setBackground(background(mouse?0xFF43AA90:0xFF7A83E5,24,0xFFB7BBFF));
        keyboardStatus.setBackground(background(keyboard?0xFF43AA90:0xFF7A83E5,24,0xFFB7BBFF));
    }
    private void renderPage() {
        if(body==null)return;
        body.removeAllViews();
        switch(activeTab){
            case 1:renderAccount();break;
            case 2:renderLottery();break;
            case 3:renderSettings();break;
            default:renderGames();break;
        }
        if(mainScroll!=null)mainScroll.post(()->mainScroll.scrollTo(0,0));
    }
    private void renderGames() {
        LinearLayout tools=horizontal();
        TextView add=purpleButton("＋ ADICIONAR JOGO",true,v->showPicker());
        tools.addView(add);
        TextView hint=text("  BIBLIOTECA DE JOGOS",landscape?13:10,MUTED,true);
        hint.setGravity(Gravity.CENTER_VERTICAL);tools.addView(hint);
        body.addView(tools);gap(body,landscape?8:18);
        List<String> games=sortedGames();
        if(games.size()==0){
            LinearLayout empty=vertical();empty.setGravity(Gravity.CENTER);
            pad(empty,14,landscape?42:67,14,40);
            TextView logo=text("＋",54,PURPLE_DARK,true);logo.setGravity(Gravity.CENTER);
            logo.setBackground(violetGradient(26));logo.setTextColor(ON_PURPLE);
            empty.addView(logo,lp(105,105));gap(empty,18);
            TextView name=text("Adicione seu primeiro jogo",20,WHITE,true);
            name.setGravity(Gravity.CENTER);empty.addView(name);gap(empty,10);
            TextView note=text("Selecione um aplicativo instalado para criar seu keymap de teclado e mouse.",13,MUTED,false);
            note.setGravity(Gravity.CENTER);empty.addView(note);gap(empty,22);
            empty.addView(purpleButton("＋  ADICIONAR AGORA",true,v->showPicker()));body.addView(empty);return;
        }
        if(selectedGame>=games.size())selectedGame=0;
        final String pkg=games.get(selectedGame);
        LinearLayout stage=horizontal();stage.setGravity(Gravity.CENTER);
        if(games.size()>1)stage.addView(carouselArrow("‹",()->{selectedGame=(selectedGame+games.size()-1)%games.size();renderPage();}));
        LinearLayout content=vertical();content.setGravity(Gravity.CENTER);
        int cardWidth=landscape?dp(240):dp(242);
        int cardHeight=landscape?dp(280):dp(285);
        FrameLayout gameCard=new FrameLayout(this);
        gameCard.setBackground(violetGradient(20));gameCard.setElevation(dp(7));
        View accent=new View(this);accent.setBackgroundColor(0x185B65D0);
        FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(-1,dp(9),Gravity.TOP);
        gameCard.addView(accent,ap);
        LinearLayout inner=vertical();inner.setGravity(Gravity.CENTER_HORIZONTAL);
        pad(inner,14,26,14,15);
        ImageView icon=new ImageView(this);
        try {icon.setImageDrawable(getPackageManager().getApplicationIcon(pkg));}
        catch(Exception ignored){icon.setImageResource(android.R.drawable.sym_def_app_icon);}
        inner.addView(icon,lp(landscape?140:145,landscape?140:145));gap(inner,14);
        TextView name=text(label(pkg),landscape?24:23,ON_PURPLE,true);
        name.setGravity(Gravity.CENTER);name.setMaxLines(2);
        inner.addView(name);gap(inner,6);
        TextView note=text("KEYMAP PERSONALIZADO",10,0xFFE1E6FF,true);
        note.setGravity(Gravity.CENTER);inner.addView(note);
        FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,-1);gameCard.addView(inner,ip);
        content.addView(gameCard,new LinearLayout.LayoutParams(cardWidth,cardHeight));
        gap(content,landscape?12:18);
        TextView launch=purpleButton("▶  INICIAR JOGO",true,v->launchGame(pkg,false));
        content.addView(launch,lp(landscape?220:242,51));gap(content,9);
        TextView edit=purpleButton("✎  EDITAR KEYMAP",false,v->launchGame(pkg,true));
        content.addView(edit,lp(landscape?220:242,46));
        stage.addView(content);
        if(games.size()>1)stage.addView(carouselArrow("›",()->{selectedGame=(selectedGame+1)%games.size();renderPage();}));
        body.addView(stage);gap(body,15);
        TextView count=text((selectedGame+1)+" / "+games.size()+"  •  "+Store.load(this,pkg).size()+" CONTROLES SALVOS",11,MUTED,true);
        count.setGravity(Gravity.CENTER);body.addView(count);gap(body,13);
        TextView remove=text("REMOVER JOGO",11,PURPLE_DARK,true);remove.setGravity(Gravity.CENTER);
        pad(remove,9,7,9,7);
        remove.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle("Remover "+label(pkg)+"?")
                .setMessage("Isso também apaga o keymap salvo para este jogo.")
                .setPositiveButton("REMOVER",(d,w)->{Store.removeGame(this,pkg);selectedGame=0;renderPage();})
                .setNegativeButton("CANCELAR",null).show());
        body.addView(remove);
    }
    private TextView carouselArrow(String label,Runnable action) {
        TextView arrow=text(label,35,PURPLE_DARK,true);arrow.setGravity(Gravity.CENTER);
        arrow.setOnClickListener(v->action.run());return arrow;
    }
    private List<String> sortedGames() {
        List<String> l=new ArrayList<>(Store.games(this));
        Collections.sort(l,(a,b)->label(a).compareToIgnoreCase(label(b)));return l;
    }
    private LinearLayout sectionCard(String title,String sub) {
        LinearLayout c=vertical();pad(c,17,18,17,18);
        c.setBackground(background(0xFFF7F7FF,18,0xFFC3C8EF));
        c.addView(text(title,18,WHITE,true));gap(c,7);
        c.addView(text(sub,12,MUTED,false));gap(c,14);return c;
    }
    private void renderAccount() {
        LinearLayout card=sectionCard("♙  Meu perfil local", "Os seus keymaps ficam salvos somente neste dispositivo. Não existe login ou conta online nesta versão.");
        card.addView(text("JOGOS CADASTRADOS: "+Store.games(this).size(),15,PURPLE_DARK,true));gap(card,14);
        card.addView(purpleButton("ABRIR MEUS JOGOS",true,v->{activeTab=0;renderPage();}));
        body.addView(card);gap(body,12);
        LinearLayout safety=sectionCard("Privacidade", "O Vortex não solicita sua senha do jogo e não conecta às suas contas. Acessibilidade só deve ser ativada se você confiar no código.");
        body.addView(safety);
    }
    private void renderLottery() {
        LinearLayout card=sectionCard("✧  Loteria", "Esta função aparece na referência visual, mas não possui sorteios, prêmios ou pagamentos nesta versão. Não há uma loteria ativa.");
        card.addView(purpleButton("VOLTAR AOS JOGOS",true,v->{activeTab=0;renderPage();}));body.addView(card);
    }
    private void renderSettings() {
        LinearLayout access=sectionCard("⚙  Central de configurações", "Permissões, controle de mouse e ajustes gerais do Vortex.");
        accessStatus=text(enabled()?"●  ACESSIBILIDADE ATIVA":"○  ACESSIBILIDADE DESLIGADA",14,enabled()?0xFF1C917A:0xFFAF623C,true);
        access.addView(accessStatus);gap(access,12);
        access.addView(purpleButton("ABRIR ACESSIBILIDADE  ↗",true,v->openAccessibility()));
        body.addView(access);gap(body,14);
        LinearLayout mouseBox=sectionCard("◉  Mouse e câmera", "O controle do mouse é experimental e depende da versão do Android, do jogo e de permissões autorizadas por você.");
        CheckBox check=new CheckBox(this);
        check.setText("Habilitar captura experimental do mouse");check.setTextSize(13);
        check.setTextColor(WHITE);check.setButtonTintList(ColorStateList.valueOf(MINT));
        check.setChecked(Store.mouseEnabled(this));check.setEnabled(Build.VERSION.SDK_INT>=34);
        check.setOnCheckedChangeListener((v,checked)->{
            Store.setMouseEnabled(this,checked);
            if(MapperService.current!=null)MapperService.current.syncMouseMode();
        });mouseBox.addView(check);gap(mouseBox,10);
        addSlider(mouseBox,"VELOCIDADE DO MOUSE","Movimento da câmera com mouse",.25f,3f,
                Store.mouseSpeed(this),"x",v->Store.setMouseSpeed(this,v));gap(mouseBox,13);
        addSlider(mouseBox,"SUAVIZAÇÃO","Menor valor = resposta mais imediata",0f,.8f,
                Store.smoothing(this),"%",v->Store.setSmoothing(this,v));gap(mouseBox,11);
        LinearLayout pointer=vertical();pad(pointer,13,14,13,13);
        pointer.setBackground(background(0xFFE8EBFF,12,0xFFC1C8F3));
        pointer.addView(text("↖  VELOCIDADE DA SETA DO ANDROID",12,PURPLE_DARK,true));gap(pointer,5);
        pointer.addView(text("Com sua autorização, o Vortex tenta ajustar a velocidade ao entrar no jogo e restaurá-la ao sair.",12,MUTED,false));gap(pointer,9);
        CheckBox auto=new CheckBox(this);auto.setText("Alterar seta automaticamente ao entrar no jogo");
        auto.setTextColor(WHITE);auto.setTextSize(12);auto.setButtonTintList(ColorStateList.valueOf(MINT));
        auto.setChecked(Store.autoSystemPointer(this));
        auto.setOnCheckedChangeListener((button,enabled)->{
            if(enabled && !PointerSpeedController.allowed(this)){
                auto.setChecked(false);
                new AlertDialog.Builder(this).setTitle("Permissão opcional")
                        .setMessage("Para alterar a velocidade da seta, autorize 'Modificar configurações do sistema'. Pode afetar outros aplicativos enquanto o jogo estiver aberto.")
                        .setPositiveButton("ABRIR",(dialog,which)->startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:"+getPackageName()))))
                        .setNegativeButton("CANCELAR",null).show();return;
            }
            Store.setAutoSystemPointer(this,enabled);
            if(MapperService.current!=null)MapperService.current.onPointerConfigChanged();
            if(!enabled)PointerSpeedController.restore(this);
        });pointer.addView(auto);gap(pointer,7);
        addSlider(pointer,"VELOCIDADE DA SETA","-7 lenta   •   0 normal   •   +7 rápida",-7f,7f,
                Store.systemPointerSpeed(this),"nível",v->{
                    Store.setSystemPointerSpeed(this,Math.round(v));
                    if(MapperService.current!=null)MapperService.current.onPointerConfigChanged();
                });
        pointer.addView(purpleButton("PERMISSÃO DA SETA  ↗",false,v->
                startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:"+getPackageName())))));
        mouseBox.addView(pointer);gap(mouseBox,13);
        mouseBox.addView(text("No jogo: abra o menu flutuante → CÂMERA X/Y para configurar a sensibilidade do keymap selecionado.",12,MUTED,false));
        body.addView(mouseBox);gap(body,14);
        LinearLayout help=sectionCard("Como usar", "1. Adicione um jogo. 2. Habilite acessibilidade conscientemente. 3. Abra o jogo pelo Vortex. 4. Toque no botão V para mostrar o menu flutuante. 5. Abra Editar keymap e configure as teclas.");
        body.addView(help);
    }

    private void scrollToSection(View target) {
        if(target==null || mainScroll==null)return;
        mainScroll.post(()->mainScroll.smoothScrollTo(0,Math.max(0,target.getTop()-dp(10))));
    }
    private TextView navTab(String title, boolean highlighted, Runnable action) {
        TextView tab=text(title,11,highlighted?MINT:0xFFCAD6E7,true);
        tab.setGravity(Gravity.CENTER);
        tab.setBackground(background(highlighted?0xFF163530:0xFF142032,12,highlighted?0xFF317565:BORDER));
        tab.setOnClickListener(v->action.run());return tab;
    }
    private LinearLayout miniStat(String symbol,String title) {
        LinearLayout card=vertical();pad(card,7,12,7,10);
        card.setBackground(background(0x60253755,12,0xFF45697B));
        TextView icon=text(symbol,20,MINT,true);icon.setGravity(Gravity.CENTER);
        card.addView(icon);
        TextView label=text(title,9,0xFFE8F5FF,true);label.setGravity(Gravity.CENTER);
        card.addView(label);return card;
    }
    private interface SaveFloat {void save(float f);}
    private void addSlider(LinearLayout parent, String title,String desc,float min,float max,
                           float initial,String unit,SaveFloat callback) {
        LinearLayout titleRow=horizontal();
        LinearLayout texts=vertical();texts.addView(text(title,12,WHITE,true));gap(texts,3);
        texts.addView(text(desc,11,MUTED,false));
        titleRow.addView(texts,new LinearLayout.LayoutParams(0,-2,1));
        TextView val=text("",15,MINT,true);titleRow.addView(val);
        parent.addView(titleRow);
        SeekBar bar=new SeekBar(this);bar.setMax(100);
        bar.setProgressTintList(ColorStateList.valueOf(MINT));
        bar.setThumbTintList(ColorStateList.valueOf(MINT));
        bar.setProgress(Math.round(100f*(initial-min)/(max-min)));
        java.util.function.Consumer<Float> update=value->{
            val.setText(unit.equals("%")?String.format(Locale.US,"%.0f%%",value*100f):
                    unit.equals("nível")?String.format(Locale.US,"%+d",Math.round(value)):
                    String.format(Locale.US,"%.2fx",value));
        };
        update.accept(initial);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar b,int progress,boolean fromUser){
                if(!fromUser)return;
                float value=min+(max-min)*progress/100f;callback.save(value);update.accept(value);
            }
            @Override public void onStartTrackingTouch(SeekBar b){}
            @Override public void onStopTrackingTouch(SeekBar b){}
        });
        LinearLayout.LayoutParams p=lp(-1,39);p.topMargin=dp(3);parent.addView(bar,p);
    }

    private boolean enabled() {
        String value=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if(value==null)return false;
        ComponentName name=new ComponentName(this,MapperService.class);
        return value.contains(name.flattenToString()) || value.contains(name.flattenToShortString());
    }
    private void refresh() {updateConnections();renderPage();}

    private String label(String pkg) {
        try { return getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg,0)).toString(); }
        catch(Exception ex) {return pkg;}
    }
    private void openAccessibility() {
        try {startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}
        catch(Exception e){new AlertDialog.Builder(this).setMessage("Abra Configurações > Acessibilidade > Vortex Mapper.").setPositiveButton("OK",null).show();}
    }
    private void launchGame(String pkg,boolean edit) {
        if(!enabled()) {
            new AlertDialog.Builder(this).setTitle("Permissão necessária")
                    .setMessage("Ative o serviço Vortex Mapper em Configurações > Acessibilidade para mostrar os controles no jogo.")
                    .setPositiveButton("ATIVAR",(d,w)->openAccessibility()).setNegativeButton("CANCELAR",null).show();return;
        }
        Intent game=getPackageManager().getLaunchIntentForPackage(pkg);
        if(game==null) {new AlertDialog.Builder(this).setMessage("Não foi possível abrir este aplicativo. Talvez tenha sido desinstalado.").setPositiveButton("OK",null).show();return;}
        if(edit)Store.requestEdit(this,pkg);
        game.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try{startActivity(game);}catch(Exception e){new AlertDialog.Builder(this).setMessage("Falha ao abrir o jogo: "+e.getMessage()).setPositiveButton("OK",null).show();}
    }
    private static class AppEntry {String pkg,name;Drawable icon;AppEntry(String p,String n,Drawable i){pkg=p;name=n;icon=i;}}
    private void loadLaunchables() {
        launchable.clear();
        PackageManager pm=getPackageManager();
        Intent intent=new Intent(Intent.ACTION_MAIN);intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> matches=pm.queryIntentActivities(intent,0);
        Set<String> seen=new java.util.HashSet<>();
        for(ResolveInfo info:matches) {
            if(info.activityInfo==null)continue;
            String pkg=info.activityInfo.packageName;
            if(pkg.equals(getPackageName())||!seen.add(pkg))continue;
            launchable.add(new AppEntry(pkg,info.loadLabel(pm).toString(),info.loadIcon(pm)));
        }
        Collections.sort(launchable,Comparator.comparing(a->a.name.toLowerCase(Locale.ROOT)));
    }
    private void showPicker() {
        loadLaunchables();
        LinearLayout box=vertical();pad(box,15,10,15,0);
        EditText search=new EditText(this);search.setSingleLine(true);search.setHint("Pesquisar jogo ou aplicativo...");
        search.setTextSize(14);search.setCompoundDrawablePadding(dp(9));box.addView(search);
        ScrollView sv=new ScrollView(this);LinearLayout results=vertical();sv.addView(results);
        box.addView(sv,lp(-1,landscape?185:380));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Adicionar jogo")
                .setView(box).setNegativeButton("FECHAR",null).create();
        Runnable redraw=()->{
            results.removeAllViews();String q=search.getText().toString().trim().toLowerCase(Locale.ROOT);
            int added=0;
            for(AppEntry item:launchable) {
                if(!item.name.toLowerCase(Locale.ROOT).contains(q)&&!item.pkg.toLowerCase(Locale.ROOT).contains(q))continue;
                if(added++>=140)break;
                LinearLayout row=horizontal();pad(row,6,10,6,10);
                ImageView iv=new ImageView(this);iv.setImageDrawable(item.icon);row.addView(iv,lp(32,32));
                LinearLayout txt=vertical();pad(txt,13,0,0,0);
                txt.addView(text(item.name,14,WHITE,true));
                TextView sub=text(item.pkg,10,0xFF5C6875,false);txt.addView(sub);
                row.addView(txt);
                row.setOnClickListener(v->{Store.addGame(this,item.pkg);dialog.dismiss();refresh();});
                results.addView(row);View line=new View(this);line.setBackgroundColor(0xFFDAE1E5);results.addView(line,lp(-1,1));
            }
            if(added==0)results.addView(text("Nenhum aplicativo encontrado.",13,WHITE,false));
        };
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){redraw.run();}
            public void afterTextChanged(Editable e){} });
        redraw.run();dialog.show();
    }
}
