package com.vortex.mapper;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.content.res.ColorStateList;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int BG=0xFF070C16, PANEL=0xFF101B2B, MUTED=0xFF91A5BC,
            WHITE=0xFFF1F9FE, MINT=0xFF7EF5CF, BLUE=0xFF7DABFF, BORDER=0xFF26384C;
    private LinearLayout screen, gamesList;
    private ScrollView mainScroll;
    private View gamesAnchor, mouseAnchor, helpAnchor;
    private TextView accessStatus, countText;
    private final List<AppEntry> launchable = new ArrayList<>();

    @Override public void onCreate(Bundle b) { super.onCreate(b); createScreen(); }
    @Override protected void onResume() { super.onResume(); if (screen != null) refresh(); }

    private int dp(float n) { return (int)(n*getResources().getDisplayMetrics().density+.5f); }
    private GradientDrawable background(int color, float radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private GradientDrawable gradient() {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF233C63,0xFF142D46,0xFF112B2D});
        d.setCornerRadius(dp(26)); d.setStroke(dp(1),0xFF416578); return d;
    }
    private TextView text(String t, int size, int color, boolean bold) {
        TextView v=new TextView(this); v.setText(t); v.setTextColor(color);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP,size);
        if(bold) v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v;
    }
    private LinearLayout vertical() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
    private void gap(LinearLayout l,int size){View spacer=new View(this);l.addView(spacer,lp(1,size));}
    private TextView button(String title, boolean primary, View.OnClickListener action) {
        TextView b=text(title,13,primary?BG:WHITE,true);b.setGravity(Gravity.CENTER);
        b.setBackground(background(primary?MINT:0xFF24384A,12,primary?0:0xFF355063));
        pad(b,14,12,14,12);b.setOnClickListener(action);return b;
    }
    private void createScreen() {
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this);scroll.setClipToPadding(false);scroll.setFillViewport(true);
        mainScroll=scroll;
        screen=vertical();pad(screen,18,26,18,48);
        scroll.addView(screen); root.addView(scroll);setContentView(root);

        LinearLayout header=horizontal();
        TextView logo=text("V",29,BG,true);logo.setGravity(Gravity.CENTER);
        logo.setBackground(background(MINT,17,0));logo.setElevation(dp(5));header.addView(logo,lp(57,57));
        LinearLayout brand=vertical();pad(brand,12,0,0,0);
        brand.addView(text("VORTEX",22,WHITE,true));brand.addView(text("M  A  P  P  E  R",10,MINT,true));
        header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView beta=text("PRO  2.0",10,MINT,true);
        beta.setBackground(background(0xFF183931,20,0xFF2F6656));pad(beta,10,9,10,9);
        header.addView(beta);screen.addView(header);gap(screen,24);

        LinearLayout nav=horizontal();
        nav.addView(navTab("⌘  JOGOS",true,()->scrollToSection(gamesAnchor)),new LinearLayout.LayoutParams(0,dp(42),1));
        LinearLayout.LayoutParams navGap=new LinearLayout.LayoutParams(0,dp(42),1);navGap.leftMargin=dp(8);
        nav.addView(navTab("◎  MOUSE",false,()->scrollToSection(mouseAnchor)),navGap);
        LinearLayout.LayoutParams navGap2=new LinearLayout.LayoutParams(0,dp(42),1);navGap2.leftMargin=dp(8);
        nav.addView(navTab("?  AJUDA",false,()->scrollToSection(helpAnchor)),navGap2);
        screen.addView(nav);gap(screen,17);

        LinearLayout hero=vertical();pad(hero,22,22,22,23);hero.setBackground(gradient());
        TextView cap=text("●  CUSTOMIZAÇÃO AVANÇADA  /  ANDROID",10,MINT,true);hero.addView(cap);gap(hero,14);
        hero.addView(text("Sua mira.\nSeu controle.",31,WHITE,true));gap(hero,12);
        hero.addView(text("Mapeie cada tecla e ajuste câmera X/Y, velocidade do mouse e resposta vertical para cada jogo.",13,0xFFD4E1F2,false));
        gap(hero,19);
        LinearLayout showcase=horizontal();
        showcase.addView(miniStat("◎", "CÂMERA X/Y"),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,-2,1);sp.leftMargin=dp(6);
        showcase.addView(miniStat("↗", "PUXADA"),sp);
        LinearLayout.LayoutParams sp2=new LinearLayout.LayoutParams(0,-2,1);sp2.leftMargin=dp(6);
        showcase.addView(miniStat("⌨", "WASD + MOUSE"),sp2);
        hero.addView(showcase);gap(hero,18);
        LinearLayout metrics=horizontal();
        countText=text("0 JOGOS",11,MINT,true);metrics.addView(countText);
        TextView sep=text("   /   ",12,MUTED,false);metrics.addView(sep);
        metrics.addView(text("PERFIS SALVOS",11,0xFFBED0DF,true));hero.addView(metrics);
        screen.addView(hero);gap(screen,25);

        screen.addView(text("01  /  SERVIÇO DE CONTROLE",12,MINT,true));gap(screen,10);
        LinearLayout permission=vertical();pad(permission,17,17,17,17);permission.setBackground(background(PANEL,18,BORDER));
        accessStatus=text("Verificando...",16,WHITE,true);permission.addView(accessStatus);
        gap(permission,7);
        permission.addView(text("Acessibilidade mostra o HUD sobre jogos selecionados e permite os gestos do teclado. Você controla quando usar.",12,MUTED,false));
        gap(permission,14);
        permission.addView(button("Abrir configurações de acessibilidade  ↗",true,v->openAccessibility()));
        screen.addView(permission);gap(screen,25);

        gamesAnchor=new View(this);screen.addView(gamesAnchor,lp(1,1));
        LinearLayout section=horizontal();LinearLayout sectionNames=vertical();
        sectionNames.addView(text("02  /  BIBLIOTECA",12,MINT,true));gap(sectionNames,5);
        sectionNames.addView(text("Meus jogos",20,WHITE,true));
        section.addView(sectionNames,new LinearLayout.LayoutParams(0,-2,1));
        section.addView(button("+ ADICIONAR",true,v->showPicker()));screen.addView(section);
        gap(screen,13);
        gamesList=vertical();screen.addView(gamesList);gap(screen,25);

        mouseAnchor=new View(this);screen.addView(mouseAnchor,lp(1,1));
        screen.addView(text("03  /  CENTRAL DO MOUSE",12,MINT,true));gap(screen,10);
        LinearLayout mouseBox=vertical();pad(mouseBox,18,18,18,19);mouseBox.setBackground(background(PANEL,21,BORDER));
        LinearLayout mouseHead=horizontal();
        TextView mouseIcon=text("◎",25,MINT,true);mouseIcon.setGravity(Gravity.CENTER);
        mouseIcon.setBackground(background(0xFF193B3D,14,0xFF316C67));
        mouseHead.addView(mouseIcon,lp(49,49));
        LinearLayout mouseTitle=vertical();pad(mouseTitle,12,0,0,0);
        mouseTitle.addView(text("Mouse & Câmera",19,WHITE,true));gap(mouseTitle,4);
        mouseTitle.addView(text("Ajustes rápidos de resposta",12,MUTED,false));
        mouseHead.addView(mouseTitle,new LinearLayout.LayoutParams(0,-2,1));mouseBox.addView(mouseHead);gap(mouseBox,14);
        CheckBox check=new CheckBox(this);check.setText("Permitir captura experimental de mouse");check.setTextSize(13);
        check.setTextColor(WHITE);check.setButtonTintList(ColorStateList.valueOf(MINT));
        check.setChecked(Store.mouseEnabled(this));check.setEnabled(Build.VERSION.SDK_INT>=34);
        check.setOnCheckedChangeListener((v,checked)->{
            Store.setMouseEnabled(this,checked);
            if(MapperService.current!=null)MapperService.current.syncMouseMode();
        });mouseBox.addView(check);gap(mouseBox,5);
        mouseBox.addView(text("A captura começa desligada em cada jogo. Toque em ◎ MOUSE LIVRE no HUD ou pressione F8 para ligar/desligar.",12,0xFFAFCADE,false));
        gap(mouseBox,18);
        addSlider(mouseBox,"VELOCIDADE GERAL","Multiplicador usado nos gestos do Vortex",.25f,3f,
                  Store.mouseSpeed(this),"x",v->Store.setMouseSpeed(this,v));
        gap(mouseBox,12);
        addSlider(mouseBox,"SUAVIZAÇÃO","Menor valor = resposta mais imediata",0f,.8f,
                  Store.smoothing(this),"%",v->Store.setSmoothing(this,v));
        gap(mouseBox,14);
        LinearLayout cameraTip=vertical();pad(cameraTip,13,12,13,12);
        cameraTip.setBackground(background(0xFF152A3C,13,0xFF2A5065));
        cameraTip.addView(text("◎  AJUSTES POR JOGO",12,MINT,true));gap(cameraTip,6);
        cameraTip.addView(text("No jogo: EDITAR → toque em CÂMERA → ajuste X (horizontal), Y (vertical) e PUXADA PARA CIMA.",12,0xFFC0D5E4,false));
        mouseBox.addView(cameraTip);gap(mouseBox,11);
        mouseBox.addView(text(Build.VERSION.SDK_INT>=34
                ? "Android 14+. Os gestos dependem do jogo e do aparelho; isto não prende ou oculta o cursor do sistema."
                : "Este Android não oferece a captura de mouse necessária (requer Android 14+). Você ainda pode configurar os perfis do teclado.",
                11,MUTED,false));
        screen.addView(mouseBox);gap(screen,26);

        helpAnchor=new View(this);screen.addView(helpAnchor,lp(1,1));
        screen.addView(text("04  /  COMO COMEÇAR",12,MINT,true));gap(screen,8);
        LinearLayout help=vertical();pad(help,17,15,17,15);help.setBackground(background(PANEL,18,BORDER));
        help.addView(text("1. Ative a acessibilidade Vortex Mapper.",13,WHITE,false));gap(help,10);
        help.addView(text("2. Adicione um jogo e toque em JOGAR ou EDITAR.",13,WHITE,false));gap(help,10);
        help.addView(text("3. Dentro do jogo, toque na bolha V. Adicione controles e arraste os círculos.",13,WHITE,false));gap(help,10);
        help.addView(text("4. Toque no círculo CÂMERA para X, Y e puxada vertical. Salve.",13,WHITE,false));gap(help,10);
        help.addView(text("5. Conecte teclado e mouse por OTG/Bluetooth. F8 alterna o modo câmera.",13,WHITE,false));
        screen.addView(help);gap(screen,18);
        TextView footer=text("VORTEX MAPPER  2.0  •  PROTÓTIPO ANDROID",10,0xFF668095,true);
        footer.setGravity(Gravity.CENTER);screen.addView(footer);
    }

    private void scrollToSection(View target) {
        if(target==null || mainScroll==null)return;
        mainScroll.post(()->mainScroll.smoothScrollTo(0,Math.max(0,target.getTop()-dp(10))));
    }
    private TextView navTab(String title, boolean highlighted, Runnable action) {
        TextView tab=text(title,11,highlighted?MINT:0xFFCAD6E7,true);
        tab.setGravity(Gravity.CENTER);
        tab.setBackground(background(highlighted?0xFF163530:0xFF142032,12,highlighted?0xFF317565:BORDER));
        tab.setOnClickListener(v->action.run());return tab;
    }
    private LinearLayout miniStat(String symbol,String title) {
        LinearLayout card=vertical();pad(card,7,12,7,10);
        card.setBackground(background(0x60253755,12,0xFF45697B));
        TextView icon=text(symbol,20,MINT,true);icon.setGravity(Gravity.CENTER);
        card.addView(icon);
        TextView label=text(title,9,0xFFE8F5FF,true);label.setGravity(Gravity.CENTER);
        card.addView(label);return card;
    }
    private interface SaveFloat {void save(float f);}
    private void addSlider(LinearLayout parent, String title,String desc,float min,float max,
                           float initial,String unit,SaveFloat callback) {
        LinearLayout titleRow=horizontal();
        LinearLayout texts=vertical();texts.addView(text(title,12,WHITE,true));gap(texts,3);
        texts.addView(text(desc,11,MUTED,false));
        titleRow.addView(texts,new LinearLayout.LayoutParams(0,-2,1));
        TextView val=text("",15,MINT,true);titleRow.addView(val);
        parent.addView(titleRow);
        SeekBar bar=new SeekBar(this);bar.setMax(100);
        bar.setProgressTintList(ColorStateList.valueOf(MINT));
        bar.setThumbTintList(ColorStateList.valueOf(MINT));
        bar.setProgress(Math.round(100f*(initial-min)/(max-min)));
        java.util.function.Consumer<Float> update=value->{
            val.setText(unit.equals("%")?String.format(Locale.US,"%.0f%%",value*100f):
                    String.format(Locale.US,"%.2fx",value));
        };
        update.accept(initial);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar b,int progress,boolean fromUser){
                if(!fromUser)return;
                float value=min+(max-min)*progress/100f;callback.save(value);update.accept(value);
            }
            @Override public void onStartTrackingTouch(SeekBar b){}
            @Override public void onStopTrackingTouch(SeekBar b){}
        });
        LinearLayout.LayoutParams p=lp(-1,39);p.topMargin=dp(3);parent.addView(bar,p);
    }

    private boolean enabled() {
        String value=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if(value==null)return false;
        ComponentName name=new ComponentName(this,MapperService.class);
        return value.contains(name.flattenToString()) || value.contains(name.flattenToShortString());
    }
    private void refresh() {
        boolean ok=enabled();
        accessStatus.setText(ok?"●  Serviço ativado":"○  Serviço desativado");
        accessStatus.setTextColor(ok?MINT:0xFFFFC37D);
        Set<String> chosen=Store.games(this);
        countText.setText(chosen.size()+" JOGOS");
        gamesList.removeAllViews();
        if(chosen.isEmpty()) {
            LinearLayout empty=vertical();pad(empty,20,29,20,29);empty.setBackground(background(PANEL,18,BORDER));
            TextView emoji=text("⌨  +  🖱",25,MINT,true);emoji.setGravity(Gravity.CENTER);empty.addView(emoji);
            gap(empty,7);
            TextView first=text("Nenhum jogo adicionado ainda",15,WHITE,true);first.setGravity(Gravity.CENTER);empty.addView(first);
            TextView note=text("Toque em + ADICIONAR para escolher seu primeiro jogo.",12,MUTED,false);note.setGravity(Gravity.CENTER);empty.addView(note);
            gamesList.addView(empty);return;
        }
        List<String> sorted=new ArrayList<>(chosen);
        Collections.sort(sorted,(a,b)->label(a).compareToIgnoreCase(label(b)));
        for(String pkg:sorted) {
            LinearLayout card=vertical();pad(card,14,15,14,14);card.setBackground(background(PANEL,17,BORDER));
            LinearLayout head=horizontal();ImageView icon=new ImageView(this);
            try { icon.setImageDrawable(getPackageManager().getApplicationIcon(pkg)); }
            catch(Exception ignored){icon.setImageResource(android.R.drawable.sym_def_app_icon);}
            head.addView(icon,lp(46,46));
            LinearLayout captions=vertical();pad(captions,12,0,0,0);
            captions.addView(text(label(pkg),16,WHITE,true));gap(captions,4);
            captions.addView(text(Store.load(this,pkg).size()+" controles • perfil local",11,MUTED,false));
            head.addView(captions,new LinearLayout.LayoutParams(0,-2,1));
            TextView remove=text("×",25,MUTED,true);pad(remove,11,2,6,2);
            remove.setOnClickListener(v->new AlertDialog.Builder(this)
                    .setTitle("Remover "+label(pkg)+"?")
                    .setMessage("O perfil de controles deste jogo também será apagado.")
                    .setPositiveButton("REMOVER",(d,w)->{Store.removeGame(this,pkg);refresh();})
                    .setNegativeButton("CANCELAR",null).show());
            head.addView(remove);card.addView(head);gap(card,13);
            LinearLayout actions=horizontal();
            TextView play=button("▶  JOGAR",true,v->launchGame(pkg,false));
            LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,-2,1);half.rightMargin=dp(9);
            actions.addView(play,half);
            TextView edit=button("✎  EDITAR",false,v->launchGame(pkg,true));
            actions.addView(edit,new LinearLayout.LayoutParams(0,-2,1));
            card.addView(actions); gamesList.addView(card);gap(gamesList,10);
        }
    }
    private String label(String pkg) {
        try { return getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg,0)).toString(); }
        catch(Exception ex) {return pkg;}
    }
    private void openAccessibility() {
        try {startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}
        catch(Exception e){new AlertDialog.Builder(this).setMessage("Abra Configurações > Acessibilidade > Vortex Mapper.").setPositiveButton("OK",null).show();}
    }
    private void launchGame(String pkg,boolean edit) {
        if(!enabled()) {
            new AlertDialog.Builder(this).setTitle("Permissão necessária")
                    .setMessage("Ative o serviço Vortex Mapper em Configurações > Acessibilidade para mostrar os controles no jogo.")
                    .setPositiveButton("ATIVAR",(d,w)->openAccessibility()).setNegativeButton("CANCELAR",null).show();return;
        }
        Intent game=getPackageManager().getLaunchIntentForPackage(pkg);
        if(game==null) {new AlertDialog.Builder(this).setMessage("Não foi possível abrir este aplicativo. Talvez tenha sido desinstalado.").setPositiveButton("OK",null).show();return;}
        if(edit)Store.requestEdit(this,pkg);
        game.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try{startActivity(game);}catch(Exception e){new AlertDialog.Builder(this).setMessage("Falha ao abrir o jogo: "+e.getMessage()).setPositiveButton("OK",null).show();}
    }
    private static class AppEntry {String pkg,name;Drawable icon;AppEntry(String p,String n,Drawable i){pkg=p;name=n;icon=i;}}
    private void loadLaunchables() {
        launchable.clear();
        PackageManager pm=getPackageManager();
        Intent intent=new Intent(Intent.ACTION_MAIN);intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> matches=pm.queryIntentActivities(intent,0);
        Set<String> seen=new java.util.HashSet<>();
        for(ResolveInfo info:matches) {
            if(info.activityInfo==null)continue;
            String pkg=info.activityInfo.packageName;
            if(pkg.equals(getPackageName())||!seen.add(pkg))continue;
            launchable.add(new AppEntry(pkg,info.loadLabel(pm).toString(),info.loadIcon(pm)));
        }
        Collections.sort(launchable,Comparator.comparing(a->a.name.toLowerCase(Locale.ROOT)));
    }
    private void showPicker() {
        loadLaunchables();
        LinearLayout box=vertical();pad(box,15,10,15,0);
        EditText search=new EditText(this);search.setSingleLine(true);search.setHint("Pesquisar jogo ou aplicativo...");
        search.setTextSize(14);search.setCompoundDrawablePadding(dp(9));box.addView(search);
        ScrollView sv=new ScrollView(this);LinearLayout results=vertical();sv.addView(results);
        box.addView(sv,lp(-1,380));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Adicionar jogo")
                .setView(box).setNegativeButton("FECHAR",null).create();
        Runnable redraw=()->{
            results.removeAllViews();String q=search.getText().toString().trim().toLowerCase(Locale.ROOT);
            int added=0;
            for(AppEntry item:launchable) {
                if(!item.name.toLowerCase(Locale.ROOT).contains(q)&&!item.pkg.toLowerCase(Locale.ROOT).contains(q))continue;
                if(added++>=140)break;
                LinearLayout row=horizontal();pad(row,6,10,6,10);
                ImageView iv=new ImageView(this);iv.setImageDrawable(item.icon);row.addView(iv,lp(32,32));
                LinearLayout txt=vertical();pad(txt,13,0,0,0);
                txt.addView(text(item.name,14,BG,true));
                TextView sub=text(item.pkg,10,0xFF5C6875,false);txt.addView(sub);
                row.addView(txt);
                row.setOnClickListener(v->{Store.addGame(this,item.pkg);dialog.dismiss();refresh();});
                results.addView(row);View line=new View(this);line.setBackgroundColor(0xFFDAE1E5);results.addView(line,lp(-1,1));
            }
            if(added==0)results.addView(text("Nenhum aplicativo encontrado.",13,BG,false));
        };
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){redraw.run();}
            public void afterTextChanged(Editable e){} });
        redraw.run();dialog.show();
    }
}
