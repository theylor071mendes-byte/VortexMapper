package com.vortex.mapper;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.KeyEvent;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class Store {
    private static final String NAME = "vortex_mapper_profiles";
    private Store() {}
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(NAME, Context.MODE_PRIVATE); }

    public static Set<String> games(Context c) {
        return new HashSet<>(prefs(c).getStringSet("games", new HashSet<>()));
    }
    public static void addGame(Context c, String pkg) {
        Set<String> s = games(c); s.add(pkg);
        prefs(c).edit().putStringSet("games", s).apply();
    }
    public static void removeGame(Context c, String pkg) {
        Set<String> s = games(c); s.remove(pkg);
        prefs(c).edit().putStringSet("games", s).remove("layout_" + pkg).apply();
    }
    public static boolean mouseEnabled(Context c) { return prefs(c).getBoolean("mouse", false); }
    public static void setMouseEnabled(Context c, boolean b) { prefs(c).edit().putBoolean("mouse", b).apply(); }
    public static void requestEdit(Context c, String pkg) {
        prefs(c).edit().putString("edit_on_launch", pkg).apply();
    }
    public static boolean takeEditRequest(Context c, String pkg) {
        if (!pkg.equals(prefs(c).getString("edit_on_launch", ""))) return false;
        prefs(c).edit().remove("edit_on_launch").apply();
        return true;
    }

    public static List<Mapping> load(Context c, String pkg) {
        String json = prefs(c).getString("layout_" + pkg, null);
        if (json == null) return defaultLayout();
        List<Mapping> result = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(json);
            for (int i=0; i<a.length(); i++) result.add(Mapping.fromJson(a.getJSONObject(i)));
        } catch (Exception e) { return defaultLayout(); }
        return result;
    }
    public static void save(Context c, String pkg, List<Mapping> controls) {
        JSONArray a = new JSONArray();
        for (Mapping m : controls) {
            try { a.put(m.toJson()); } catch (Exception ignored) {}
        }
        prefs(c).edit().putString("layout_" + pkg, a.toString()).apply();
    }
    private static List<Mapping> defaultLayout() {
        List<Mapping> l = new ArrayList<>();
        l.add(new Mapping(Mapping.JOYSTICK, "WASD", .20f, .77f, true));
        l.add(new Mapping(KeyEvent.KEYCODE_SPACE, "ESPAÇO", .82f, .78f, false));
        l.add(new Mapping(KeyEvent.KEYCODE_R, "R", .88f, .47f, false));
        l.add(new Mapping(KeyEvent.KEYCODE_F, "F", .73f, .63f, false));
        l.add(new Mapping(Mapping.MOUSE_LEFT, "M1", .88f, .61f, false));
        l.add(new Mapping(Mapping.AIM, "MIRA", .67f, .38f, false));
        return l;
    }
}
