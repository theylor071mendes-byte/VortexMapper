package com.vortex.mapper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Acessibilidade voluntária e específica para os jogos que o usuário adicionou.
 * Não instala mods, não lê contas e não altera arquivos de jogos.
 */
public class MapperService extends AccessibilityService {
    public static MapperService current;
    private static final int MINT=0xFF7EF5CF, BG=0xFF0D1927, WHITE=0xFFE8F5FF;
    private WindowManager wm;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private String gamePkg;
    private final List<Mapping> controls=new ArrayList<>();
    private View bubble, toolbar, picker;
    private EditorView editor;
    private boolean menuOpen=false, editorOpen=false;
    private int selected=-1;
    private final InputSequencer input=new InputSequencer();
    private float lastMouseX=Float.NaN,lastMouseY=Float.NaN;
    private long lastAimTime=0L;
    private final Set<Integer> mouseDown=new HashSet<>();

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        current=this;
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        AccessibilityServiceInfo cfg=getServiceInfo();
        if(cfg!=null) {
            cfg.flags|=AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
            setServiceInfo(cfg);
        }
        syncMouseMode();
    }
    @Override public void onDestroy() {
        clearActive();current=null;super.onDestroy();
    }
    @Override public void onInterrupt() { input.clear(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if(e==null||e.getPackageName()==null)return;
        int kind=e.getEventType();
        if(kind!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && kind!=AccessibilityEvent.TYPE_WINDOWS_CHANGED)return;
        String pkg=e.getPackageName().toString();
        if(pkg.equals(getPackageName())) {
            // A tela principal e o próprio overlay têm o mesmo pacote.
            // Ignore a bolha, mas feche o mapeamento ao voltar ao painel principal.
            String cls=e.getClassName()==null?"":e.getClassName().toString();
            if(cls.equals(MainActivity.class.getName()))clearActive();
            return;
        }
        if(pkg.equals("android"))return;
        if(pkg.equals(gamePkg)) {
            if(Store.takeEditRequest(this,pkg))openEditor();
            return;
        }
        if(Store.games(this).contains(pkg)) {
            activate(pkg);
        } else if(gamePkg!=null && !isIgnorablePackage(pkg)) {
            clearActive();
        }
    }
    private boolean isIgnorablePackage(String pkg) {
        // Teclados virtuais não encerram o mapeamento ao serem exibidos.
        return pkg.contains("inputmethod") || pkg.contains("keyboard");
    }
    private void activate(String pkg) {
        if(pkg.equals(gamePkg))return;
        clearActive();
        gamePkg=pkg;controls.addAll(Store.load(this,pkg));
        selected=-1;input.clear();
        createBubble();syncMouseMode();
        if(Store.takeEditRequest(this,pkg))openEditor();
    }
    private void clearActive() {
        gamePkg=null;input.clear();controls.clear();
        editorOpen=false;menuOpen=false;selected=-1;
        remove(picker);remove(editor);remove(toolbar);remove(bubble);
        picker=null;editor=null;toolbar=null;bubble=null;
        lastMouseX=Float.NaN;lastMouseY=Float.NaN;mouseDown.clear();
        syncMouseMode();
    }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable shape(int fill,int border,int r) {
        GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(r));
        if(border!=0)d.setStroke(dp(1),border);return d;
    }
    private TextView button(String s,boolean accent,View.OnClickListener click) {
        TextView v=new TextView(this);v.setText(s);v.setTextSize(11);
        v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setTextColor(accent?BG:WHITE);
        v.setBackground(shape(accent?MINT:0xFF233549,accent?0:0xFF486073,10));
        v.setGravity(Gravity.CENTER);v.setPadding(dp(12),dp(10),dp(12),dp(10));
        v.setOnClickListener(click);return v;
    }
    private TextView text(String s,int size,int color) {
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;
    }
    private WindowManager.LayoutParams params(int width,int height,int gravity,int x,int y) {
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(width,height,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                android.graphics.PixelFormat.TRANSLUCENT);
        p.gravity=gravity;p.x=x;p.y=y;return p;
    }
    private void add(View v,WindowManager.LayoutParams p) {
        try {wm.addView(v,p);} catch(Exception ex){android.util.Log.e("VortexMapper","Overlay indisponível",ex);}
    }
    private void remove(View v) {if(v!=null&&wm!=null){try{wm.removeViewImmediate(v);}catch(Exception ignored){}}}

    private void createBubble() {
        if(gamePkg==null||wm==null)return;
        TextView v=new TextView(this);v.setText("V");v.setTextSize(22);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        v.setTextColor(BG);v.setGravity(Gravity.CENTER);
        v.setBackground(shape(MINT,0,18));v.setElevation(dp(10));
        WindowManager.LayoutParams p=params(dp(53),dp(53),Gravity.TOP|Gravity.RIGHT,dp(12),dp(170));
        v.setOnTouchListener(new View.OnTouchListener(){
            float downX,downY;int startX,startY;boolean moved;
            @Override public boolean onTouch(View view,MotionEvent e) {
                if(e.getActionMasked()==MotionEvent.ACTION_DOWN) {
                    downX=e.getRawX();downY=e.getRawY();startX=p.x;startY=p.y;moved=false;return true;
                }
                if(e.getActionMasked()==MotionEvent.ACTION_MOVE) {
                    float dx=e.getRawX()-downX,dy=e.getRawY()-downY;
                    if(Math.abs(dx)>dp(9)||Math.abs(dy)>dp(9))moved=true;
                    if(moved){p.x=Math.max(0,startX-Math.round(dx));p.y=Math.max(0,startY+Math.round(dy));
                        try{wm.updateViewLayout(v,p);}catch(Exception ignored){}}
                    return true;
                }
                if(e.getActionMasked()==MotionEvent.ACTION_UP){if(!moved)toggleMenu();return true;}
                return true;
            }
        });bubble=v;add(bubble,p);
    }
    private void toggleMenu() {
        if(menuOpen && !editorOpen) {
            menuOpen=false;remove(toolbar);toolbar=null;return;
        }
        if(!menuOpen) {menuOpen=true;buildToolbar();}
        else if(editorOpen){save();closeEditor();}
    }
    private void buildToolbar() {
        remove(toolbar);
        HorizontalScrollView scroll=new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setFillViewport(true);
        scroll.setBackground(shape(0xEF0D1B2A,0xFF41625F,15));
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(7),dp(8),dp(7));
        toolbarButton(row,editorOpen?"✓ PRONTO":"✎ EDITAR",true,v->{if(editorOpen){save();closeEditor();}else openEditor();});
        toolbarButton(row,"＋ TECLA",false,v->openPicker());
        if(editorOpen) {
            toolbarButton(row,"⇄ MODO",false,v->toggleSelectedMode());
            toolbarButton(row,"✕ EXCLUIR",false,v->removeSelected());
        }
        toolbarButton(row,"▣ SALVAR",false,v->{save();Toast.makeText(this,"Perfil salvo",Toast.LENGTH_SHORT).show();});
        toolbarButton(row,"FECHAR",false,v->{save();closeEditor();menuOpen=false;remove(toolbar);toolbar=null;});
        scroll.addView(row);toolbar=scroll;
        add(toolbar,params(-1,dp(59),Gravity.TOP,0,dp(14)));
    }
    private void toolbarButton(LinearLayout row,String label,boolean primary,View.OnClickListener onClick) {
        TextView v=button(label,primary,onClick);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(41));p.rightMargin=dp(6);row.addView(v,p);
    }
    private void openEditor() {
        if(gamePkg==null||wm==null)return;
        if(!editorOpen) {
            editorOpen=true;input.clear();selected=-1;
            editor=new EditorView();
            add(editor,params(-1,-1,Gravity.TOP|Gravity.LEFT,0,0));
        }
        menuOpen=true;
        // Barra acima da camada de edição.
        buildToolbar();
        if(bubble!=null) {
            // Reempilha a bolha acima da área de edição.
            View old=bubble;WindowManager.LayoutParams oldParams=(WindowManager.LayoutParams)old.getLayoutParams();
            if(oldParams!=null){remove(old);add(old,oldParams);}
        }
        Toast.makeText(this,"Arraste os botões para as posições do jogo",Toast.LENGTH_SHORT).show();
    }
    private void closeEditor() {
        editorOpen=false;selected=-1;
        remove(picker);picker=null;remove(editor);editor=null;
        if(menuOpen)buildToolbar();
    }
    private void save() {
        if(gamePkg!=null)Store.save(this,gamePkg,controls);
    }
    private void toggleSelectedMode() {
        if(selected<0||selected>=controls.size()) {Toast.makeText(this,"Selecione um botão primeiro",Toast.LENGTH_SHORT).show();return;}
        Mapping m=controls.get(selected);
        if(m.isAim()||m.isJoystick()) {Toast.makeText(this,"Este controle tem modo fixo",Toast.LENGTH_SHORT).show();return;}
        m.hold=!m.hold;save();if(editor!=null)editor.invalidate();
        Toast.makeText(this,m.hold?"Modo SEGURAR":"Modo TOQUE",Toast.LENGTH_SHORT).show();
    }
    private void removeSelected() {
        if(selected<0||selected>=controls.size()) {Toast.makeText(this,"Selecione um botão primeiro",Toast.LENGTH_SHORT).show();return;}
        controls.remove(selected);selected=-1;save();if(editor!=null)editor.invalidate();
    }

    private void openPicker() {
        if(gamePkg==null)return;
        openEditor();remove(picker);picker=null;
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(13),dp(13),dp(13),dp(12));box.setBackground(shape(0xF7112030,0xFF578579,20));
        TextView heading=text("ESCOLHA UM CONTROLE",14,MINT);heading.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        box.addView(heading);
        TextView hint=text("Depois arraste para o botão correspondente no jogo.",11,0xFFC1D3E2);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(6);hp.bottomMargin=dp(10);box.addView(hint,hp);
        ScrollView sc=new ScrollView(this);
        GridLayout grid=new GridLayout(this);grid.setColumnCount(4);
        final int[] keys={Mapping.JOYSTICK,KeyEvent.KEYCODE_W,KeyEvent.KEYCODE_A,KeyEvent.KEYCODE_S,
                KeyEvent.KEYCODE_D,KeyEvent.KEYCODE_SPACE,KeyEvent.KEYCODE_SHIFT_LEFT,KeyEvent.KEYCODE_CTRL_LEFT,
                KeyEvent.KEYCODE_E,KeyEvent.KEYCODE_F,KeyEvent.KEYCODE_R,KeyEvent.KEYCODE_Q,
                KeyEvent.KEYCODE_1,KeyEvent.KEYCODE_2,KeyEvent.KEYCODE_3,KeyEvent.KEYCODE_4,
                KeyEvent.KEYCODE_TAB,KeyEvent.KEYCODE_C,KeyEvent.KEYCODE_X,KeyEvent.KEYCODE_Z,
                Mapping.MOUSE_LEFT,Mapping.MOUSE_RIGHT,Mapping.AIM,KeyEvent.KEYCODE_ENTER};
        final String[] labels={"WASD","W","A","S","D","ESPAÇO","SHIFT","CTRL","E","F","R","Q",
                "1","2","3","4","TAB","C","X","Z","M1","M2","MIRA","ENTER"};
        for(int i=0;i<keys.length;i++) {
            final int code=keys[i];final String label=labels[i];
            TextView cell=button(label,false,v->addMapping(code,label));
            GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=dp(68);p.height=dp(43);
            p.setMargins(dp(3),dp(3),dp(3),dp(3));grid.addView(cell,p);
        }
        sc.addView(grid);box.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        TextView cancel=button("VOLTAR",true,v->{remove(picker);picker=null;});
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(42));cp.topMargin=dp(10);box.addView(cancel,cp);
        picker=box;add(picker,params(dp(330),dp(408),Gravity.CENTER,0,0));
    }
    private void addMapping(int code,String label) {
        if(code==Mapping.JOYSTICK||code==Mapping.AIM) {
            for(Mapping m:controls)if(m.code==code){selected=controls.indexOf(m);remove(picker);picker=null;
                if(editor!=null)editor.invalidate();Toast.makeText(this,"Controle selecionado: arraste-o",Toast.LENGTH_SHORT).show();return;}
        }
        boolean hold=(code==KeyEvent.KEYCODE_W||code==KeyEvent.KEYCODE_A||code==KeyEvent.KEYCODE_S||
                code==KeyEvent.KEYCODE_D||code==KeyEvent.KEYCODE_SHIFT_LEFT||code==KeyEvent.KEYCODE_CTRL_LEFT||code==Mapping.JOYSTICK);
        float x=code==Mapping.JOYSTICK?.20f:.55f;
        float y=code==Mapping.JOYSTICK?.77f:.50f;
        if(code==Mapping.AIM){x=.69f;y=.38f;}
        controls.add(new Mapping(code,label,x,y,hold));selected=controls.size()-1;
        remove(picker);picker=null;save();if(editor!=null)editor.invalidate();
        Toast.makeText(this,"Arraste "+label+" até o controle desejado",Toast.LENGTH_SHORT).show();
    }
    private class EditorView extends View {
        final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        int dragging=-1;
        EditorView(){super(MapperService.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(0x44021018);
            paint.setColor(0xFFB6D6E2);paint.setTextSize(dp(12));paint.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText("ARRASTE OS CÍRCULOS • SELECIONE PARA ALTERAR",dp(13),dp(94),paint);
            float w=getWidth(),h=getHeight();
            for(int i=0;i<controls.size();i++) {
                Mapping m=controls.get(i);float cx=m.x*w,cy=m.y*h;
                float radius=dp(m.isJoystick()?40:32);
                paint.setStyle(Paint.Style.FILL);paint.setColor(i==selected?0xE87EF5CF:0xC91C3446);
                c.drawCircle(cx,cy,radius,paint);
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(i==selected?3:2));
                paint.setColor(i==selected?Color.WHITE:MINT);c.drawCircle(cx,cy,radius,paint);
                if(m.isJoystick()){paint.setColor(0x887EF5CF);c.drawCircle(cx,cy,dp(51),paint);}
                paint.setStyle(Paint.Style.FILL);paint.setColor(i==selected?BG:WHITE);
                paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextAlign(Paint.Align.CENTER);
                paint.setTextSize(dp(m.label.length()>4?11:14));
                c.drawText(m.label,cx,cy+dp(1),paint);
                paint.setTextSize(dp(9));
                c.drawText(m.isJoystick()?"ANALÓGICO":m.isAim()?"MOUSE":m.hold?"SEGURAR":"TOQUE",cx,cy+dp(14),paint);
            }
            paint.setTextAlign(Paint.Align.LEFT);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            int action=e.getActionMasked();
            if(action==MotionEvent.ACTION_DOWN) {
                dragging=-1;float best=dp(58);
                for(int i=controls.size()-1;i>=0;i--) {
                    Mapping m=controls.get(i);
                    float dx=m.x*getWidth()-e.getX(),dy=m.y*getHeight()-e.getY();
                    float dist=(float)Math.sqrt(dx*dx+dy*dy);
                    if(dist<best){best=dist;dragging=i;}
                }
                if(dragging>=0){selected=dragging;invalidate();}return true;
            }
            if(action==MotionEvent.ACTION_MOVE && dragging>=0) {
                Mapping m=controls.get(dragging);
                m.x=Math.max(.05f,Math.min(.95f,e.getX()/Math.max(1f,getWidth())));
                m.y=Math.max(.09f,Math.min(.95f,e.getY()/Math.max(1f,getHeight())));
                invalidate();return true;
            }
            if(action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_CANCEL) {
                if(dragging>=0)save();dragging=-1;return true;
            }
            return true;
        }
    }

    @Override protected boolean onKeyEvent(KeyEvent e) {
        if(gamePkg==null||editorOpen)return false;
        int code=e.getKeyCode();boolean down=e.getAction()==KeyEvent.ACTION_DOWN;
        if(e.getAction()!=KeyEvent.ACTION_DOWN && e.getAction()!=KeyEvent.ACTION_UP)return false;
        for(Mapping m:controls) {
            if(m.isJoystick() && (code==KeyEvent.KEYCODE_W||code==KeyEvent.KEYCODE_A||
                    code==KeyEvent.KEYCODE_S||code==KeyEvent.KEYCODE_D)) {
                if(e.getRepeatCount()==0||!down)input.direction(code,down);
                return true;
            }
        }
        boolean found=false;
        for(Mapping m:controls) {
            if(m.code==code && code>=0) {
                found=true;
                if(e.getRepeatCount()==0||!down)input.button(m,down);
            }
        }
        return found;
    }
    public void syncMouseMode() {
        if(Build.VERSION.SDK_INT<34)return;
        AccessibilityServiceInfo cfg=getServiceInfo();if(cfg==null)return;
        boolean on=gamePkg!=null && Store.mouseEnabled(this);
        cfg.setMotionEventSources(on?InputDevice.SOURCE_MOUSE:0);
        setServiceInfo(cfg);
        lastMouseX=Float.NaN;lastMouseY=Float.NaN;
    }
    @Override public void onMotionEvent(MotionEvent e) {
        if(gamePkg==null||editorOpen||!Store.mouseEnabled(this))return;
        if((e.getSource() & InputDevice.SOURCE_MOUSE)!=InputDevice.SOURCE_MOUSE)return;
        int action=e.getActionMasked();
        if(action==MotionEvent.ACTION_BUTTON_PRESS || action==MotionEvent.ACTION_BUTTON_RELEASE) {
            int b=e.getActionButton();int code=(b==MotionEvent.BUTTON_PRIMARY)?Mapping.MOUSE_LEFT:
                    (b==MotionEvent.BUTTON_SECONDARY)?Mapping.MOUSE_RIGHT:0;
            if(code!=0)mouseButton(code,action==MotionEvent.ACTION_BUTTON_PRESS);
        } else if(action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_UP) {
            if(action==MotionEvent.ACTION_DOWN) {
                int code=(e.getButtonState()&MotionEvent.BUTTON_SECONDARY)!=0?Mapping.MOUSE_RIGHT:Mapping.MOUSE_LEFT;
                mouseButton(code,true);
            } else {
                // Em ACTION_UP, o buttonState geralmente já foi zerado.
                for(int code:new HashSet<>(mouseDown))mouseButton(code,false);
            }
        }
        if(action==MotionEvent.ACTION_HOVER_MOVE || action==MotionEvent.ACTION_MOVE) {
            float x=e.getX(),y=e.getY();
            if(!Float.isNaN(lastMouseX)) {
                float dx=x-lastMouseX,dy=y-lastMouseY;
                if((Math.abs(dx)+Math.abs(dy))>=2 && android.os.SystemClock.uptimeMillis()-lastAimTime>=35) {
                    for(Mapping m:controls)if(m.isAim()) {
                        input.aim(m,dx,dy);lastAimTime=android.os.SystemClock.uptimeMillis();break;
                    }
                }
            }
            lastMouseX=x;lastMouseY=y;
        }
    }
    private void mouseButton(int code,boolean down) {
        // Alguns mouses emitem BUTTON_PRESS e DOWN para o mesmo clique.
        if(down&&!mouseDown.add(code))return;
        if(!down&&!mouseDown.remove(code))return;
        for(Mapping m:controls)if(m.code==code)input.button(m,down);
    }
    private Point screenSize() {
        Point p=new Point();wm.getDefaultDisplay().getRealSize(p);return p;
    }
    private PointF position(Mapping m) {
        Point s=screenSize();return new PointF(s.x*m.x,s.y*m.y);
    }
    private Mapping find(int code) {
        for(Mapping m:controls)if(m.code==code)return m;
        return null;
    }
    private static class Tap {
        final float x,y,ex,ey;final boolean swipe;
        Tap(float x,float y,float ex,float ey,boolean swipe) {
            this.x=x;this.y=y;this.ex=ex;this.ey=ey;this.swipe=swipe;
        }
    }
    /**
     * Serializa as chamadas a dispatchGesture. Suporta até seis dedos em hold simultâneos;
     * toques adicionais interrompem brevemente os holds (limitação do Android).
     */
    private final class InputSequencer {
        private final Set<Integer> pressed=new HashSet<>();
        private final Set<Integer> directions=new HashSet<>();
        private Map<Integer,GestureDescription.StrokeDescription> previous=new HashMap<>();
        private Map<Integer,PointF> endpoints=new HashMap<>();
        private final ArrayDeque<Tap> taps=new ArrayDeque<>();
        private boolean busy=false;
        void clear() {
            pressed.clear();directions.clear();previous.clear();endpoints.clear();taps.clear();
            // Uma chamada em curso termina/cancela naturalmente.
        }
        void button(Mapping m,boolean down) {
            if(m.hold) {
                if(down)pressed.add(m.code);else pressed.remove(m.code);
                next();
            } else if(down){
                if(taps.size()<16) {
                    PointF p=position(m);taps.add(new Tap(p.x,p.y,p.x,p.y,false));next();
                }
            }
        }
        void direction(int code,boolean down) {
            if(down)directions.add(code);else directions.remove(code);
            if(directions.isEmpty())pressed.remove(Mapping.JOYSTICK);
            else pressed.add(Mapping.JOYSTICK);
            next();
        }
        void aim(Mapping m,float dx,float dy) {
            if(taps.size()>3)return;
            PointF p=position(m);
            float max=dp(90),scale=1.6f;
            float vx=Math.max(-max,Math.min(max,dx*scale));
            float vy=Math.max(-max,Math.min(max,dy*scale));
            taps.add(new Tap(p.x,p.y,p.x+vx,p.y+vy,true));next();
        }
        PointF joystickTarget(Mapping m) {
            PointF center=position(m);int h=0,v=0;
            if(directions.contains(KeyEvent.KEYCODE_A))h--;
            if(directions.contains(KeyEvent.KEYCODE_D))h++;
            if(directions.contains(KeyEvent.KEYCODE_W))v--;
            if(directions.contains(KeyEvent.KEYCODE_S))v++;
            float r=dp(51);if(h!=0&&v!=0)r*=.7071f;
            return new PointF(center.x+h*r,center.y+v*r);
        }
        void next() {
            if(busy||gamePkg==null||editorOpen)return;
            if(!taps.isEmpty()) {
                previous.clear();endpoints.clear();
                GestureDescription.Builder b=new GestureDescription.Builder();
                int n=0;
                while(!taps.isEmpty()&&n++<4) {
                    Tap t=taps.removeFirst();Path path=new Path();path.moveTo(t.x,t.y);
                    if(t.swipe)path.lineTo(t.ex,t.ey);
                    b.addStroke(new GestureDescription.StrokeDescription(path,0,t.swipe?48:54,false));
                }
                send(b.build());return;
            }
            if(pressed.isEmpty()&&previous.isEmpty())return;
            GestureDescription.Builder builder=new GestureDescription.Builder();
            Map<Integer,GestureDescription.StrokeDescription> nextStrokes=new HashMap<>();
            Map<Integer,PointF> nextPoints=new HashMap<>();
            int count=0;
            for(Map.Entry<Integer,GestureDescription.StrokeDescription> en:previous.entrySet()) {
                if(count>=6)break;
                int code=en.getKey();
                Mapping m=find(code);
                PointF start=endpoints.get(code);
                if(start==null)continue;
                PointF dest=(code==Mapping.JOYSTICK&&m!=null)?joystickTarget(m):start;
                Path path=new Path();path.moveTo(start.x,start.y);
                if(start.x!=dest.x||start.y!=dest.y)path.lineTo(dest.x,dest.y);
                boolean keep=pressed.contains(code)&&m!=null;
                try {
                    GestureDescription.StrokeDescription continuation=en.getValue().continueStroke(path,0,keep?180:1,keep);
                    builder.addStroke(continuation);count++;
                    if(keep){nextStrokes.put(code,continuation);nextPoints.put(code,dest);}
                } catch(IllegalArgumentException ignored) {}
            }
            for(int code:new HashSet<>(pressed)) {
                if(count>=6)break;
                if(previous.containsKey(code))continue;
                Mapping m=find(code);if(m==null)continue;
                PointF start=position(m);
                PointF end=code==Mapping.JOYSTICK?joystickTarget(m):start;
                Path path=new Path();path.moveTo(start.x,start.y);
                if(end.x!=start.x||end.y!=start.y)path.lineTo(end.x,end.y);
                GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(path,0,180,true);
                builder.addStroke(stroke);nextStrokes.put(code,stroke);nextPoints.put(code,end);count++;
            }
            if(count==0){previous.clear();endpoints.clear();return;}
            previous=nextStrokes;endpoints=nextPoints;
            send(builder.build());
        }
        void send(GestureDescription g) {
            busy=true;
            boolean submitted=dispatchGesture(g,new GestureResultCallback(){
                @Override public void onCompleted(GestureDescription gesture){busy=false;next();}
                @Override public void onCancelled(GestureDescription gesture){
                    busy=false;previous.clear();endpoints.clear();
                    // Evita tentar injetar indefinidamente em jogos bloqueados.
                    handler.postDelayed(()->{if(gamePkg!=null)next();},120);
                }
            },handler);
            if(!submitted){busy=false;previous.clear();endpoints.clear();}
        }
    }
}
