package com.vortex.mapper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Typeface;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.DashPathEffect;
import android.graphics.RectF;
import android.widget.FrameLayout;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.content.res.ColorStateList;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.GridLayout;
import android.widget.SeekBar;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Acessibilidade voluntária e específica para os jogos que o usuário adicionou.
 * Não instala mods, não lê contas e não altera arquivos de jogos.
 */
public class MapperService extends AccessibilityService {
    public static MapperService current;
    private static final int MINT=0xFF7EF5CF, BG=0xFF0D1927, WHITE=0xFFE8F5FF;
    private WindowManager wm;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private String gamePkg;
    private final List<Mapping> controls=new ArrayList<>();
    private View bubble, cameraToggle, toolbar, radialMenu, picker, cameraPanel, shortcutPicker;
    private TextView cameraLabel;
    private EditorView editor;
    private boolean menuOpen=false, editorOpen=false, cameraCaptured=false;
    private int selected=-1;
    private boolean waitingHotkey=false;
    private float pendingAddX=Float.NaN, pendingAddY=Float.NaN;
    private final InputSequencer input=new InputSequencer();
    private float lastMouseX=Float.NaN,lastMouseY=Float.NaN;
    private long lastAimTime=0L;
    private float smoothedDx=0f, smoothedDy=0f;
    // Acumula movimentos voluntarios menores; evita gerar "toques" por micro-jitter.
    private float pendingAimDx=0f,pendingAimDy=0f;
    private long lastMouseMotionMs=0L;
    private final Set<Integer> mouseDown=new HashSet<>();

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        current=this;
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        AccessibilityServiceInfo cfg=getServiceInfo();
        if(cfg!=null) {
            cfg.flags|=AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
            setServiceInfo(cfg);
        }
        // Restaura uma velocidade de cursor que tenha ficado alterada apos uma
        // interrupcao/reinicializacao anterior do aplicativo.
        PointerSpeedController.restore(this);
        syncMouseMode();
    }
    @Override public void onDestroy() {
        clearActive();current=null;super.onDestroy();
    }
    @Override public void onInterrupt() { clearActive(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if(e==null||e.getPackageName()==null)return;
        int kind=e.getEventType();
        if(kind!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && kind!=AccessibilityEvent.TYPE_WINDOWS_CHANGED)return;
        String pkg=e.getPackageName().toString();
        if(pkg.equals(getPackageName())) {
            // A tela principal e o próprio overlay têm o mesmo pacote.
            // Ignore a bolha, mas feche o mapeamento ao voltar ao painel principal.
            String cls=e.getClassName()==null?"":e.getClassName().toString();
            if(cls.equals(MainActivity.class.getName()))clearActive();
            return;
        }
        if(pkg.equals("android"))return;
        if(pkg.equals(gamePkg)) {
            if(Store.takeEditRequest(this,pkg))openEditor();
            return;
        }
        if(Store.games(this).contains(pkg)) {
            activate(pkg);
        } else if(gamePkg!=null && !isIgnorablePackage(pkg)) {
            clearActive();
        }
    }
    private boolean isIgnorablePackage(String pkg) {
        // Teclados virtuais não encerram o mapeamento ao serem exibidos.
        return pkg.contains("inputmethod") || pkg.contains("keyboard");
    }
    private void activate(String pkg) {
        if(pkg.equals(gamePkg))return;
        clearActive();
        gamePkg=pkg;controls.addAll(Store.load(this,pkg));
        selected=-1;input.clear();
        PointerSpeedController.applyForGame(this);
        createBubble();createCameraToggle();syncMouseMode();
        if(Store.takeEditRequest(this,pkg))openEditor();
    }
    private void clearActive() {
        gamePkg=null;input.clear();controls.clear();
        editorOpen=false;menuOpen=false;cameraCaptured=false;selected=-1;
        remove(cameraPanel);remove(picker);remove(shortcutPicker);remove(editor);remove(toolbar);remove(radialMenu);remove(cameraToggle);remove(bubble);
        PointerSpeedController.restore(this);
        cameraPanel=null;picker=null;shortcutPicker=null;editor=null;toolbar=null;radialMenu=null;cameraToggle=null;bubble=null;cameraLabel=null;
        waitingHotkey=false;pendingAddX=Float.NaN;pendingAddY=Float.NaN;
        lastMouseX=Float.NaN;lastMouseY=Float.NaN;smoothedDx=0f;smoothedDy=0f;pendingAimDx=0f;pendingAimDy=0f;lastMouseMotionMs=0L;mouseDown.clear();
        syncMouseMode();
    }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable shape(int fill,int border,int r) {
        GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(r));
        if(border!=0)d.setStroke(dp(1),border);return d;
    }
    private TextView button(String s,boolean accent,View.OnClickListener click) {
        TextView v=new TextView(this);v.setText(s);v.setTextSize(11);
        v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setTextColor(accent?BG:WHITE);
        v.setBackground(shape(accent?MINT:0xFF233549,accent?0:0xFF486073,10));
        v.setGravity(Gravity.CENTER);v.setPadding(dp(12),dp(10),dp(12),dp(10));
        v.setOnClickListener(click);return v;
    }
    private TextView text(String s,int size,int color) {
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;
    }
    private WindowManager.LayoutParams params(int width,int height,int gravity,int x,int y) {
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(width,height,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                android.graphics.PixelFormat.TRANSLUCENT);
        p.gravity=gravity;p.x=x;p.y=y;return p;
    }
    private void add(View v,WindowManager.LayoutParams p) {
        try {wm.addView(v,p);} catch(Exception ex){android.util.Log.e("VortexMapper","Overlay indisponível",ex);}
    }
    private void remove(View v) {if(v!=null&&wm!=null){try{wm.removeViewImmediate(v);}catch(Exception ignored){}}}

    private void createBubble() {
        if(gamePkg==null||wm==null)return;
        TextView v=new TextView(this);v.setText("V");v.setTextSize(22);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        v.setTextColor(BG);v.setGravity(Gravity.CENTER);
        v.setBackground(shape(MINT,0,18));v.setElevation(dp(10));
        WindowManager.LayoutParams p=params(dp(53),dp(53),Gravity.TOP|Gravity.RIGHT,dp(12),dp(170));
        v.setOnTouchListener(new View.OnTouchListener(){
            float downX,downY;int startX,startY;boolean moved;
            @Override public boolean onTouch(View view,MotionEvent e) {
                if(e.getActionMasked()==MotionEvent.ACTION_DOWN) {
                    downX=e.getRawX();downY=e.getRawY();startX=p.x;startY=p.y;moved=false;return true;
                }
                if(e.getActionMasked()==MotionEvent.ACTION_MOVE) {
                    float dx=e.getRawX()-downX,dy=e.getRawY()-downY;
                    if(Math.abs(dx)>dp(9)||Math.abs(dy)>dp(9))moved=true;
                    if(moved){p.x=Math.max(0,startX-Math.round(dx));p.y=Math.max(0,startY+Math.round(dy));
                        try{wm.updateViewLayout(v,p);}catch(Exception ignored){}}
                    return true;
                }
                if(e.getActionMasked()==MotionEvent.ACTION_UP){if(!moved)toggleMenu();return true;}
                return true;
            }
        });bubble=v;add(bubble,p);
    }
    /** Alterna interceptacao do mouse apenas para o jogo atual.
     *  Nao pode ocultar / prender o cursor do Android em todos os dispositivos.
     */
    private void createCameraToggle() {
        if(gamePkg==null||wm==null)return;
        TextView v=new TextView(this);
        v.setTextSize(11);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        v.setGravity(Gravity.CENTER);v.setElevation(dp(8));
        v.setOnClickListener(view->toggleCameraCapture());
        cameraToggle=v;cameraLabel=v;
        refreshCameraToggle();
        add(v,params(dp(135),dp(44),Gravity.TOP|Gravity.RIGHT,dp(8),dp(230)));
    }
    private void refreshCameraToggle() {
        if(cameraLabel==null)return;
        boolean active=cameraCaptured && Store.mouseEnabled(this) && Build.VERSION.SDK_INT>=34;
        cameraLabel.setText(active?"◎  CÂMERA ON":"◉  CURSOR LIVRE");
        cameraLabel.setTextColor(active?BG:WHITE);
        cameraLabel.setBackground(shape(active?MINT:0xF0172B41,active?0:0xFF48677F,15));
    }
    private void toggleCameraCapture() {
        if(gamePkg==null)return;
        if(Build.VERSION.SDK_INT<34) {
            Toast.makeText(this,"Captura de mouse requer Android 14+",Toast.LENGTH_LONG).show();return;
        }
        if(!Store.mouseEnabled(this)) {
            Toast.makeText(this,"Ative mouse experimental no painel Vortex Mapper",Toast.LENGTH_LONG).show();return;
        }
        cameraCaptured=!cameraCaptured;
        syncMouseMode();refreshCameraToggle();
        Toast.makeText(this,cameraCaptured?
                "Modo câmera: movimento do mouse vira deslize experimental":"Mouse liberado para o Android",
                Toast.LENGTH_SHORT).show();
    }
    private void toggleMenu() {
        if(editorOpen){save();closeEditor();menuOpen=true;buildRadialMenu();return;}
        if(menuOpen)closeRadialMenu();
        else {menuOpen=true;buildRadialMenu();syncMouseMode();}
    }
    private void closeRadialMenu() {
        menuOpen=false;remove(radialMenu);radialMenu=null;syncMouseMode();
    }
    private void radialAction(Runnable job) {
        closeRadialMenu();job.run();
    }
    private void buildRadialMenu() {
        remove(radialMenu);
        if(editorOpen || gamePkg==null || wm==null)return;
        Point size=new Point();wm.getDefaultDisplay().getSize(size);
        final int width=Math.min(size.x-dp(8),Math.min(Math.round(size.x*(size.x>size.y?.43f:.88f)),dp(size.x>size.y?365:320)));
        final int height=size.y;
        FrameLayout pane=new FrameLayout(this);pane.setElevation(dp(18));
        View background=new View(this){
            Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c){
                super.onDraw(c);
                float w=getWidth(),h=getHeight();
                Path area=new Path();area.moveTo(0,0);area.lineTo(w*.48f,0);
                area.cubicTo(w*1.19f,h*.20f,w*1.16f,h*.82f,w*.44f,h);
                area.lineTo(0,h);area.close();
                paint.setStyle(Paint.Style.FILL);
                paint.setShader(new LinearGradient(0,0,w*.95f,h*.35f,
                        new int[]{0xEF171C50,0xE7353A91,0xDB6471ED},null,Shader.TileMode.CLAMP));
                c.drawPath(area,paint);paint.setShader(null);
                Path arc=new Path();arc.moveTo(w*.49f,dp(3));
                arc.cubicTo(w*1.16f,h*.21f,w*1.14f,h*.81f,w*.43f,h-dp(4));
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(5));
                paint.setColor(0xFF808CFA);c.drawPath(arc,paint);
                paint.setStrokeWidth(dp(2.5f));paint.setColor(0xFFE1E5FF);
                paint.setPathEffect(new DashPathEffect(new float[]{dp(5),dp(6)},0));
                c.drawPath(arc,paint);paint.setPathEffect(null);paint.setStyle(Paint.Style.FILL);
            }
        };
        pane.addView(background,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(13),dp(8),dp(6),0);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        TextView home=roundShortcut("⌂",v->radialAction(()->{
            Intent i=new Intent(this,MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        }));
        head.addView(home,new LinearLayout.LayoutParams(dp(51),dp(51)));
        TextView gear=roundShortcut("⚙",v->radialAction(()->openMouseSettings()));
        LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(dp(51),dp(51));gp.leftMargin=dp(12);
        head.addView(gear,gp);
        TextView close=roundShortcut("×",v->closeRadialMenu());
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(40),dp(40));cp.leftMargin=dp(12);
        head.addView(close,cp);
        content.addView(head);View space=new View(this);
        content.addView(space,new LinearLayout.LayoutParams(1,dp(4)));
        int rowHeight=Math.max(dp(77),Math.min(dp(112),(height-dp(92))/3));
        addRadialRow(content,rowHeight,
                new String[]{"▤","Configurações\nde Keymap","✎","Editar keymap"},
                ()->radialAction(()->openKeymapDetails()),
                ()->radialAction(()->openEditor()));
        addRadialRow(content,rowHeight,
                new String[]{"⌨","Mapeamento\nde Teclas","▣","Digitação no\nteclado"},
                ()->radialAction(()->openPicker()),
                ()->radialAction(()->openTypingPanel()));
        addRadialRow(content,rowHeight,
                new String[]{"◉","Controle\ndo mouse","⊕","Câmera X/Y"},
                ()->radialAction(()->openMouseSettings()),
                ()->radialAction(()->openCameraSettings()));
        FrameLayout.LayoutParams pos=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP|Gravity.LEFT);
        pane.addView(content,pos);
        radialMenu=pane;
        add(radialMenu,params(width,height,Gravity.TOP|Gravity.LEFT,0,0));
    }
    private TextView roundShortcut(String glyph,View.OnClickListener action) {
        TextView b=text(glyph,30,0xFFF4F4FF);
        b.setGravity(Gravity.CENTER);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setBackground(shape(0xFF20275D,0xFF838FFF,50));
        b.setOnClickListener(action);return b;
    }
    private void addRadialRow(LinearLayout list,int height,String[] a,Runnable first,Runnable second) {
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.TOP|Gravity.LEFT);
        HexAction l=new HexAction(a[0],a[1],first);
        HexAction r=new HexAction(a[2],a[3],second);
        row.addView(l,new LinearLayout.LayoutParams(dp(112),height));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(112),height);p.leftMargin=dp(6);
        row.addView(r,p);list.addView(row);
    }
    private class HexAction extends LinearLayout {
        HexAction(String glyph,String title,Runnable action) {
            super(MapperService.this);setOrientation(VERTICAL);setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
            View hex=new View(MapperService.this){
                Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
                @Override protected void onDraw(Canvas c) {
                    super.onDraw(c);float x=getWidth()/2f,y=getHeight()/2f;
                    float radius=Math.min(x,y)-dp(3);
                    Path path=new Path();
                    for(int i=0;i<6;i++){
                        double a=Math.PI/3*i-Math.PI/2;
                        float px=x+(float)Math.cos(a)*radius,py=y+(float)Math.sin(a)*radius;
                        if(i==0)path.moveTo(px,py);else path.lineTo(px,py);
                    }path.close();
                    paint.setStyle(Paint.Style.FILL);paint.setColor(0xFF111843);c.drawPath(path,paint);
                    paint.setStyle(Paint.Style.STROKE);paint.setColor(0xFFA1A9FF);
                    paint.setStrokeWidth(dp(3));c.drawPath(path,paint);
                    paint.setStyle(Paint.Style.FILL);paint.setColor(0xFFF5F5FF);
                    paint.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));paint.setTextSize(dp(27));
                    paint.setTextAlign(Paint.Align.CENTER);
                    Paint.FontMetrics fm=paint.getFontMetrics();
                    c.drawText(glyph,x,y-(fm.ascent+fm.descent)/2,paint);
                }
            };
            addView(hex,new LinearLayout.LayoutParams(dp(58),dp(58)));
            TextView label=text(title,11,0xFFF2F4FF);label.setGravity(Gravity.CENTER);
            label.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            addView(label,new LinearLayout.LayoutParams(dp(105),-2));
            setOnClickListener(v->action.run());
        }
    }
    private void openKeymapDetails() {
        if(gamePkg==null)return;
        remove(cameraPanel);
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18),dp(20),dp(18),dp(18));
        panel.setBackground(shape(0xF9141A43,0xFF7B88F6,22));
        TextView title=text("▤  CONFIGURAÇÕES DE KEYMAP",16,0xFFFFFFFF);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);panel.addView(title);
        TextView sum=text("Jogo: "+gamePkg+"\n\n"+controls.size()+" botões no perfil local. Edite as posições, adicione teclas e salve seu keymap.",12,0xFFC6D3FF);
        sum.setPadding(0,dp(13),0,dp(16));panel.addView(sum);
        panel.addView(button("✎  EDITAR KEYMAP",true,v->{closeCameraPanel();openEditor();}));
        LinearLayout.LayoutParams space=new LinearLayout.LayoutParams(-1,dp(44));space.topMargin=dp(8);
        panel.addView(button("▣  SALVAR PERFIL",false,v->{save();Toast.makeText(this,"Keymap salvo",Toast.LENGTH_SHORT).show();closeCameraPanel();}),space);
        LinearLayout.LayoutParams close=new LinearLayout.LayoutParams(-1,dp(43));close.topMargin=dp(8);
        panel.addView(button("FECHAR",false,v->closeCameraPanel()),close);
        cameraPanel=panel;add(cameraPanel,params(dp(330),-2,Gravity.CENTER,0,0));syncMouseMode();
    }
    private void openTypingPanel() {
        remove(cameraPanel);
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18),dp(19),dp(18),dp(18));
        panel.setBackground(shape(0xF9141A43,0xFF7B88F6,22));
        TextView title=text("⌨  DIGITAÇÃO NO TECLADO",16,0xFFFFFFFF);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);panel.addView(title);
        TextView note=text("Para conversar ou escrever, use o campo de texto do jogo e um teclado físico ou virtual. A disponibilidade depende de cada jogo e do Android.",12,0xFFD2D9FF);
        note.setPadding(0,dp(12),0,dp(12));panel.addView(note);
        panel.addView(button("CONFIGURAR TECLADOS DO ANDROID",true,v->{
            closeCameraPanel();
            Intent i=new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);
        }));
        LinearLayout.LayoutParams close=new LinearLayout.LayoutParams(-1,dp(44));close.topMargin=dp(9);
        panel.addView(button("FECHAR",false,v->closeCameraPanel()),close);
        cameraPanel=panel;add(cameraPanel,params(dp(330),-2,Gravity.CENTER,0,0));syncMouseMode();
    }
    private void buildToolbar() {
        remove(toolbar);
        HorizontalScrollView scroll=new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setFillViewport(true);
        scroll.setBackground(shape(0xEF0D1B2A,0xFF41625F,15));
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(7),dp(8),dp(7));
        toolbarButton(row,editorOpen?"✓ PRONTO":"✎ EDITAR",true,v->{if(editorOpen){save();closeEditor();}else openEditor();});
        toolbarButton(row,"＋ TECLA",false,v->openPicker());
        toolbarButton(row,"⌨ ATALHO",false,v->openShortcutPicker());
        toolbarButton(row,"◎ CÂMERA X/Y",false,v->openCameraSettings());
        toolbarButton(row,"🖱 MOUSE",false,v->openMouseSettings());
        if(editorOpen) {
            toolbarButton(row,"⇄ MODO",false,v->toggleSelectedMode());
            toolbarButton(row,"✕ EXCLUIR",false,v->removeSelected());
        }
        toolbarButton(row,"▣ SALVAR",false,v->{save();Toast.makeText(this,"Perfil salvo",Toast.LENGTH_SHORT).show();});
        toolbarButton(row,"FECHAR",false,v->{save();closeEditor();menuOpen=false;remove(toolbar);toolbar=null;remove(radialMenu);radialMenu=null;syncMouseMode();});
        scroll.addView(row);toolbar=scroll;
        add(toolbar,params(-1,dp(59),Gravity.TOP,0,dp(14)));
    }
    private void toolbarButton(LinearLayout row,String label,boolean primary,View.OnClickListener onClick) {
        TextView v=button(label,primary,onClick);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(41));p.rightMargin=dp(6);row.addView(v,p);
    }
    private void openEditor() {
        if(gamePkg==null||wm==null)return;
        remove(radialMenu);radialMenu=null;
        if(!editorOpen) {
            editorOpen=true;input.clear();selected=-1;syncMouseMode();
            editor=new EditorView();
            add(editor,params(-1,-1,Gravity.TOP|Gravity.LEFT,0,0));
        }
        menuOpen=true;
        // Barra acima da camada de edição.
        buildToolbar();
        if(bubble!=null) {
            // Reempilha a bolha acima da área de edição.
            View old=bubble;WindowManager.LayoutParams oldParams=(WindowManager.LayoutParams)old.getLayoutParams();
            if(oldParams!=null){remove(old);add(old,oldParams);}
        }
        if(cameraToggle!=null) {
            View old=cameraToggle;WindowManager.LayoutParams oldParams=(WindowManager.LayoutParams)old.getLayoutParams();
            if(oldParams!=null){remove(old);add(old,oldParams);}
        }
        Toast.makeText(this,"Arraste controles ou toque duas vezes para adicionar uma tecla",Toast.LENGTH_SHORT).show();
    }
    private void closeEditor() {
        editorOpen=false;selected=-1;
        closeCameraPanel();
        remove(picker);picker=null;remove(shortcutPicker);shortcutPicker=null;
        waitingHotkey=false;pendingAddX=Float.NaN;pendingAddY=Float.NaN;
        remove(editor);editor=null;
        remove(toolbar);toolbar=null;
        syncMouseMode();
        if(menuOpen)buildRadialMenu();
    }
    private void save() {
        if(gamePkg!=null)Store.save(this,gamePkg,controls);
    }
    private void toggleSelectedMode() {
        if(selected<0||selected>=controls.size()) {Toast.makeText(this,"Selecione um botão primeiro",Toast.LENGTH_SHORT).show();return;}
        Mapping m=controls.get(selected);
        if(m.isAim()||m.isJoystick()) {Toast.makeText(this,"Este controle tem modo fixo",Toast.LENGTH_SHORT).show();return;}
        m.hold=!m.hold;save();if(editor!=null)editor.invalidate();
        Toast.makeText(this,m.hold?"Modo SEGURAR":"Modo TOQUE",Toast.LENGTH_SHORT).show();
    }
    private void removeSelected() {
        if(selected<0||selected>=controls.size()) {Toast.makeText(this,"Selecione um botão primeiro",Toast.LENGTH_SHORT).show();return;}
        controls.remove(selected);selected=-1;save();if(editor!=null)editor.invalidate();
    }

    private void closeCameraPanel() {
        remove(cameraPanel);cameraPanel=null;syncMouseMode();
    }
    private void openMouseSettings() {
        if(gamePkg==null)return;
        showSettingsPanel(true);
    }
    private void openCameraSettings() {
        if(gamePkg==null)return;
        if(find(Mapping.AIM)==null) {
            Toast.makeText(this,"Adicione o controle CÂMERA primeiro",Toast.LENGTH_LONG).show();
            return;
        }
        showSettingsPanel(false);
    }
    private void showSettingsPanel(boolean mouseOnly) {
        closeCameraPanel();
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20),dp(18),dp(20),dp(17));
        panel.setBackground(shape(0xFC111E30,0xFF496F81,22));panel.setElevation(dp(18));
        TextView title=text(mouseOnly?"🖱  VELOCIDADE DO MOUSE":"◎  CONFIGURAÇÕES DA CÂMERA",17,WHITE);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);panel.addView(title);
        TextView hint=text(mouseOnly?"Ajustes do Vortex. Não altera a velocidade do cursor do sistema.":
                "Toque no ponto CÂMERA e ajuste a resposta do movimento neste jogo.",12,0xFFA8C6D7);
        LinearLayout.LayoutParams hintLp=new LinearLayout.LayoutParams(-1,-2);hintLp.topMargin=dp(8);hintLp.bottomMargin=dp(12);
        panel.addView(hint,hintLp);
        if(mouseOnly) {
            settingSlider(panel,"VELOCIDADE DO MOUSE",.25f,3f,Store.mouseSpeed(this),"x",
                    value->Store.setMouseSpeed(this,value));
            settingSlider(panel,"SUAVIZAÇÃO",0f,.80f,Store.smoothing(this),"%",
                    value->Store.setSmoothing(this,value));
            TextView hotkey=button("⌨ SUSPENDER MOUSE: "+hotkeyLabel(),false,v->openShortcutPicker());
            LinearLayout.LayoutParams hk=new LinearLayout.LayoutParams(-1,dp(45));hk.topMargin=dp(12);
            panel.addView(hotkey,hk);
            TextView note=text("A velocidade acima controla o movimento no modo CÂMERA. A velocidade da seta do Android usa autorização separada na tela inicial. O atalho é por jogo.",11,0xFF91B2C8);
            panel.addView(note);
        }else {
            settingSlider(panel,"CÂMERA X  •  HORIZONTAL",.2f,4f,Store.cameraX(this,gamePkg),"x",
                    value->Store.setCameraX(this,gamePkg,value));
            settingSlider(panel,"CÂMERA Y  •  VERTICAL",.2f,4f,Store.cameraY(this,gamePkg),"x",
                    value->Store.setCameraY(this,gamePkg,value));
            settingSlider(panel,"PUXADA PARA CIMA",0f,2.5f,Store.pullUp(this,gamePkg),"x",
                    value->Store.setPullUp(this,gamePkg,value));
            TextView note=text("A puxada aumenta a resposta somente quando você move fisicamente o mouse para cima. Não é mira automática.",11,0xFF91B2C8);
            panel.addView(note);
        }
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView reset=button("REDEFINIR",false,v->{
            if(mouseOnly) {Store.setMouseSpeed(this,1f);Store.setSmoothing(this,.10f);}
            else {Store.setCameraX(this,gamePkg,1f);Store.setCameraY(this,gamePkg,1f);Store.setPullUp(this,gamePkg,0f);}
            showSettingsPanel(mouseOnly);
        });
        actions.addView(reset,new LinearLayout.LayoutParams(0,dp(43),1));
        TextView done=button("✓  APLICAR",true,v->closeCameraPanel());
        LinearLayout.LayoutParams d=new LinearLayout.LayoutParams(0,dp(43),1);d.leftMargin=dp(10);
        actions.addView(done,d);
        LinearLayout.LayoutParams actLp=new LinearLayout.LayoutParams(-1,-2);actLp.topMargin=dp(14);
        panel.addView(actions,actLp);
        cameraPanel=panel;
        syncMouseMode();
        // Painel compacto, nao requer permissao de overlay convencional.
        add(cameraPanel,params(dp(350),-2,Gravity.CENTER,0,0));
    }
    private interface FloatSetter {void set(float value);}
    private void settingSlider(LinearLayout panel,String caption,float min,float max,
                               float initial,String unit,FloatSetter setter) {
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        TextView name=text(caption,12,0xFFD1E6F3);name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView valueText=text("",14,MINT);valueText.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        row.addView(valueText);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(10);
        panel.addView(row,rp);
        SeekBar bar=new SeekBar(this);bar.setMax(100);bar.setProgressTintList(ColorStateList.valueOf(MINT));
        bar.setThumbTintList(ColorStateList.valueOf(MINT));
        bar.setProgress(Math.round((initial-min)*100f/(max-min)));
        java.util.function.Consumer<Float> update=val->{
            valueText.setText(unit.equals("%")?String.format(java.util.Locale.US,"%.0f%%",val*100f):
                    String.format(java.util.Locale.US,"%.2fx",val));
        };
        update.accept(initial);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar b,int progress,boolean fromUser){
                if(!fromUser)return;
                float v=min+(max-min)*progress/100f;setter.set(v);update.accept(v);
            }
            @Override public void onStartTrackingTouch(SeekBar b){}
            @Override public void onStopTrackingTouch(SeekBar b){}
        });
        panel.addView(bar,new LinearLayout.LayoutParams(-1,dp(35)));
    }

    private String hotkeyLabel() {
        int key=Store.suspendKey(this,gamePkg);
        if(key==KeyEvent.KEYCODE_UNKNOWN)return "SEM ATALHO";
        return KeyEvent.keyCodeToString(key).replace("KEYCODE_", "");
    }
    private void closeShortcutPicker() {
        waitingHotkey=false;
        remove(shortcutPicker);shortcutPicker=null;
        syncMouseMode();
    }
    private void chooseHotkey(int code) {
        if(gamePkg==null)return;
        Store.setSuspendKey(this,gamePkg,code);
        closeShortcutPicker();
        Toast.makeText(this,"Suspender mouse: "+hotkeyLabel(),Toast.LENGTH_SHORT).show();
        if(cameraPanel!=null)showSettingsPanel(true);
    }
    private void openShortcutPicker() {
        if(gamePkg==null)return;
        closeShortcutPicker();
        waitingHotkey=true;syncMouseMode();
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(15),dp(15),dp(15),dp(13));
        panel.setBackground(shape(0xFB101D30,0xFF426A72,19));
        TextView header=text("⌨  TECLA PARA SUSPENDER MOUSE",15,MINT);
        header.setTypeface(Typeface.DEFAULT,Typeface.BOLD);panel.addView(header);
        TextView desc=text("Escolha uma tecla abaixo ou pressione uma tecla no teclado físico. Tecla reservada não será enviada ao jogo.",11,0xFFB2CBDA);
        desc.setPadding(0,dp(6),0,dp(10));panel.addView(desc);
        ScrollView sc=new ScrollView(this);GridLayout grid=new GridLayout(this);
        grid.setColumnCount(4);
        List<Integer> codes=new ArrayList<>();
        for(int c=KeyEvent.KEYCODE_F1;c<=KeyEvent.KEYCODE_F12;c++)codes.add(c);
        for(int c=KeyEvent.KEYCODE_A;c<=KeyEvent.KEYCODE_Z;c++)codes.add(c);
        for(int c=KeyEvent.KEYCODE_0;c<=KeyEvent.KEYCODE_9;c++)codes.add(c);
        codes.add(KeyEvent.KEYCODE_TAB);codes.add(KeyEvent.KEYCODE_CAPS_LOCK);
        codes.add(KeyEvent.KEYCODE_SHIFT_LEFT);codes.add(KeyEvent.KEYCODE_CTRL_LEFT);
        codes.add(KeyEvent.KEYCODE_ALT_LEFT);codes.add(KeyEvent.KEYCODE_SPACE);
        for(int key:codes) {
            TextView cell=button(KeyEvent.keyCodeToString(key).replace("KEYCODE_", ""),
                    key==Store.suspendKey(this,gamePkg),v->chooseHotkey(key));
            GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=dp(69);lp.height=dp(41);
            lp.setMargins(dp(3),dp(3),dp(3),dp(3));grid.addView(cell,lp);
        }
        sc.addView(grid);panel.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        TextView none=button("DESATIVAR ATALHO",false,v->chooseHotkey(KeyEvent.KEYCODE_UNKNOWN));
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(42));np.topMargin=dp(7);
        panel.addView(none,np);
        TextView cancel=button("CANCELAR",true,v->closeShortcutPicker());
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(42));cp.topMargin=dp(7);
        panel.addView(cancel,cp);
        shortcutPicker=panel;
        add(shortcutPicker,params(dp(338),dp(435),Gravity.CENTER,0,0));
    }
    private void openPicker() { openPickerAt(Float.NaN,Float.NaN); }
    private void openPickerAt(float atX,float atY) {
        pendingAddX=atX;pendingAddY=atY;
        if(gamePkg==null)return;
        openEditor();remove(picker);picker=null;
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(13),dp(13),dp(13),dp(12));box.setBackground(shape(0xF7112030,0xFF578579,20));
        TextView heading=text("＋  ESCOLHA UMA TECLA",14,MINT);heading.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        box.addView(heading);
        TextView hint=text(Float.isNaN(pendingAddX)?
                "Escolha o botão ou pressione uma tecla no teclado físico. Depois arraste-o.":
                "Toque na letra ou pressione uma tecla: o botão ficará onde você tocou duas vezes.",11,0xFFC1D3E2);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(6);hp.bottomMargin=dp(10);box.addView(hint,hp);
        ScrollView sc=new ScrollView(this);
        GridLayout grid=new GridLayout(this);grid.setColumnCount(4);
        List<Integer> keys=new ArrayList<>();List<String> labels=new ArrayList<>();
        int[] specials={Mapping.JOYSTICK,Mapping.AIM,Mapping.MOUSE_LEFT,Mapping.MOUSE_RIGHT,
                KeyEvent.KEYCODE_SPACE,KeyEvent.KEYCODE_SHIFT_LEFT,KeyEvent.KEYCODE_CTRL_LEFT,
                KeyEvent.KEYCODE_TAB,KeyEvent.KEYCODE_ENTER,KeyEvent.KEYCODE_CAPS_LOCK};
        String[] names={"WASD","CÂMERA","M1","M2","ESPAÇO","SHIFT","CTRL","TAB","ENTER","CAPS"};
        for(int i=0;i<specials.length;i++){keys.add(specials[i]);labels.add(names[i]);}
        for(int c=KeyEvent.KEYCODE_A;c<=KeyEvent.KEYCODE_Z;c++){
            keys.add(c);labels.add(KeyEvent.keyCodeToString(c).replace("KEYCODE_",""));
        }
        for(int c=KeyEvent.KEYCODE_0;c<=KeyEvent.KEYCODE_9;c++){
            keys.add(c);labels.add(KeyEvent.keyCodeToString(c).replace("KEYCODE_",""));
        }
        for(int i=0;i<keys.size();i++) {
            final int code=keys.get(i);final String label=labels.get(i);
            TextView cell=button(label,false,v->addMapping(code,label));
            GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=dp(68);p.height=dp(43);
            p.setMargins(dp(3),dp(3),dp(3),dp(3));grid.addView(cell,p);
        }
        sc.addView(grid);box.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        TextView cancel=button("VOLTAR",true,v->{remove(picker);picker=null;pendingAddX=Float.NaN;pendingAddY=Float.NaN;});
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(42));cp.topMargin=dp(10);box.addView(cancel,cp);
        picker=box;add(picker,params(dp(330),dp(408),Gravity.CENTER,0,0));
    }
    private void addMapping(int code,String label) {
        if(code==Mapping.JOYSTICK||code==Mapping.AIM) {
            for(Mapping m:controls)if(m.code==code){selected=controls.indexOf(m);remove(picker);picker=null;
                pendingAddX=Float.NaN;pendingAddY=Float.NaN;
                if(editor!=null)editor.invalidate();Toast.makeText(this,"Controle selecionado: arraste-o",Toast.LENGTH_SHORT).show();return;}
        }
        boolean hold=(code==KeyEvent.KEYCODE_W||code==KeyEvent.KEYCODE_A||code==KeyEvent.KEYCODE_S||
                code==KeyEvent.KEYCODE_D||code==KeyEvent.KEYCODE_SHIFT_LEFT||code==KeyEvent.KEYCODE_CTRL_LEFT||code==Mapping.JOYSTICK);
        float x=code==Mapping.JOYSTICK?.20f:.55f;
        float y=code==Mapping.JOYSTICK?.77f:.50f;
        if(code==Mapping.AIM){x=.69f;y=.38f;}
        if(!Float.isNaN(pendingAddX) && !Float.isNaN(pendingAddY)) {
            x=pendingAddX;y=pendingAddY;
        }
        pendingAddX=Float.NaN;pendingAddY=Float.NaN;
        controls.add(new Mapping(code,label,x,y,hold));selected=controls.size()-1;
        remove(picker);picker=null;save();if(editor!=null)editor.invalidate();
        Toast.makeText(this,"Arraste "+label+" até o controle desejado",Toast.LENGTH_SHORT).show();
    }
    private class EditorView extends View {
        final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        int dragging=-1;
        boolean moved=false;
        float touchStartX,touchStartY;
        long previousTapMs=0L;
        float previousTapX=0f,previousTapY=0f;
        EditorView(){super(MapperService.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(0x59030B16);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));paint.setColor(0x4059B5B5);
            for(int gx=dp(25);gx<getWidth();gx+=dp(65)) c.drawLine(gx,0,gx,getHeight(),paint);
            for(int gy=dp(25);gy<getHeight();gy+=dp(65)) c.drawLine(0,gy,getWidth(),gy,paint);
            paint.setStyle(Paint.Style.FILL);paint.setColor(0xF0102738);
            c.drawRoundRect(dp(7),dp(76),Math.min(getWidth()-dp(7),dp(355)),dp(116),dp(12),dp(12),paint);
            paint.setColor(MINT);paint.setTextSize(dp(11));paint.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText("2 TOQUES = NOVO BOTÃO  •  ARRASTE = MOVER",dp(15),dp(101),paint);
            float w=getWidth(),h=getHeight();
            for(int i=0;i<controls.size();i++) {
                Mapping m=controls.get(i);float cx=m.x*w,cy=m.y*h;
                float radius=dp(m.isJoystick()?40:32);
                paint.setStyle(Paint.Style.FILL);paint.setColor(i==selected?0xE87EF5CF:0xC91C3446);
                c.drawCircle(cx,cy,radius,paint);
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(i==selected?3:2));
                paint.setColor(i==selected?Color.WHITE:MINT);c.drawCircle(cx,cy,radius,paint);
                if(m.isAim()) {
                    paint.setStrokeWidth(dp(1));
                    c.drawLine(cx-radius-dp(7),cy,cx-radius+dp(7),cy,paint);
                    c.drawLine(cx+radius-dp(7),cy,cx+radius+dp(7),cy,paint);
                    c.drawLine(cx,cy-radius-dp(7),cx,cy-radius+dp(7),paint);
                    c.drawLine(cx,cy+radius-dp(7),cx,cy+radius+dp(7),paint);
                }
                if(m.isJoystick()){paint.setColor(0x887EF5CF);c.drawCircle(cx,cy,dp(51),paint);}
                paint.setStyle(Paint.Style.FILL);paint.setColor(i==selected?BG:WHITE);
                paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextAlign(Paint.Align.CENTER);
                paint.setTextSize(dp(m.label.length()>4?11:14));
                c.drawText(m.label,cx,cy+dp(1),paint);
                paint.setTextSize(dp(9));
                c.drawText(m.isJoystick()?"ANALÓGICO":m.isAim()?"AJUSTAR X / Y":m.hold?"SEGURAR":"TOQUE",cx,cy+dp(14),paint);
            }
            paint.setTextAlign(Paint.Align.LEFT);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            int action=e.getActionMasked();
            if(action==MotionEvent.ACTION_DOWN) {
                dragging=-1;moved=false;touchStartX=e.getX();touchStartY=e.getY();float best=dp(58);
                for(int i=controls.size()-1;i>=0;i--) {
                    Mapping m=controls.get(i);
                    float dx=m.x*getWidth()-e.getX(),dy=m.y*getHeight()-e.getY();
                    float dist=(float)Math.sqrt(dx*dx+dy*dy);
                    if(dist<best){best=dist;dragging=i;}
                }
                if(dragging>=0){selected=dragging;invalidate();}return true;
            }
            if(action==MotionEvent.ACTION_MOVE && dragging>=0) {
                if(Math.hypot(e.getX()-touchStartX,e.getY()-touchStartY)<dp(9) && !moved)return true;
                moved=true;
                Mapping m=controls.get(dragging);
                m.x=Math.max(.05f,Math.min(.95f,e.getX()/Math.max(1f,getWidth())));
                m.y=Math.max(.09f,Math.min(.95f,e.getY()/Math.max(1f,getHeight())));
                invalidate();return true;
            }
            if(action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_CANCEL) {
                if(dragging>=0) {
                    boolean cameraTap=!moved && controls.get(dragging).isAim() && action==MotionEvent.ACTION_UP;
                    if(moved)save();
                    if(cameraTap)openCameraSettings();
                    previousTapMs=0L;
                } else if(action==MotionEvent.ACTION_UP && !moved) {
                    long now=SystemClock.uptimeMillis();
                    if(previousTapMs>0 && now-previousTapMs<=330 &&
                            Math.hypot(e.getX()-previousTapX,e.getY()-previousTapY)<=dp(44)) {
                        previousTapMs=0L;
                        float nx=Math.max(.05f,Math.min(.95f,e.getX()/Math.max(1f,getWidth())));
                        float ny=Math.max(.09f,Math.min(.95f,e.getY()/Math.max(1f,getHeight())));
                        openPickerAt(nx,ny);
                    } else {
                        previousTapMs=now;previousTapX=e.getX();previousTapY=e.getY();
                    }
                }
                dragging=-1;return true;
            }
            return true;
        }
    }

    @Override protected boolean onKeyEvent(KeyEvent e) {
        if(gamePkg==null)return false;
        int code=e.getKeyCode();boolean down=e.getAction()==KeyEvent.ACTION_DOWN;
        // Quando o seletor esta aberto, a proxima tecla fisica define o atalho.
        if(waitingHotkey) {
            if(down && e.getRepeatCount()==0 && code!=KeyEvent.KEYCODE_BACK &&
                    code!=KeyEvent.KEYCODE_HOME && code!=KeyEvent.KEYCODE_POWER &&
                    code!=KeyEvent.KEYCODE_VOLUME_UP && code!=KeyEvent.KEYCODE_VOLUME_DOWN)
                chooseHotkey(code);
            return true;
        }
        if(picker!=null && editorOpen && down && e.getRepeatCount()==0 &&
                code!=KeyEvent.KEYCODE_BACK && code!=KeyEvent.KEYCODE_HOME &&
                code!=KeyEvent.KEYCODE_POWER) {
            addMapping(code,KeyEvent.keyCodeToString(code).replace("KEYCODE_", ""));
            return true;
        }
        if(editorOpen||cameraPanel!=null)return false;
        int hotkey=Store.suspendKey(this,gamePkg);
        if(hotkey!=KeyEvent.KEYCODE_UNKNOWN && code==hotkey) {
            if(down&&e.getRepeatCount()==0)toggleCameraCapture();
            return true;
        }
        if(e.getAction()!=KeyEvent.ACTION_DOWN && e.getAction()!=KeyEvent.ACTION_UP)return false;
        for(Mapping m:controls) {
            if(m.isJoystick() && (code==KeyEvent.KEYCODE_W||code==KeyEvent.KEYCODE_A||
                    code==KeyEvent.KEYCODE_S||code==KeyEvent.KEYCODE_D)) {
                if(e.getRepeatCount()==0||!down)input.direction(code,down);
                return true;
            }
        }
        boolean found=false;
        for(Mapping m:controls) {
            if(m.code==code && code>=0) {
                found=true;
                if(e.getRepeatCount()==0||!down)input.button(m,down);
            }
        }
        return found;
    }
    public void onPointerConfigChanged() {
        if(gamePkg==null){PointerSpeedController.restore(this);return;}
        if(Store.autoSystemPointer(this))PointerSpeedController.applyForGame(this);
        else PointerSpeedController.restore(this);
    }
    public void syncMouseMode() {
        if(Build.VERSION.SDK_INT<34)return;
        AccessibilityServiceInfo cfg=getServiceInfo();if(cfg==null)return;
        boolean on=gamePkg!=null && cameraCaptured && !editorOpen && !menuOpen
                && cameraPanel==null && Store.mouseEnabled(this);
        cfg.setMotionEventSources(on?InputDevice.SOURCE_MOUSE:0);
        setServiceInfo(cfg);
        lastMouseX=Float.NaN;lastMouseY=Float.NaN;
        smoothedDx=0f;smoothedDy=0f;
        pendingAimDx=0f;pendingAimDy=0f;lastMouseMotionMs=0L;
        // Nunca mantenha um botao anterior pressionado depois de mudar o modo.
        for(int code:new HashSet<>(mouseDown))mouseButton(code,false);
    }
    @Override public void onMotionEvent(MotionEvent e) {
        if(gamePkg==null||editorOpen||menuOpen||cameraPanel!=null||!cameraCaptured||!Store.mouseEnabled(this))return;
        if(!e.isFromSource(InputDevice.SOURCE_MOUSE))return;
        int action=e.getActionMasked();
        // IMPORTANTE: HOVER_MOVE/HOVER_ENTER/HOVER_EXIT e MOVE NUNCA sao cliques.
        // ACTION_DOWN sem bit de botao pressionado ocorre em alguns adaptadores OTG
        // durante movimentos/hover. A implementacao anterior o interpretava como M1.
        // Apenas transicoes confirmadas de botao podem executar um controle.
        if(action==MotionEvent.ACTION_BUTTON_PRESS || action==MotionEvent.ACTION_BUTTON_RELEASE) {
            int button=e.getActionButton();
            int code=(button==MotionEvent.BUTTON_PRIMARY)?Mapping.MOUSE_LEFT:
                    (button==MotionEvent.BUTTON_SECONDARY)?Mapping.MOUSE_RIGHT:0;
            if(code!=0)mouseButton(code,action==MotionEvent.ACTION_BUTTON_PRESS);
            return;
        }
        if(action==MotionEvent.ACTION_DOWN) {
            // Fallback para dispositivos que enviam DOWN sem BUTTON_PRESS.
            // Sem BUTTON_PRIMARY/SECONDARY confirmado, nao simule clique algum.
            int state=e.getButtonState();
            if((state & MotionEvent.BUTTON_PRIMARY)!=0)mouseButton(Mapping.MOUSE_LEFT,true);
            if((state & MotionEvent.BUTTON_SECONDARY)!=0)mouseButton(Mapping.MOUSE_RIGHT,true);
            return;
        }
        if(action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_CANCEL) {
            for(int code:new HashSet<>(mouseDown))mouseButton(code,false);
            return;
        }
        if(action!=MotionEvent.ACTION_HOVER_MOVE && action!=MotionEvent.ACTION_MOVE)return;

        float x=e.getX(),y=e.getY();
        if(!Float.isNaN(lastMouseX)) {
            float dx=x-lastMouseX,dy=y-lastMouseY;
            long now=SystemClock.uptimeMillis();
            Point screen=screenSize();
            // Ignore saltos de cursor causados por bordas, retomadas ou troca de tela.
            if(Math.abs(dx)>screen.x*.35f || Math.abs(dy)>screen.y*.35f) {
                pendingAimDx=0f;pendingAimDy=0f;
                smoothedDx=0f;smoothedDy=0f;
            } else if(Math.abs(dx)+Math.abs(dy)>=1f) {
                if(lastMouseMotionMs!=0 && now-lastMouseMotionMs>180) {
                    pendingAimDx=0f;pendingAimDy=0f;
                    smoothedDx=0f;smoothedDy=0f;
                }
                lastMouseMotionMs=now;
                float smoothing=Store.smoothing(this);
                smoothedDx=smoothedDx*smoothing+dx*(1f-smoothing);
                smoothedDy=smoothedDy*smoothing+dy*(1f-smoothing);
                float global=Store.mouseSpeed(this);
                float ax=smoothedDx*global*Store.cameraX(this,gamePkg);
                float ay=smoothedDy*global*Store.cameraY(this,gamePkg);
                if(ay<0)ay+=smoothedDy*global*Store.pullUp(this,gamePkg);
                pendingAimDx+=ax;pendingAimDy+=ay;
                // Um swipe de poucos pixels pode ser interpretado como um TAP
                // pelo jogo. Aguarde deslocamento real suficiente antes de enviar.
                float minMove=dp(8f)/1.45f;
                if(now-lastAimTime>=16 && Math.hypot(pendingAimDx,pendingAimDy)>=minMove) {
                    for(Mapping m:controls)if(m.isAim()) {
                        input.aim(m,pendingAimDx,pendingAimDy);
                        lastAimTime=now;
                        pendingAimDx=0f;pendingAimDy=0f;
                        break;
                    }
                }
            }
        }
        lastMouseX=x;lastMouseY=y;
    }
    private void mouseButton(int code,boolean down) {
        // Alguns mouses emitem BUTTON_PRESS e DOWN para o mesmo clique.
        if(down&&!mouseDown.add(code))return;
        if(!down&&!mouseDown.remove(code))return;
        for(Mapping m:controls)if(m.code==code)input.button(m,down);
    }
    private Point screenSize() {
        Point p=new Point();wm.getDefaultDisplay().getRealSize(p);return p;
    }
    private PointF position(Mapping m) {
        Point s=screenSize();return new PointF(s.x*m.x,s.y*m.y);
    }
    private Mapping find(int code) {
        for(Mapping m:controls)if(m.code==code)return m;
        return null;
    }
    private static class Tap {
        final float x,y,ex,ey;final boolean swipe;
        Tap(float x,float y,float ex,float ey,boolean swipe) {
            this.x=x;this.y=y;this.ex=ex;this.ey=ey;this.swipe=swipe;
        }
    }
    /**
     * Serializa as chamadas a dispatchGesture. Suporta até seis dedos em hold simultâneos;
     * toques adicionais interrompem brevemente os holds (limitação do Android).
     */
    private final class InputSequencer {
        private final Set<Integer> pressed=new HashSet<>();
        private final Set<Integer> directions=new HashSet<>();
        private Map<Integer,GestureDescription.StrokeDescription> previous=new HashMap<>();
        private Map<Integer,PointF> endpoints=new HashMap<>();
        private final ArrayDeque<Tap> taps=new ArrayDeque<>();
        private boolean busy=false;
        void clear() {
            pressed.clear();directions.clear();previous.clear();endpoints.clear();taps.clear();
            // Uma chamada em curso termina/cancela naturalmente.
        }
        void button(Mapping m,boolean down) {
            if(m.hold) {
                if(down)pressed.add(m.code);else pressed.remove(m.code);
                next();
            } else if(down){
                if(taps.size()<16) {
                    PointF p=position(m);taps.addFirst(new Tap(p.x,p.y,p.x,p.y,false));next();
                }
            }
        }
        void direction(int code,boolean down) {
            if(down)directions.add(code);else directions.remove(code);
            if(directions.isEmpty())pressed.remove(Mapping.JOYSTICK);
            else pressed.add(Mapping.JOYSTICK);
            next();
        }
        void aim(Mapping m,float dx,float dy) {
            if(taps.size()>2)return; // Descarte sob carga em vez de acumular atraso perceptivel.
            PointF p=position(m);
            float max=dp(125),scale=1.45f;
            float vx=Math.max(-max,Math.min(max,dx*scale));
            float vy=Math.max(-max,Math.min(max,dy*scale));
            // Nao envie gestos de deslocamento quase nulo: em alguns jogos,
            // isso equivale a um toque simples no ponto de camera.
            if(Math.hypot(vx,vy)<dp(8))return;
            Point screen=screenSize();
            float endX=Math.max(dp(4),Math.min(screen.x-dp(4),p.x+vx));
            float endY=Math.max(dp(4),Math.min(screen.y-dp(4),p.y+vy));
            taps.add(new Tap(p.x,p.y,endX,endY,true));next();
        }
        PointF joystickTarget(Mapping m) {
            PointF center=position(m);int h=0,v=0;
            if(directions.contains(KeyEvent.KEYCODE_A))h--;
            if(directions.contains(KeyEvent.KEYCODE_D))h++;
            if(directions.contains(KeyEvent.KEYCODE_W))v--;
            if(directions.contains(KeyEvent.KEYCODE_S))v++;
            float r=dp(51);if(h!=0&&v!=0)r*=.7071f;
            return new PointF(center.x+h*r,center.y+v*r);
        }
        void next() {
            if(busy||gamePkg==null||editorOpen)return;
            if(!taps.isEmpty()) {
                previous.clear();endpoints.clear();
                GestureDescription.Builder b=new GestureDescription.Builder();
                int n=0;
                while(!taps.isEmpty()&&n++<4) {
                    Tap t=taps.removeFirst();Path path=new Path();path.moveTo(t.x,t.y);
                    if(t.swipe)path.lineTo(t.ex,t.ey);
                    b.addStroke(new GestureDescription.StrokeDescription(path,0,t.swipe?30:26,false));
                }
                send(b.build());return;
            }
            if(pressed.isEmpty()&&previous.isEmpty())return;
            GestureDescription.Builder builder=new GestureDescription.Builder();
            Map<Integer,GestureDescription.StrokeDescription> nextStrokes=new HashMap<>();
            Map<Integer,PointF> nextPoints=new HashMap<>();
            int count=0;
            for(Map.Entry<Integer,GestureDescription.StrokeDescription> en:previous.entrySet()) {
                if(count>=6)break;
                int code=en.getKey();
                Mapping m=find(code);
                PointF start=endpoints.get(code);
                if(start==null)continue;
                PointF dest=(code==Mapping.JOYSTICK&&m!=null)?joystickTarget(m):start;
                Path path=new Path();path.moveTo(start.x,start.y);
                if(start.x!=dest.x||start.y!=dest.y)path.lineTo(dest.x,dest.y);
                boolean keep=pressed.contains(code)&&m!=null;
                try {
                    GestureDescription.StrokeDescription continuation=en.getValue().continueStroke(path,0,keep?60:1,keep);
                    builder.addStroke(continuation);count++;
                    if(keep){nextStrokes.put(code,continuation);nextPoints.put(code,dest);}
                } catch(IllegalArgumentException ignored) {}
            }
            for(int code:new HashSet<>(pressed)) {
                if(count>=6)break;
                if(previous.containsKey(code))continue;
                Mapping m=find(code);if(m==null)continue;
                PointF start=position(m);
                PointF end=code==Mapping.JOYSTICK?joystickTarget(m):start;
                Path path=new Path();path.moveTo(start.x,start.y);
                if(end.x!=start.x||end.y!=start.y)path.lineTo(end.x,end.y);
                GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(path,0,60,true);
                builder.addStroke(stroke);nextStrokes.put(code,stroke);nextPoints.put(code,end);count++;
            }
            if(count==0){previous.clear();endpoints.clear();return;}
            previous=nextStrokes;endpoints=nextPoints;
            send(builder.build());
        }
        void send(GestureDescription g) {
            busy=true;
            boolean submitted=dispatchGesture(g,new GestureResultCallback(){
                @Override public void onCompleted(GestureDescription gesture){busy=false;next();}
                @Override public void onCancelled(GestureDescription gesture){
                    busy=false;previous.clear();endpoints.clear();
                    // Evita tentar injetar indefinidamente em jogos bloqueados.
                    handler.postDelayed(()->{if(gamePkg!=null)next();},45);
                }
            },handler);
            if(!submitted){busy=false;previous.clear();endpoints.clear();}
        }
    }
}
