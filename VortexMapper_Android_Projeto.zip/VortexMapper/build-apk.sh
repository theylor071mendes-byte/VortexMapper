#!/bin/sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo 'Gradle nao encontrado. Instale Gradle 8.9 e Android SDK 35 (ou use o workflow do GitHub Actions).'
  exit 1
fi
gradle :app:assembleDebug
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'
