# Vortex Mapper — Android (versão beta)

Projeto **nativo Android Java**, pronto para abrir no Android Studio ou VS Code com Gradle. Este arquivo ZIP contém o **código-fonte** e **não contém APK pré-compilado**. Para instalar no celular, compile o APK debug pelas instruções abaixo.

## Funções incluídas

- Encontra aplicativos com ícone na lista de apps instalados e permite adicioná-los como jogos.
- Salva separadamente cada perfil de botões por pacote Android (armazenamento local, sem contas nem servidor).
- Reconhece quando um jogo adicionado fica em primeiro plano, usando eventos de acessibilidade.
- Mostra **bolha flutuante “V”** sobre esse jogo, sem permissão SYSTEM_ALERT_WINDOW.
- Abre editor de botões por cima da tela; arraste círculos para posicionar as teclas onde os botões do jogo aparecem.
- Adiciona teclas físicas (incluindo SPACE/SHIFT/CTRL), mouse M1/M2, controle analógico WASD e ponto de mira experimental.
- Permite alternar entre **TOQUE** e **SEGURAR** para teclas comuns.
- Envia toques/deslizamentos por `AccessibilityService.dispatchGesture` quando eventos de teclas mapeadas são recebidos.
- No Android 14+ (API 34+), opção experimental de capturar eventos de mouse e convertê-los em gestos, incluindo movimento sobre a região MIRA. Desligada por padrão.
- Todos os dados ficam no dispositivo (SharedPreferences).

## Compilar no PC com Android Studio

1. Descompacte o projeto `VortexMapper`.
2. No **Android Studio**, selecione **Open** e abra a pasta raiz `VortexMapper` (não `app`).
3. Instale o **Android SDK Platform 35** e, caso necessário, configure **Gradle 8.9** e **JDK 17**. O projeto não inclui o JAR do Gradle Wrapper, por isso deve usar uma instalação local de Gradle no Android Studio.
4. Aguarde o sync, depois selecione **Build > Build APK(s)**. Se a instalação do Gradle estiver disponível no terminal: `gradle :app:assembleDebug`.
5. Local do arquivo: `app/build/outputs/apk/debug/app-debug.apk`.
6. Copie o APK para seu Android e instale-o. Algumas versões do Android exigem autorização para instalar apps de fontes desconhecidas.

## Compilar no próprio celular sem PC (GitHub Actions)

1. Crie um repositório no GitHub e envie o conteúdo da pasta `VortexMapper` para a **raiz do repositório**, incluindo a pasta oculta `.github/workflows`.
2. Abra o repositório no navegador, toque na aba **Actions** e escolha **Gerar APK Android**.
3. Toque em **Run workflow**. O fluxo instala o SDK/Gradle em um executor do GitHub e executa `assembleDebug`.
4. Ao terminar, baixe o artefato **VortexMapper-debug-APK**. Extraia o ZIP do artefato para encontrar `app-debug.apk` e instale o APK no celular.

O GitHub pode alterar os detalhes dessa interface. A execução está sujeita às regras e limites da sua conta.

## Configuração do mapeador

1. Abra o app e toque em **Abrir configurações de acessibilidade**.
2. Ative **Vortex Mapper — Controles** voluntariamente; a descrição esclarece o acesso solicitado.
3. Volte ao app, toque em **+ ADICIONAR** e selecione um jogo.
4. Toque em **EDITAR** na linha do jogo. Isso abre o jogo e carrega o editor flutuante.
5. Toque **＋ TECLA** para adicionar controles. Arraste as bolinhas até a posição do botão correspondente no jogo.
6. Selecione uma bolinha e toque **⇄ MODO** para alternar entre toque rápido e pressionado (para controles comuns).
7. Toque **✓ PRONTO** e **▣ SALVAR**. Toque na bolha **V** para abrir/fechar o menu.
8. Conecte um teclado USB OTG ou Bluetooth. Os eventos físicos compatíveis serão convertidos em toques.

**Configuração inicial:** joystick WASD no canto inferior esquerdo, ESPAÇO, R, F, M1 e âncora MIRA. Personalize de acordo com a interface de cada jogo; nenhuma detecção de posição de botões é automática.

## Limitações técnicas importantes

- Não existe uma API pública universal que conceda a um app comum o mesmo controle de teclado/mouse de um mapeador profissional para **todos** os jogos sem restrições. O jogo, o Android e o fabricante podem impedir ou limitar gestos sintetizados.
- O mapeamento de **teclas físicas** depende do Android encaminhar os eventos ao serviço de acessibilidade. O serviço pode disputar o filtro de teclas com outro serviço ativo.
- O uso do **mouse em Android 14+** é *experimental*: ativar a captura de eventos faz com que esses eventos de mouse não cheguem normalmente ao jogo; os gestos sintéticos substituem apenas certos movimentos/cliques. Não há “mouse lock” universal nem garantia de mira fluida em FPS.
- **Toques, movimentos da mira e múltiplas teclas pressionadas simultaneamente podem interferir entre si**. `dispatchGesture` cancela gestos que já estiverem em andamento; este protótipo serializa eventos e tenta manter teclas seguradas por meio de continuação de traçados, mas isso não elimina a restrição.
- O menu usa `TYPE_ACCESSIBILITY_OVERLAY`, não permissões de desenhar sobre outros aplicativos. Em alguns aparelhos, telas protegidas não aceitam overlays.
- Alguns jogos proíbem mapeadores ou ferramentas de automação em seus termos. Verifique as regras antes de usar.
- **Este projeto não tem root, injeção de processo, cheats, acesso a contas, execução de scripts, macros ocultas ou coleta de dados.**
- Ao mudar a orientação (retrato/paisagem), as posições relativas são preservadas, mas pode ser necessário reposicionar botões. O protótipo usa dimensões reais de tela, e barras do sistema podem exigir ajustes.
- A API de acessibilidade é um recurso poderoso. Ative-a somente se confiar no código e desative-a nas configurações quando quiser interromper o mapeamento.

## Arquitetura

```
app/src/main/java/com/vortex/mapper/
  MainActivity.java    tela inicial, seleção de jogos e permissões
  MapperService.java  detecção de janelas, overlay, editor e gestos
  Mapping.java        modelo do controle
  Store.java          configurações e perfis locais
app/src/main/res/xml/mapper_accessibility.xml
app/src/main/AndroidManifest.xml
.github/workflows/gerar-apk.yml
```

**Versão:** 1.0 beta, Android 8.0+, compilação SDK 35, alvo Android 14, Java 17, Android Gradle Plugin 8.6.1, Gradle 8.9. O APK não foi compilado/testado num dispositivo neste ambiente; trate-o como protótipo de desenvolvimento.
