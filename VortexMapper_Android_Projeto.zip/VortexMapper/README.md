# Vortex Mapper PRO 4.1 — correção de cliques involuntários

Esta atualização foi criada para impedir que deixar o cursor parado ou mover o mouse sem pressionar botões execute cliques mapeados.

## Correções

- Eventos de **hover** e de movimento do mouse não disparam botões de clique.
- Um evento `ACTION_DOWN` só aciona o mouse se indicar explicitamente o botão físico primário ou secundário (sem presumir botão esquerdo).
- Movimentos minúsculos da câmera não geram gestos de toque acidentais; deslocamentos reais são acumulados até haver distância suficiente.
- Saltos abruptos do cursor não disparam gestos de câmera.
- Ao suspender/capturar o mouse, os botões previamente pressionados são liberados.

## Diagnóstico no Android

**Atenção:** na captura anterior do usuário, o serviço *Auto Clicker* do Android estava **Ativado** em Acessibilidade. Ele pode clicar automaticamente independentemente do Vortex Mapper. Desative esse serviço e, se existir, também a função do Android **Clicar automaticamente quando o ponteiro parar**, antes de testar o APK atualizado.

No modo **CURSOR LIVRE**, o Vortex não envia comandos de câmera nem intercepta o mouse. No modo **CÂMERA ON** (experimental, Android 14+), mover fisicamente o mouse envia gestos curtos de deslizamento conforme a configuração; esses gestos ainda podem ser interpretados de modo diferente pelos jogos.

# Vortex Mapper PRO 4.0 — interface inspirada nas referências

**Projeto Android (Java) para compilar em APK.** Atualização visual do Vortex Mapper 3.0. Esta versão foi verificada quanto à sintaxe Java, XML e estrutura ZIP, **mas não foi compilada com o Android SDK nem testada em um aparelho real neste ambiente**.

## Novidades visuais

### Tela inicial / Jogos

- Estilo lilás/azul inspirado na imagem enviada, com cabeçalho **JOGOS** e barra inferior fixa: **Iniciar jogo**, **Conta**, **Loteria**, **Configurações**.
- **Adicionar jogo** escolhe aplicativos instalados; a tela usa o nome e o ícone reais do app — Free Fire aparecerá com seu ícone se estiver instalado e você o adicionar.
- Card grande para o jogo selecionado, com botões **Iniciar jogo** e **Editar keymap** e setas para alternar entre jogos.
- Indicadores de **mouse** e **teclado** consultam os dispositivos físicos detectados pelo Android e atualizam ao conectar/desconectar (a detecção varia conforme hub/OTG/fabricante).
- **Conta** mostra perfis locais e não pede logins ou senhas; **Loteria** é identificada como recurso indisponível. Não há serviço online ou sorteio conectado.
- **Configurações** apresenta permissão de acessibilidade, velocidade de mouse, suavização e velocidade opcional da seta do Android com autorização especial.

### Menu flutuante no jogo

- Toque na bolha **V** enquanto o jogo selecionado estiver na tela para abrir um painel lateral curvo, semitransparente e roxo, inspirado na segunda imagem.
- Botões de atalho em formato hexagonal, organizados em duas colunas:
  1. **Configurações de Keymap**: mostra perfil ativo, quantidade de controles, permite editar ou salvar.
  2. **Editar keymap**: abre o editor de controles sobre o jogo.
  3. **Mapeamento de teclas**: permite adicionar uma tecla ao keymap; no editor é possível arrastar.
  4. **Digitação no teclado**: exibe orientações e permite abrir as configurações de teclado do Android.
  5. **Controle do mouse**: abre velocidades, suavização e atalho para suspender captura.
  6. **Câmera X/Y**: controla movimento horizontal, vertical e movimento físico do mouse para cima.
- Botões superiores **Início**, **Configurações** e **Fechar**.
- Durante a edição, a barra de ferramentas existente continua disponível. Toque duas vezes em uma área vazia para adicionar uma tecla; salve o perfil ao terminar.

## Funcionalidades preservadas da versão 3.0

- Perfis por jogo salvos localmente.
- Teclado físico, mouse USB OTG/Bluetooth e interceptação de teclas pela API de Acessibilidade.
- Câmera experimental com sensibilidade X/Y e componente vertical ajustável mediante movimento real do mouse.
- Suspender/liberar mouse por tecla configurável (F8 por padrão).
- Velocidade da seta do Android ajustável (-7 a +7) apenas com permissão opcional **Modificar configurações do sistema**, com tentativa de restauração ao sair do jogo.
- Gestos mais curtos para diminuir a latência configurada, sem garantia de atraso zero.

## Compilar pelo GitHub, apenas pelo celular

Use o **mesmo nome do ZIP** que seu workflow antigo extrai:

1. Baixe `VortexMapper_Android_Projeto.zip` desta resposta.
2. Entre em `https://github.com/theylor071mendes-byte/VortexMapper` no navegador, aba **Code**.
3. Toque no menu de arquivos **⋯ > Upload file** e selecione esse ZIP, **substituindo** a versão anterior de mesmo nome; confirme **Commit changes**.
4. O workflow existente na raiz do seu repositório extrai `VortexMapper_Android_Projeto.zip` e executa `gradle :app:assembleDebug` dentro de `VortexMapper`. Mantenha esse workflow que já funcionou.
5. Aba **Actions** → execução verde → **Artifacts** → `VortexMapper-APK` → extrair o ZIP → instalar `app-debug.apk`.

Se o GitHub mostrar erro vermelho, abra a etapa da falha e leia o log. Uma verificação de sintaxe não garante que o projeto compile sem ajustes adicionais do SDK/Gradle.

**Atenção à atualização:** APKs de debug podem usar certificados diferentes entre execuções, impedindo instalação sobre a versão anterior. Desinstalar um APK pode apagar os keymaps armazenados localmente. Registre suas configurações antes de tentar reinstalar.

## Limites e segurança

- O Android **não oferece a apps externos captura universal e invisível do mouse para todo jogo**, e jogos podem rejeitar gestos de acessibilidade. Android 14+ é necessário para o monitoramento experimental de movimentos do mouse implementado neste protótipo.
- Este app **não tem aimbot** nem modifica arquivos de jogos. O ajuste de “puxada para cima” depende do usuário mover fisicamente o mouse.
- A permissão de acessibilidade é sensível: pode permitir observar interações com aplicativos e realizar gestos. Analise o código e suas permissões antes de concedê-la. Se o Play Protect bloquear a instalação, **não desative a proteção para contornar o alerta**.
- Este projeto é um protótipo sujeito a incompatibilidades entre aparelhos, jogos e versões Android. A presença de botões na interface não garante que funcionarão em todos os jogos.

## Compilação local (opcional)

Java 17, Android Gradle Plugin 8.6.1, Gradle 8.9 e SDK 35; `gradle :app:assembleDebug`. Android mínimo 8.0.
