# Vortex Mapper PRO 2.0 (beta) — mapeador Android

Projeto Android Java de **mapeamento experimental** de teclado e mouse para jogos escolhidos pelo usuário. Este ZIP é **código-fonte**, não um APK pré-compilado.

## Novidades da versão 2.0

- Interface em tema escuro, cartões renovados, guia em português e navegação rápida **JOGOS / MOUSE / AJUDA**.
- Biblioteca de jogos com perfil independente por aplicativo.
- **HUD flutuante:** a bolha **V** abre o editor e o botão **◎ MOUSE LIVRE / ◎ MIRA ON** alterna a captura de eventos do mouse enquanto o jogo está aberto.
- Atalho do teclado **F8** para alternar mouse livre/câmera, caso a captura experimental esteja habilitada.
- Controle **CÂMERA** no editor: ao tocar **sem arrastar** no círculo CÂMERA, abre o painel com ajuste **X horizontal**, **Y vertical** e **PUXADA PARA CIMA**. Os controles podem também ser abertos pela barra: **◎ CÂMERA X/Y**.
- **PUXADA PARA CIMA** aumenta a intensidade de deslocamentos quando o usuário **move fisicamente o mouse para cima** (dy negativo). Não automatiza a mira.
- Painel **🖱 MOUSE** dentro do jogo e seção **MOUSE** na página inicial: velocidade geral e suavização, ajustadas ao vivo.
- O usuário pode **redefinir** valores e cada jogo mantém X/Y/puxada separados.
- Teclas, cliques M1/M2, joystick WASD, mover controles, alternar pressionar/toque e salvar layout.

## Como usar

1. Abra o app e configure a permissão voluntária de acessibilidade **somente após conferir as implicações de privacidade**. O app precisa dela para overlays e simulação de gestos. Alguns Androids/Play Protect bloqueiam APKs com permissões sensíveis.
2. Toque em **+ ADICIONAR**, escolha o jogo, e depois em **EDITAR**.
3. Posicione os controles flutuantes. Se o seu jogo não tiver um ponto CÂMERA, entre em **+ TECLA > CÂMERA**.
4. Toque no ponto **CÂMERA** para ajustar X, Y e puxada; toque **APLICAR**.
5. Toque **✓ PRONTO** e **SALVAR**. Conecte teclado/mouse Bluetooth ou USB OTG.
6. No app inicial, em **CENTRAL DO MOUSE**, ative **Permitir captura experimental de mouse**. Esta opção só está disponível no **Android 14+**.
7. Dentro do jogo, toque em **◎ MOUSE LIVRE** para começar a converter movimento do mouse em gestos de deslizar próximos ao ponto CÂMERA. Quando quiser voltar ao ponteiro normal, toque novamente ou aperte **F8**.
8. Com a bolha **V**, abra **🖱 MOUSE** para velocidade e suavização, ou **◎ CÂMERA X/Y** para o perfil atual.

**A velocidade configurada modifica os gestos emitidos pelo Vortex Mapper, não a velocidade global do cursor no Android.**

## GitHub Actions — atualizar somente com o celular

Se você já usa o repositório `VortexMapper` do GitHub que compilou a versão anterior:

1. Faça o download do ZIP novo chamado **`VortexMapper_Android_Projeto.zip`**. É intencional que tenha o MESMO NOME do arquivo antigo.
2. No seu repositório, abra **Code** > `...` > **Upload file** e escolha o novo ZIP. Quando o GitHub pedir, salve com **Commit changes** para substituir o anterior.
3. Sua versão corrigida de `.github/workflows/gerar-apk.yml` deve continuar no repositório. **Não substitua** esse workflow por uma versão antiga.
4. Acesse **Actions**, abra a execução mais recente e espere resultado verde; em **Artifacts** baixe **VortexMapper-APK**, extraia o ZIP e encontre `app-debug.apk`.

**Importante sobre atualizações Android:** as versões `debug` do GitHub podem usar certificados de assinatura diferentes a cada build. Se o Android rejeitar a atualização do aplicativo existente por incompatibilidade de assinatura, será preciso desinstalar o anterior antes de instalar o novo. **Isso apaga os perfis locais**, portanto registre suas posições/ajustes antes de desinstalar. Para versões futuras, o ideal é configurar uma assinatura estável e privada.

Se for um repositório novo, envie a **pasta VortexMapper extraída para a raiz do GitHub**, incluindo `.github/workflows/gerar-apk.yml`. Alternativamente, envie o ZIP e use o workflow separado do arquivo `workflow-github-zip.yml` fornecido na entrega.

## Requisitos para desenvolvedor

- Java 17, Android Gradle Plugin 8.6.1, Gradle 8.9, Android SDK 35.
- Android mínimo 8.0 para os controles de teclado; Android **14+** necessário para tentativa de interceptação dos eventos de mouse.
- Para compilar localmente: na raiz do projeto `VortexMapper`, execute `gradle :app:assembleDebug`.
- Saída: `app/build/outputs/apk/debug/app-debug.apk`.

## Limites, segurança e honestidade técnica

- Este é um **protótipo**, não foi validado com um aparelho ou jogo real nesta entrega. Testes de sintaxe Java não provam que o APK compila nem que o controle funciona em todos os jogos.
- As APIs públicas não fornecem **mouse lock** universal nem forma confiável de ocultar o cursor de todos os jogos. "Modo câmera" aqui significa **capturar eventos quando possível e simular arrastos**, não bloquear de verdade o ponteiro do sistema.
- Gestos simultâneos de teclas pressionadas, joystick e movimento do mouse podem se cancelar devido a restrições de `dispatchGesture` do Android. A fluidez pode não ser adequada a jogos FPS.
- Acesso de acessibilidade é altamente sensível; alguns dispositivos restringem essa permissão para APKs externos. Não desative proteções do celular só para instalar um APK não auditado.
- O projeto não faz injeção, root, modificação de pacotes de jogos, macros de mira automática, registro de contas ou coleta de dados pessoais. As configurações ficam em `SharedPreferences` locais.
- Não garantimos conformidade com termos de cada jogo; confira antes de usar.

## Arquivos principais

`app/src/main/java/com/vortex/mapper/MainActivity.java` — interface inicial, sliders e jogos.

`app/src/main/java/com/vortex/mapper/MapperService.java` — sobreposição, botão câmera, editor, gestos e painéis.

`app/src/main/java/com/vortex/mapper/Store.java` — persistência por jogo.

`app/src/main/java/com/vortex/mapper/Mapping.java` — modelo de mapeamento.
