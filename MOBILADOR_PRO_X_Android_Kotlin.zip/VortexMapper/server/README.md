# Backend Premium (Node 20+, HTTPS obrigatório)

Este servidor **não está hospedado**. O pagamento não funcionará até que o operador configure uma loja real no Google Play Console, um produto de assinatura, uma conta de serviço com acesso à API Google Play Developer, DNS+HTTPS e os segredos `.env`.

1. `cd server && npm install`
2. Copie `.env.example` para `.env`, gere `JWT_SECRET` aleatório e `TOKEN_ENC_KEY_HEX` com 32 bytes aleatórios hex (ex.: `openssl rand -hex 32`).
3. Configure a service account e conceda permissões de assinaturas no Play Console. Não inclua JSON de chave no APK ou GitHub.
4. Em ambiente de produção, utilize proxy HTTPS, limites de requisição e monitore o servidor.
5. `node --env-file=.env index.mjs` (Node 20.6+).
6. Compile o app com `-PPROX_API_URL=https://seu-dominio.example`. Sem URL, tela de pagamento ficará desabilitada.
7. Cadastre o produto `mobilador_pro_monthly` no Google Play Console, associe oferta/base plan e distribua por canal de teste autorizado. Teste compras com license testers.

**Proteção de assinatura**: token Play é consultado na API oficial (não basta alterar valores locais); são verificados produto, expiração e estado e uma compra não pode pertencer a duas contas. Backups exigem checagem Premium no servidor em cada solicitação. Esta implementação não inclui mecanismos de cobrança fora da Play Store ou preços falsos. Para lançamento público, implante política de privacidade, recuperação de senha, Play Real-time Developer Notifications e política de exclusão de dados conforme legislação aplicável.
