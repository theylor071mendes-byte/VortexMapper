import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import Database from 'better-sqlite3';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { google } from 'googleapis';

const { PORT = '8080', APP_PACKAGE_NAME = 'com.mobilador.prox', PLAY_PRODUCT_ID = 'mobilador_pro_monthly',
 JWT_SECRET, TOKEN_ENC_KEY_HEX, GOOGLE_SERVICE_ACCOUNT_JSON, DATABASE_PATH = './mobilador.db' } = process.env;
if (!JWT_SECRET || JWT_SECRET.length < 32 || !/^[0-9a-f]{64}$/i.test(TOKEN_ENC_KEY_HEX || '') || !GOOGLE_SERVICE_ACCOUNT_JSON) {
  console.error('Configure JWT_SECRET, TOKEN_ENC_KEY_HEX e GOOGLE_SERVICE_ACCOUNT_JSON antes de iniciar.');
  process.exit(1);
}
const encryptionKey = Buffer.from(TOKEN_ENC_KEY_HEX, 'hex');
const db = new Database(DATABASE_PATH);
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT NOT NULL UNIQUE, salt TEXT NOT NULL, hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, token_hash TEXT NOT NULL UNIQUE, token_cipher TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE IF NOT EXISTS backups(user_id INTEGER PRIMARY KEY, json TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id));
`);
const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(express.json({ limit: '256kb' }));
app.use(rateLimit({windowMs: 60_000, limit: 40, standardHeaders: 'draft-7', legacyHeaders: false}));
const authClient = new google.auth.GoogleAuth({credentials: JSON.parse(GOOGLE_SERVICE_ACCOUNT_JSON),scopes:['https://www.googleapis.com/auth/androidpublisher']});
const publisher = google.androidpublisher({version:'v3',auth:authClient});
const encrypt = text => {const iv=crypto.randomBytes(12);const c=crypto.createCipheriv('aes-256-gcm',encryptionKey,iv);const body=Buffer.concat([c.update(text,'utf8'),c.final()]);return Buffer.concat([iv,c.getAuthTag(),body]).toString('base64');};
const decrypt = payload => {const b=Buffer.from(payload,'base64');const d=crypto.createDecipheriv('aes-256-gcm',encryptionKey,b.subarray(0,12));d.setAuthTag(b.subarray(12,28));return Buffer.concat([d.update(b.subarray(28)),d.final()]).toString('utf8');};
const tokenHash = text => crypto.createHash('sha256').update(text).digest('hex');
const secretHash = (password,salt) => crypto.scryptSync(password,salt,64);
function authorize(req,res,next){try {req.user=jwt.verify((req.get('Authorization')||'').replace(/^Bearer /,''),JWT_SECRET,{algorithms:['HS256']});next();}catch{res.status(401).json({error:'Autenticação necessária'});}}
const issue = (id,email) => jwt.sign({id,email},JWT_SECRET,{algorithm:'HS256',expiresIn:'7d',issuer:'mobilador-pro-x'});
app.post('/auth/register',(req,res)=>{
  const {email,password}=req.body || {};
  if(typeof email!=='string'|| !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || typeof password!=='string'||password.length<10 ||password.length>128) return res.status(400).json({error:'Informe e-mail válido e senha de 10 a 128 caracteres'});
  const salt=crypto.randomBytes(16).toString('hex');
  try {const row=db.prepare('INSERT INTO users(email,salt,hash) VALUES(?,?,?)').run(email.toLowerCase(),salt,secretHash(password,salt).toString('hex'));
    res.status(201).json({token:issue(row.lastInsertRowid,email.toLowerCase())});
  } catch {res.status(409).json({error:'E-mail indisponível'});}
});
app.post('/auth/login',(req,res)=>{
  const {email,password}=req.body||{};
  const user= typeof email==='string'?db.prepare('SELECT * FROM users WHERE email=?').get(email.toLowerCase()):null;
  const supplied= typeof password==='string' && password.length<=128?password:'';
  const calculated=secretHash(supplied,user?.salt || 'not-found-dummy-salt');
  const stored=Buffer.from(user?.hash || '0'.repeat(128),'hex');
  if(!user || !crypto.timingSafeEqual(calculated,stored))return res.status(401).json({error:'Credenciais inválidas'});
  res.json({token:issue(user.id,user.email)});
});
async function subscriptionStatus(purchaseToken){
  const {data} = await publisher.purchases.subscriptionsv2.get({packageName:APP_PACKAGE_NAME,token:purchaseToken});
  const items=(data.lineItems||[]).filter(x=>x.productId===PLAY_PRODUCT_ID);
  const future=items.some(x=>new Date(x.expiryTime||0).getTime()>Date.now());
  const eligibleStates=new Set(['SUBSCRIPTION_STATE_ACTIVE','SUBSCRIPTION_STATE_IN_GRACE_PERIOD','SUBSCRIPTION_STATE_CANCELED']);
  return {valid:future&&eligibleStates.has(data.subscriptionState),data};
}
async function hasPremium(userId){
  const rows=db.prepare('SELECT token_cipher FROM purchases WHERE user_id=?').all(userId);
  for(const row of rows){
    try {if((await subscriptionStatus(decrypt(row.token_cipher))).valid) return true;}
    catch(e){console.error('Falha ao consultar Play Developer API',e.message);throw e;}
  }
  return false;
}
app.get('/entitlement', authorize, async (req,res)=>{
  try{res.json({premium:await hasPremium(req.user.id)});}catch{res.status(503).json({error:'Não foi possível verificar Google Play'});}
});
app.post('/billing/verify', authorize, async (req,res)=>{
  const token=req.body?.purchaseToken;
  if(typeof token!=='string'||token.length<20||token.length>8192)return res.status(400).json({error:'Token inválido'});
  try {
    const result=await subscriptionStatus(token);
    if(!result.valid)return res.status(403).json({error:'Assinatura não está ativa'});
    const hash=tokenHash(token);
    const existing=db.prepare('SELECT user_id FROM purchases WHERE token_hash=?').get(hash);
    if(existing && existing.user_id!==req.user.id)return res.status(403).json({error:'Token já associado a outra conta'});
    db.prepare('INSERT INTO purchases(user_id,token_hash,token_cipher) VALUES(?,?,?) ON CONFLICT(token_hash) DO UPDATE SET token_cipher=excluded.token_cipher')
      .run(req.user.id,hash,encrypt(token));
    if(result.data.acknowledgementState==='ACKNOWLEDGEMENT_STATE_PENDING') {
      await publisher.purchases.subscriptions.acknowledge({packageName:APP_PACKAGE_NAME,subscriptionId:PLAY_PRODUCT_ID,token,requestBody:{}});
    }
    res.json({premium:true});
  } catch(e) {console.error('Falha de verificação',e.message);res.status(503).json({error:'Verificação do Google Play indisponível'});}
});
async function premiumOnly(req,res,next){try{if(!await hasPremium(req.user.id))return res.status(403).json({error:'Premium necessário'});next();}catch{res.status(503).json({error:'Validação temporariamente indisponível'});}}
app.get('/profiles', authorize, premiumOnly, (req,res)=>{
 const row=db.prepare('SELECT json FROM backups WHERE user_id=?').get(req.user.id);
 res.json(row ? JSON.parse(row.json) : {profiles:[]});
});
app.put('/profiles', authorize, premiumOnly, (req,res)=>{
 const profiles=req.body?.profiles;
 if(!Array.isArray(profiles)||profiles.length>100||profiles.some(p=>typeof p.packageName!=='string'||p.packageName.length>150||!Array.isArray(p.keys)||p.keys.length>150))return res.status(400).json({error:'Dados de perfil inválidos'});
 db.prepare('INSERT INTO backups(user_id,json) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET json=excluded.json').run(req.user.id, JSON.stringify({profiles}));
 res.json({saved:true});
});
app.get('/health', (_,res)=>res.json({service:'mobilador-pro-x',status:'ok'}));
app.listen(Number(PORT), '127.0.0.1', ()=>console.log(`Servidor em 127.0.0.1:${PORT}; use proxy HTTPS`));
