package com.mobilador.prox.premium

import android.app.Activity
import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.android.billingclient.api.*
import com.mobilador.prox.BuildConfig
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec

/** Never unlock Premium from a local boolean or an unverified Play purchase.
 * Server validates the subscription token using Google Play Developer API.
 */
class PremiumClient(private val context: Context) : PurchasesUpdatedListener {
    val entitled = MutableStateFlow(false)
    val status = MutableStateFlow(if (BuildConfig.API_BASE_URL.isBlank()) "Servidor Premium não configurado" else "Faça login para consultar a assinatura")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val secret = SecureSession(context)
    private var cachedProduct: ProductDetails? = null
    private val billing = BillingClient.newBuilder(context).setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()).build()
    val configured: Boolean get() = BuildConfig.API_BASE_URL.startsWith("https://")
    init {
        if (configured) {
            billing.startConnection(object : BillingClientStateListener {
                override fun onBillingSetupFinished(result: BillingResult) {
                    if (result.responseCode == BillingClient.BillingResponseCode.OK) queryProduct()
                    else status.value = "Google Play Billing indisponível: ${result.debugMessage}"
                }
                override fun onBillingServiceDisconnected() { status.value = "Conexão com Google Play interrompida" }
            })
            scope.launch { refresh() }
        }
    }
    private fun queryProduct() {
        val product = QueryProductDetailsParams.Product.newBuilder()
            .setProductId(BuildConfig.PREMIUM_PRODUCT_ID).setProductType(BillingClient.ProductType.SUBS).build()
        billing.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(listOf(product)).build()) { result, list ->
            cachedProduct = list.firstOrNull()
            if (cachedProduct == null && result.responseCode == BillingClient.BillingResponseCode.OK)
                status.value = "Assinatura ainda não cadastrada no Play Console"
        }
    }
    fun subscribe(activity: Activity) {
        if (!configured || secret.read().isNullOrBlank()) { status.value = "Configure o servidor e faça login antes de comprar"; return }
        val product = cachedProduct ?: run { status.value = "Produto não encontrado no Google Play"; return }
        val offer = product.subscriptionOfferDetails?.firstOrNull() ?: run { status.value = "Oferta de assinatura indisponível"; return }
        val params = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(product).setOfferToken(offer.offerToken).build()
        val result = billing.launchBillingFlow(activity, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(params)).build())
        if (result.responseCode != BillingClient.BillingResponseCode.OK) status.value = result.debugMessage
    }
    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        if (result.responseCode == BillingClient.BillingResponseCode.OK) {
            purchases.orEmpty().filter { it.purchaseState == Purchase.PurchaseState.PURCHASED }.forEach { purchase ->
                scope.launch {
                    runCatching { request("/billing/verify", JSONObject().put("purchaseToken", purchase.purchaseToken), "POST") }
                        .onSuccess { refresh() }
                        .onFailure { status.value = "Compra recebida, mas ainda não validada pelo servidor: ${it.message}" }
                }
            }
        } else if (result.responseCode != BillingClient.BillingResponseCode.USER_CANCELED) {
            status.value = "Compra não concluída: ${result.debugMessage}"
        }
    }
    suspend fun login(email: String, password: String, create: Boolean = false) {
        if (!configured) return
        runCatching {
            val result = request(if (create) "/auth/register" else "/auth/login",
                JSONObject().put("email", email.trim()).put("password", password), "POST", false)
            secret.save(result.getString("token")); refresh()
        }.onFailure { status.value = "Login falhou: ${it.message}"; entitled.value = false }
    }
    suspend fun refresh() {
        if (!configured || secret.read().isNullOrBlank()) { entitled.value = false; return }
        runCatching {
            val result = request("/entitlement", null, "GET")
            entitled.value = result.optBoolean("premium", false)
            status.value = if (entitled.value) "Assinatura Premium validada pelo servidor" else "Plano gratuito (até 2 perfis)"
        }.onFailure { entitled.value = false; status.value = "Não foi possível validar a assinatura: ${it.message}" }
    }
    fun signOut() { secret.clear(); entitled.value = false; status.value = "Desconectado" }
    suspend fun uploadBackup(payload: JSONObject): Boolean {
        if (!entitled.value) return false
        return runCatching { request("/profiles", payload, "PUT"); true }.getOrDefault(false)
    }
    suspend fun downloadBackup(): JSONObject? = if (entitled.value) runCatching { request("/profiles", null, "GET") }.getOrNull() else null
    private suspend fun request(path: String, body: JSONObject?, method: String, authenticated: Boolean = true): JSONObject = withContext(Dispatchers.IO) {
        require(configured) { "Exige backend HTTPS" }
        val c = URL(BuildConfig.API_BASE_URL.trimEnd('/') + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 10000; c.readTimeout = 12000
        c.setRequestProperty("Accept", "application/json")
        if (authenticated) secret.read()?.let { c.setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) {
            c.doOutput = true; c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        }
        try {
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
            if (code !in 200..299) error("HTTP $code: ${text.take(200)}")
            JSONObject(text)
        } finally { c.disconnect() }
    }
}

/** Android Keystore AES/GCM encrypted session (not written as plaintext DataStore). */
private class SecureSession(private val context: Context) {
    private val name = "mobilador_session_key"
    private val prefs = context.getSharedPreferences("secure_session", Context.MODE_PRIVATE)
    private fun key(): java.security.Key {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        ks.getKey(name, null)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(name, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return generator.generateKey()
    }
    fun save(token: String) = runCatching {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val data = cipher.doFinal(token.toByteArray())
        prefs.edit().putString("encrypted", Base64.encodeToString(data, Base64.NO_WRAP))
            .putString("iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP)).apply()
    }.getOrThrow()
    fun read(): String? {
        val savedIv = prefs.getString("iv", null) ?: return null
        val encrypted = prefs.getString("encrypted", null) ?: return null
        return runCatching {
            val iv = Base64.decode(savedIv, Base64.NO_WRAP)
            val data = Base64.decode(encrypted, Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(data))
        }.getOrNull()
    }
    fun clear() { prefs.edit().clear().apply() }
}
