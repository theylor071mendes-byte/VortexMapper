package com.mobilador.prox.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "profiles", indices = [Index(value = ["packageName"], unique = true)])
data class GameProfile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val title: String,
    val sensitivityX: Float = 70f,
    val sensitivityY: Float = 65f,
    val upwardBoost: Float = 100f,
    val acceleration: Float = 0f,
    val smoothing: Float = 0f,
    val deadzone: Float = 2f,
    val invertX: Boolean = false,
    val invertY: Boolean = false,
    val suspendKey: Int = android.view.KeyEvent.KEYCODE_F8
)

@Entity(tableName = "controls", indices = [Index(value = ["profileId"])],
    foreignKeys = [ForeignKey(entity = GameProfile::class, parentColumns = ["id"], childColumns = ["profileId"], onDelete = ForeignKey.CASCADE)])
data class KeyControl(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val keyCode: Int,
    val x: Float,
    val y: Float,
    val size: Float = 58f,
    val action: String = "TAP" // TAP or HOLD; HOLD is best-effort on Android accessibility
)

@Dao interface ProfileDao {
    @Query("SELECT * FROM profiles ORDER BY title COLLATE NOCASE") fun observeAll(): Flow<List<GameProfile>>
    @Query("SELECT * FROM profiles WHERE id=:id LIMIT 1") suspend fun byId(id: Long): GameProfile?
    @Query("SELECT * FROM profiles WHERE packageName=:pkg LIMIT 1") suspend fun byPackage(pkg: String): GameProfile?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(profile: GameProfile): Long
    @Update suspend fun update(profile: GameProfile)
    @Delete suspend fun delete(profile: GameProfile)
}
@Dao interface ControlDao {
    @Query("SELECT * FROM controls WHERE profileId=:profileId ORDER BY id") fun observe(profileId: Long): Flow<List<KeyControl>>
    @Query("SELECT * FROM controls WHERE profileId=:profileId ORDER BY id") suspend fun forProfile(profileId: Long): List<KeyControl>
    @Insert suspend fun insert(control: KeyControl): Long
    @Update suspend fun update(control: KeyControl)
    @Delete suspend fun delete(control: KeyControl)
}
@Database(entities = [GameProfile::class, KeyControl::class], version = 1, exportSchema = false)
abstract class MapperDatabase : RoomDatabase() {
    abstract fun profiles(): ProfileDao
    abstract fun controls(): ControlDao
    companion object {
        @Volatile private var instance: MapperDatabase? = null
        fun get(context: Context): MapperDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, MapperDatabase::class.java, "mobilador-pro-x.db").build().also { instance = it }
        }
    }
}
