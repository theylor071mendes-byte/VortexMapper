package com.mobilador.prox.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore("mobilador_settings")
class SettingsStore(private val context: Context) {
    private val selected = longPreferencesKey("selected_profile")
    private val enabled = booleanPreferencesKey("mapping_enabled")
    private val mouseSpeed = intPreferencesKey("pointer_speed")
    private val changeNative = booleanPreferencesKey("change_system_pointer_speed")
    val selectedProfile: Flow<Long> = context.settingsDataStore.data.map { it[selected] ?: 0L }
    val mappingEnabled: Flow<Boolean> = context.settingsDataStore.data.map { it[enabled] ?: false }
    val pointerSpeed: Flow<Int> = context.settingsDataStore.data.map { it[mouseSpeed] ?: 0 }
    val applySystemPointer: Flow<Boolean> = context.settingsDataStore.data.map { it[changeNative] ?: false }
    suspend fun setSelected(id: Long) { context.settingsDataStore.edit { it[selected] = id } }
    suspend fun setEnabled(value: Boolean) { context.settingsDataStore.edit { it[enabled] = value } }
    suspend fun setPointerSpeed(value: Int) { context.settingsDataStore.edit { it[mouseSpeed] = value.coerceIn(-7, 7) } }
    suspend fun setApplySystemPointer(value: Boolean) { context.settingsDataStore.edit { it[changeNative] = value } }
}
