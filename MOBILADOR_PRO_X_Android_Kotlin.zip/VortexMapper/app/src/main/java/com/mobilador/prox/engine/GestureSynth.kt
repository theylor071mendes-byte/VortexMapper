package com.mobilador.prox.engine

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper

/** Serializes gesture dispatch; Android may cancel an in-flight touch when a new gesture starts.
 * HOLD chains short continuing strokes, so multi-key holds can share one gesture dispatch.
 * Accessibility and the game's own handling can still limit simultaneous/low-latency input.
 */
class GestureSynth(private val service: AccessibilityService) {
    private val handler = Handler(Looper.getMainLooper())
    private val tapQueue = ArrayDeque<Pair<Float, Float>>()
    private val active = linkedMapOf<Int, Pair<Float, Float>>()
    private var continuation = linkedMapOf<Int, GestureDescription.StrokeDescription>()
    private var busy = false
    private var generation = 0

    fun tap(x: Float, y: Float) {
        if (tapQueue.size < 12) tapQueue.addLast(x to y)
        pump()
    }
    fun startHold(key: Int, x: Float, y: Float) {
        if (active.size >= 8) return
        active[key] = x to y
        pump()
    }
    fun endHold(key: Int) {
        active.remove(key)
        pump()
    }
    fun clear() {
        generation++
        active.clear(); continuation.clear(); tapQueue.clear()
        busy = false
        handler.removeCallbacksAndMessages(null)
    }
    private fun path(x: Float, y: Float) = Path().apply { moveTo(x, y) }
    private fun pump() {
        if (busy) return
        if (active.isEmpty() && continuation.isEmpty()) {
            val point = tapQueue.removeFirstOrNull() ?: return
            busy = true
            val p = path(point.first, point.second)
            val desc = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 32)).build()
            val thisGeneration = generation
            val callback = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { finish() }
                override fun onCancelled(gestureDescription: GestureDescription?) { finish() }
                private fun finish() { if (generation == thisGeneration) { busy = false; pump() } }
            }
            if (!service.dispatchGesture(desc, callback, handler)) { busy = false; pump() }
            return
        }
        busy = true
        val duration = 120L
        val builder = GestureDescription.Builder()
        val next = linkedMapOf<Int, GestureDescription.StrokeDescription>()
        // Continue or terminate earlier strokes; never leave a released key holding forever.
        for ((key, stroke) in continuation) {
            val coords = active[key]
            val ending = coords == null
            val position = coords ?: previousPointFor(stroke)
            val continued = stroke.continueStroke(path(position.first, position.second), 0, if (ending) 1L else duration, !ending)
            builder.addStroke(continued)
            if (!ending) next[key] = continued
        }
        for ((key, position) in active) {
            if (key !in next) {
                val stroke = GestureDescription.StrokeDescription(path(position.first, position.second), 0, duration, true)
                builder.addStroke(stroke); next[key] = stroke
            }
        }
        // Dispatch a newly requested tap along with the ongoing holds, instead of
        // waiting indefinitely for the user to release a movement key.
        tapQueue.removeFirstOrNull()?.let { (x, y) ->
            builder.addStroke(GestureDescription.StrokeDescription(path(x, y), 0, 32L))
        }
        val thisGeneration = generation
        val callback = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (thisGeneration != generation) return
                continuation = next
                busy = false
                if (active.isNotEmpty() || continuation.isNotEmpty() || tapQueue.isNotEmpty()) handler.post { pump() }
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (thisGeneration != generation) return
                continuation.clear(); busy = false
                if (active.isNotEmpty() || tapQueue.isNotEmpty()) handler.post { pump() }
            }
        }
        if (!service.dispatchGesture(builder.build(), callback, handler)) {
            continuation.clear(); busy = false
        }
    }
    private fun previousPointFor(stroke: GestureDescription.StrokeDescription): Pair<Float, Float> {
        // Stroke#getPath returns its original touch position, even for released keys.
        val coords = FloatArray(2)
        val measure = android.graphics.PathMeasure(stroke.path, false)
        measure.getPosTan(0f, coords, null)
        return coords[0] to coords[1]
    }
}
