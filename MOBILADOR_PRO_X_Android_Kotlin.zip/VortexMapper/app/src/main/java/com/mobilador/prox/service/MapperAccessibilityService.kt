package com.mobilador.prox.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.*
import com.mobilador.prox.data.*
import com.mobilador.prox.engine.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.combine

class MapperAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var db: MapperDatabase
    private lateinit var store: SettingsStore
    private lateinit var wm: WindowManager
    private lateinit var synth: GestureSynth
    private lateinit var nativePointer: SystemPointerSpeed
    private val pressed = HeldKeyState()
    private var profile: GameProfile? = null
    private var controls: List<KeyControl> = emptyList()
    private var mappingEnabled = false
    private var nativePointerEnabled = false
    private var selectedPointerSpeed = 0
    private var inGame = false
    private var pointerSlow = true
    private var editorOpen = false
    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var optionsPanel: View? = null
    private var editor: FrameLayout? = null
    private var editorRoot: FrameLayout? = null
    private var editorStatus: TextView? = null
    private var editorControls: List<KeyControl> = emptyList()
    private var capturingAt: Pair<Float, Float>? = null
    private var capturing = false
    private val primary = Color.rgb(127, 92, 255)
    private val cyan = Color.rgb(18, 224, 242)
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        db = MapperDatabase.get(this); store = SettingsStore(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        synth = GestureSynth(this); nativePointer = SystemPointerSpeed(this)
        serviceInfo = serviceInfo.apply { flags = flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS }
        scope.launch {
            combine(store.selectedProfile, store.mappingEnabled, store.applySystemPointer, store.pointerSpeed) { id, enabled, native, speed -> listOf(id, enabled, native, speed) }
                .collect { values ->
                    val id = values[0] as Long
                    mappingEnabled = values[1] as Boolean
                    nativePointerEnabled = values[2] as Boolean
                    selectedPointerSpeed = values[3] as Int
                    profile = if (id == 0L) null else db.profiles().byId(id)
                    controls = if (id == 0L) emptyList() else db.controls().forProfile(id)
                    if (!mappingEnabled) { inGame = false; stopOverlay(); nativePointer.restore() }
                    else if (inGame && nativePointerEnabled && pointerSlow) nativePointer.applyIfPermitted(selectedPointerSpeed)
                }
        }
    }
    fun refreshControls() { scope.launch { controls = profile?.let { db.controls().forProfile(it.id) } ?: emptyList() } }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName) return // our menus must not deactivate the selected game
        val foreground = mappingEnabled && profile != null && pkg == profile?.packageName
        if (foreground == inGame) return
        inGame = foreground
        if (foreground) {
            pointerSlow = true
            if (nativePointerEnabled) nativePointer.applyIfPermitted(selectedPointerSpeed)
            showBubble()
        } else {
            synth.clear(); pressed.clear(); nativePointer.restore(); stopOverlay()
        }
    }
    override fun onInterrupt() { synth.clear(); pressed.clear(); nativePointer.restore() }
    override fun onDestroy() {
        synth.clear(); pressed.clear(); nativePointer.restore(); stopOverlay(); scope.cancel()
        instance = null
        super.onDestroy()
    }
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!mappingEnabled || !inGame || profile == null) return false
        val code = event.keyCode
        if (capturing) {
            if (event.action == KeyEvent.ACTION_UP) return true
            if (event.repeatCount != 0) return true
            val pos = capturingAt ?: return true
            capturing = false; capturingAt = null
            scope.launch {
                val p = profile ?: return@launch
                db.controls().insert(KeyControl(profileId = p.id, keyCode = code, x = InputLogic.normalize(pos.first), y = InputLogic.normalize(pos.second)))
                reloadEditor()
            }
            editorStatus?.text = "Tecla vinculada: ${KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")}"
            return true
        }
        if (editorOpen) return false // while editing, no touches are injected into the game
        if (code == profile?.suspendKey) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                pointerSlow = !pointerSlow
                if (nativePointerEnabled) {
                    if (pointerSlow) nativePointer.applyIfPermitted(selectedPointerSpeed) else nativePointer.restore()
                }
                Toast.makeText(this, if (pointerSlow) "Ponteiro: velocidade configurada" else "Ponteiro: velocidade do sistema", Toast.LENGTH_SHORT).show()
            }
            return true
        }
        val matches = controls.filter { it.keyCode == code }
        if (matches.isEmpty()) return false
        val screen = resources.displayMetrics
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (!pressed.onDown(code, event.repeatCount)) return true
            matches.forEach {
                val x = InputLogic.normalize(it.x) * screen.widthPixels
                val y = InputLogic.normalize(it.y) * screen.heightPixels
                if (it.action == "HOLD") synth.startHold(code, x, y) else synth.tap(x, y)
            }
            return true
        }
        if (event.action == KeyEvent.ACTION_UP) {
            pressed.onUp(code)
            if (matches.any { it.action == "HOLD" }) synth.endHold(code)
            return true
        }
        return false
    }
    private fun overlayParams(w: Int, h: Int, gravity: Int, x: Int = 0, y: Int = 0) =
        WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT).apply { this.gravity = gravity; this.x = x; this.y = y }
    private fun shape(color: Int, corner: Float = 24f, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = corner; if (stroke != 0) setStroke(2, stroke) }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float = 14f, color: Int = Color.WHITE) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8))
    }
    private fun showBubble() {
        if (bubble != null || !mappingEnabled || !inGame) return
        val b = label("X", 22f).apply { setTypeface(null, Typeface.BOLD); background = shape(primary, dp(22).toFloat(), cyan); elevation = dp(6).toFloat() }
        val params = overlayParams(dp(54), dp(54), Gravity.TOP or Gravity.START, dp(10), dp(130))
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        b.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    if (kotlin.math.abs(event.rawX - downX) > dp(6) || kotlin.math.abs(event.rawY - downY) > dp(6)) moved = true
                    if (moved) { params.x = startX + (event.rawX - downX).toInt(); params.y = startY + (event.rawY - downY).toInt(); runCatching { wm.updateViewLayout(b, params) } }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) toggleMenu(); true }
                else -> true
            }
        }
        bubble = b; bubbleParams = params
        wm.addView(b, params)
    }
    private fun toggleMenu() {
        if (optionsPanel != null) { remove(optionsPanel); optionsPanel = null; return }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(Color.argb(240, 14, 12, 33), dp(28).toFloat(), primary)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val header = label("MOBILADOR  PRO X", 16f, cyan).apply { setTypeface(null, Typeface.BOLD) }
        box.addView(header)
        fun option(title: String, action: () -> Unit) {
            box.addView(label(title, 14f).apply {
                background = shape(Color.rgb(42, 32, 79), dp(12).toFloat())
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(dp(250), dp(52)).apply { bottomMargin = dp(7) })
        }
        option("✎  EDITAR KEYMAP") { remove(optionsPanel); optionsPanel = null; openEditor() }
        option("⌨  TECLAS CONFIGURADAS") { Toast.makeText(this, "${controls.size} controles cadastrados. Abra EDITAR para mudar.", Toast.LENGTH_LONG).show() }
        option("◉  TESTAR MIRA (NO APP)") { remove(optionsPanel); optionsPanel = null; startActivity(android.content.Intent(this, com.mobilador.prox.ui.MainActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("open_calibration", true)) }
        option("⚙  CONFIGURAÇÕES") { remove(optionsPanel); optionsPanel = null; startActivity(android.content.Intent(this, com.mobilador.prox.ui.MainActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("open_settings", true)) }
        option("◷  PAUSAR MAPEAMENTO") { scope.launch { store.setEnabled(false) } }
        option("✕  FECHAR MENU") { remove(optionsPanel); optionsPanel = null }
        optionsPanel = box
        wm.addView(box, overlayParams(dp(280), WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START, dp(70), dp(100)))
    }
    private fun openEditor() {
        if (editorOpen) return
        editorOpen = true; synth.clear(); pressed.clear()
        val root = FrameLayout(this).apply { setBackgroundColor(Color.argb(90, 9, 9, 22)) }
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val screen = resources.displayMetrics
                capturingAt = (e.rawX / screen.widthPixels) to (e.rawY / screen.heightPixels)
                capturing = true
                editorStatus?.text = "Pressione uma tecla física para criar o controle…"
                return true
            }
        })
        root.setOnTouchListener { _, event -> detector.onTouchEvent(event); true }
        editorRoot = root
        wm.addView(root, overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, Gravity.TOP or Gravity.START))
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = shape(Color.argb(248, 15, 12, 37), dp(14).toFloat()); setPadding(dp(8), dp(6), dp(8), dp(6)) }
        val row = LinearLayout(this)
        row.addView(label("MODO EDITAR · Toque 2 vezes", 13f, cyan), LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(label("SALVAR / SAIR", 12f).apply { background = shape(primary, dp(10).toFloat()); setOnClickListener { closeEditor() } })
        toolbar.addView(row)
        editorStatus = label("Toque 2x em área vazia, depois pressione uma tecla", 12f)
        toolbar.addView(editorStatus)
        root.addView(toolbar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        editor = root
        scope.launch { reloadEditor() }
    }
    private suspend fun reloadEditor() {
        val p = profile ?: return
        val root = editorRoot ?: return
        editorControls = db.controls().forProfile(p.id)
        // Preserve the toolbar at index 0.
        while (root.childCount > 1) root.removeViewAt(root.childCount - 1)
        val metrics = resources.displayMetrics
        editorControls.forEach { control ->
            val text = KeyEvent.keyCodeToString(control.keyCode).removePrefix("KEYCODE_")
            val view = label(text, 13f).apply { background = shape(Color.argb(218, 87, 63, 183), dp(12).toFloat(), cyan) }
            val size = dp(control.size.toInt())
            val lp = FrameLayout.LayoutParams(size, size).apply {
                leftMargin = (control.x * metrics.widthPixels).toInt() - size / 2
                topMargin = (control.y * metrics.heightPixels).toInt() - size / 2
            }
            var sx = 0f; var sy = 0f; var oldX = 0; var oldY = 0; var start = 0L
            view.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; oldX = lp.leftMargin; oldY = lp.topMargin; start = android.os.SystemClock.uptimeMillis(); true }
                    MotionEvent.ACTION_MOVE -> {
                        lp.leftMargin = (oldX + (e.rawX - sx)).toInt().coerceIn(0, metrics.widthPixels-size)
                        lp.topMargin = (oldY + (e.rawY - sy)).toInt().coerceIn(0, metrics.heightPixels-size)
                        root.updateViewLayout(view, lp); true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (android.os.SystemClock.uptimeMillis() - start > 520 && kotlin.math.abs(e.rawX - sx) < dp(8) && kotlin.math.abs(e.rawY - sy) < dp(8)) showControlOptions(control)
                        else scope.launch {
                            db.controls().update(control.copy(x=InputLogic.normalize((lp.leftMargin+size/2f)/metrics.widthPixels), y=InputLogic.normalize((lp.topMargin+size/2f)/metrics.heightPixels)))
                            refreshControls()
                        }
                        true
                    }
                    else -> true
                }
            }
            root.addView(view, lp)
        }
        refreshControls()
    }
    private fun showControlOptions(control: KeyControl) {
        val layout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(12),dp(20),dp(12)) }
        val seek = SeekBar(this).apply { max=100; progress=(control.size-32).toInt().coerceIn(0,100) }
        layout.addView(label("Tamanho do botão", 15f, Color.BLACK)); layout.addView(seek)
        val actions = arrayOf("TAP", "HOLD")
        var mode = control.action
        val selector = Spinner(this).apply { adapter = ArrayAdapter(this@MapperAccessibilityService, android.R.layout.simple_spinner_dropdown_item, actions); setSelection(actions.indexOf(mode).coerceAtLeast(0)); onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { mode=actions[position] }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) { }
        } }
        layout.addView(selector)
        val dlg = android.app.AlertDialog.Builder(this).setTitle("Editar ${KeyEvent.keyCodeToString(control.keyCode)}")
            .setView(layout).setPositiveButton("SALVAR") { _,_ -> scope.launch { db.controls().update(control.copy(size=(seek.progress+32).toFloat(), action=mode)); reloadEditor() } }
            .setNeutralButton("EXCLUIR") { _,_ -> scope.launch { db.controls().delete(control); reloadEditor() } }
            .setNegativeButton("CANCELAR", null).create()
        dlg.window?.setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        dlg.show()
        dlg.window?.setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
    }
    private fun closeEditor() {
        editorOpen = false; capturing = false; capturingAt = null
        remove(editor); editor = null; editorRoot = null; editorStatus = null
        refreshControls()
    }
    private fun remove(view: View?) { if (view != null) runCatching { wm.removeView(view) } }
    private fun stopOverlay() {
        closeEditor(); remove(optionsPanel); optionsPanel = null
        remove(bubble); bubble = null; bubbleParams = null
    }
    companion object { @Volatile var instance: MapperAccessibilityService? = null; private set }
}
