package com.mobilador.prox.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import com.mobilador.prox.data.GameProfile
import com.mobilador.prox.engine.InputLogic
import kotlin.math.hypot

/** Real relative-mouse experiment in OUR OWN focused view; not global game camera capture. */
class AimCalibrationView(context: Context, var profile: GameProfile) : View(context) {
    private var x = 0.5f
    private var y = 0.5f
    private var previousX: Float? = null
    private var previousY: Float? = null
    private var lastDx = 0f; private var lastDy = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    init { isFocusable = true; isFocusableInTouchMode = true; setBackgroundColor(Color.rgb(11, 14, 33)) }
    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (!event.isFromSource(InputDevice.SOURCE_MOUSE)) return super.onGenericMotionEvent(event)
        if (event.actionMasked == MotionEvent.ACTION_HOVER_MOVE || event.actionMasked == MotionEvent.ACTION_MOVE) {
            val dx = if (previousX == null) 0f else event.x - previousX!!
            val dy = if (previousY == null) 0f else event.y - previousY!!
            previousX = event.x; previousY = event.y
            move(dx, dy)
            return true
        }
        if (event.actionMasked == MotionEvent.ACTION_HOVER_EXIT) { previousX = null; previousY = null }
        return super.onGenericMotionEvent(event)
    }
    override fun onCapturedPointerEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_MOVE) {
            move(event.getAxisValue(MotionEvent.AXIS_RELATIVE_X), event.getAxisValue(MotionEvent.AXIS_RELATIVE_Y))
            return true
        }
        return super.onCapturedPointerEvent(event)
    }
    private fun move(rawX: Float, rawY: Float) {
        val dx = InputLogic.aimDelta(rawX, profile.sensitivityX, profile.deadzone, profile.acceleration, profile.invertX)
        val dy = InputLogic.aimDelta(rawY, profile.sensitivityY, profile.deadzone, profile.acceleration, profile.invertY, profile.upwardBoost)
        val smooth = (profile.smoothing / 100f).coerceIn(0f, 0.95f)
        lastDx = lastDx * smooth + dx * (1f - smooth)
        lastDy = lastDy * smooth + dy * (1f - smooth)
        if (width > 0 && height > 0) { x = (x + lastDx / width).coerceIn(0.04f, 0.96f); y = (y + lastDy / height).coerceIn(0.04f, 0.96f) }
        invalidate()
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        paint.color = Color.rgb(35, 37, 72); paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f
        for (i in 1..4) { canvas.drawLine(w*i/5,0f,w*i/5,h,paint);canvas.drawLine(0f,h*i/5,w,h*i/5,paint) }
        paint.color = Color.rgb(127, 92, 255); paint.strokeWidth = 5f
        canvas.drawCircle(w*.5f,h*.5f,50f,paint)
        val cx = w*x; val cy = h*y
        paint.color = Color.rgb(0, 235, 243); paint.strokeWidth = 4f
        canvas.drawCircle(cx,cy,21f,paint)
        canvas.drawLine(cx-39,cy,cx-10,cy,paint);canvas.drawLine(cx+10,cy,cx+39,cy,paint)
        canvas.drawLine(cx,cy-39,cx,cy-10,paint);canvas.drawLine(cx,cy+10,cx,cy+39,paint)
        paint.style = Paint.Style.FILL; paint.textSize = 27f; paint.color = Color.WHITE
        canvas.drawText("TREINO DE MIRA · SOMENTE NESTA TELA",22f,36f,paint)
        canvas.drawText("X ${profile.sensitivityX.toInt()}%   Y ${profile.sensitivityY.toInt()}%",22f,75f,paint)
    }
}
