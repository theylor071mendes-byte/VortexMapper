package com.mobilador.prox.engine

/** Pure Kotlin rules; unit-tested without an emulator. */
object InputLogic {
    fun normalize(value: Float): Float = value.coerceIn(0.03f, 0.97f)
    fun isClick(action: Int, buttonPrimary: Boolean): Boolean =
        action == 0 && buttonPrimary // ACTION_DOWN (never ACTION_HOVER_MOVE or motion-only)
    fun shouldPress(isDown: Boolean, repeatCount: Int, alreadyDown: Boolean): Boolean =
        isDown && repeatCount == 0 && !alreadyDown
    fun canAddProfile(current: Int, verifiedPremium: Boolean): Boolean = verifiedPremium || current < 2
    fun aimDelta(raw: Float, percent: Float, deadzone: Float, acceleration: Float, inverted: Boolean, upBoost: Float = 100f): Float {
        if (kotlin.math.abs(raw) < deadzone) return 0f
        val amplitude = kotlin.math.abs(raw)
        val factor = 1f + acceleration.coerceIn(0f, 2f) * amplitude / 300f
        val up = if (raw < 0f) upBoost.coerceIn(1f, 200f) / 100f else 1f
        return raw * percent.coerceIn(1f, 200f) / 100f * factor * up * if (inverted) -1f else 1f
    }
}
class HeldKeyState {
    private val pressed = mutableSetOf<Int>()
    fun onDown(code: Int, repeat: Int): Boolean = InputLogic.shouldPress(true, repeat, code in pressed).also { if (it) pressed += code }
    fun onUp(code: Int): Boolean = pressed.remove(code)
    fun clear() = pressed.clear()
    fun isPressed(code: Int) = code in pressed
    fun snapshot() = pressed.toSet()
}
