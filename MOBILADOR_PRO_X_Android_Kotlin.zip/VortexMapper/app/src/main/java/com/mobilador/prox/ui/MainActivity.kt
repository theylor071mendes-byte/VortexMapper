package com.mobilador.prox.ui

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.hardware.input.InputManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import com.mobilador.prox.data.*
import com.mobilador.prox.engine.InputLogic
import com.mobilador.prox.premium.PremiumClient
import com.mobilador.prox.service.MapperAccessibilityService
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.ui.graphics.toArgb

private val Ink = Color(0xFF080B15)
private val CardColor = Color(0xFF16152B)
private val Violet = Color(0xFF8E65FF)
private val Blue = Color(0xFF00E6F4)
private val Grey = Color(0xFFADB0CA)
private val Pink = Color(0xFFFF6FCF)
private enum class Tab { JOGOS, CONTROLES, PRECISION, AJUSTES, PREMIUM }

class MainActivity : ComponentActivity() {
    private val db by lazy { MapperDatabase.get(applicationContext) }
    private val settings by lazy { SettingsStore(applicationContext) }
    private val premium by lazy { PremiumClient(applicationContext) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
    private fun hasService(): Boolean {
        val manager = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName && it.resolveInfo.serviceInfo.name.endsWith("MapperAccessibilityService") }
    }
    private fun launch(profile: GameProfile) {
        val i = packageManager.getLaunchIntentForPackage(profile.packageName)
        if (i != null) startActivity(i) else Toast.makeText(this, "Não foi possível iniciar este jogo", Toast.LENGTH_LONG).show()
    }
    private fun installedApps(): List<Pair<String, String>> {
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(launcher, 0).map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
    }
    @Composable private fun App() {
        val scope = rememberCoroutineScope()
        val profiles by db.profiles().observeAll().collectAsState(initial = emptyList())
        val selectedId by settings.selectedProfile.collectAsState(initial = 0L)
        val mappingOn by settings.mappingEnabled.collectAsState(initial = false)
        val pointerSpeed by settings.pointerSpeed.collectAsState(initial = 0)
        val systemPointer by settings.applySystemPointer.collectAsState(initial = false)
        val premiumOn by premium.entitled.collectAsState()
        val premiumStatus by premium.status.collectAsState()
        var page by remember { mutableStateOf(if (intent.getBooleanExtra("open_calibration", false)) Tab.PRECISION else if (intent.getBooleanExtra("open_settings", false)) Tab.AJUSTES else Tab.JOGOS) }
        var choosing by remember { mutableStateOf(false) }
        var pendingStart by remember { mutableStateOf<GameProfile?>(null) }
        val selected = profiles.firstOrNull { it.id == selectedId } ?: profiles.firstOrNull()
        var peripheralVersion by remember { mutableIntStateOf(0) }
        DisposableEffect(Unit) {
            val manager = getSystemService(Context.INPUT_SERVICE) as InputManager
            val listener = object : InputManager.InputDeviceListener {
                override fun onInputDeviceAdded(deviceId: Int) { peripheralVersion++ }
                override fun onInputDeviceRemoved(deviceId: Int) { peripheralVersion++ }
                override fun onInputDeviceChanged(deviceId: Int) { peripheralVersion++ }
            }
            manager.registerInputDeviceListener(listener, null)
            onDispose { manager.unregisterInputDeviceListener(listener) }
        }
        val devices = remember(peripheralVersion) { InputDevice.getDeviceIds().mapNotNull { InputDevice.getDevice(it) } }
        val mouseFound = devices.any { !it.isVirtual && it.supportsSource(InputDevice.SOURCE_MOUSE) }
        val keyboardFound = devices.any { !it.isVirtual && it.supportsSource(InputDevice.SOURCE_KEYBOARD) && it.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC }
        MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Ink, surface = CardColor, onSurface = Color.White)) {
            Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Ink, Color(0xFF111027), Ink)))) {
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 18.dp, top = 24.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("MOBILADOR", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                        Text("PRO X   /   MOBILE KEYMAPPING", color = Blue, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Surface(shape = RoundedCornerShape(50), color = if (mappingOn) Color(0xFF214F4E) else Color(0xFF302644)) {
                        Text(if (mappingOn) "●  ATIVO" else "●  PAUSADO", color = if (mappingOn) Blue else Grey, modifier = Modifier.padding(10.dp), fontSize = 11.sp)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusChip("MOUSE", mouseFound, Modifier.weight(1f))
                    StatusChip("TECLADO", keyboardFound, Modifier.weight(1f))
                }
                Spacer(Modifier.height(15.dp))
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (page) {
                        Tab.JOGOS -> GamesPanel(profiles, selected, onAdd = { choosing=true }, onChoose = { scope.launch { settings.setSelected(it.id) } }, onLaunch = { p ->
                            scope.launch { settings.setSelected(p.id); settings.setEnabled(true); if (hasService()) launch(p) else pendingStart=p }
                        }, onRemove = { p -> scope.launch { db.profiles().delete(p); if (selectedId == p.id) settings.setSelected(0) } })
                        Tab.CONTROLES -> ControlsPanel(selected, db)
                        Tab.PRECISION -> PrecisionPanel(selected, premiumOn) { update -> scope.launch { db.profiles().update(update) } }
                        Tab.AJUSTES -> SettingsPanel(selected, pointerSpeed, systemPointer, mappingOn,
                            onSpeed = { scope.launch { settings.setPointerSpeed(it) } }, onSystem = { on ->
                                if (on && !Settings.System.canWrite(this@MainActivity)) {
                                    startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
                                    Toast.makeText(this@MainActivity,"Depois de autorizar, volte e ative a opção",Toast.LENGTH_LONG).show()
                                } else scope.launch { settings.setApplySystemPointer(on) }
                            }, onEnabled = { scope.launch { settings.setEnabled(it) } }, onSuspendKey = { code -> selected?.let { p -> scope.launch { db.profiles().update(p.copy(suspendKey = code)) } } })
                        Tab.PREMIUM -> PremiumPanel(premiumOn, premiumStatus, premium, this@MainActivity, scope,
                            onUpload = {
                                scope.launch {
                                    val dump = JSONArray()
                                    profiles.forEach { p ->
                                        val keys = JSONArray(); db.controls().forProfile(p.id).forEach { c ->
                                            keys.put(JSONObject().put("keyCode",c.keyCode).put("x",c.x.toDouble()).put("y",c.y.toDouble()).put("size",c.size.toDouble()).put("action",c.action))
                                        }
                                        dump.put(JSONObject().put("packageName",p.packageName).put("title",p.title).put("sensitivityX",p.sensitivityX.toDouble()).put("sensitivityY",p.sensitivityY.toDouble()).put("keys",keys))
                                    }
                                    val ok = premium.uploadBackup(JSONObject().put("profiles",dump))
                                    Toast.makeText(this@MainActivity, if (ok) "Backup salvo no servidor" else "Backup não disponível", Toast.LENGTH_LONG).show()
                                }
                            })
                    }
                }
                NavigationBar(containerColor = Color(0xFF111127), tonalElevation = 0.dp) {
                    val entries = listOf(Triple(Tab.JOGOS, Icons.Filled.SportsEsports, "JOGOS"), Triple(Tab.CONTROLES, Icons.Filled.Keyboard, "TECLAS"), Triple(Tab.PRECISION, Icons.Filled.GpsFixed, "MIRA"), Triple(Tab.AJUSTES, Icons.Filled.Tune, "AJUSTES"), Triple(Tab.PREMIUM, Icons.Filled.WorkspacePremium, "PRO"))
                    entries.forEach { (tab, icon, name) ->
                        NavigationBarItem(selected=page==tab, onClick={page=tab}, icon={Icon(icon, contentDescription=name)}, label={Text(name, fontSize=9.sp)}, colors=NavigationBarItemDefaults.colors(selectedIconColor=Blue, selectedTextColor=Blue, indicatorColor=Color(0xFF302255), unselectedIconColor=Grey, unselectedTextColor=Grey))
                    }
                }
            }
            if (choosing) {
                val apps = remember { installedApps() }
                var search by remember { mutableStateOf("") }
                AlertDialog(onDismissRequest={choosing=false}, title={Text("ADICIONAR JOGO")}, text={
                    Column(Modifier.heightIn(max=460.dp)) {
                        OutlinedTextField(search, {search=it}, label={Text("Procurar aplicativo")}, singleLine=true)
                        LazyColumn { items(apps.filter { it.second.contains(search, ignoreCase=true) }) { (pkg, title) ->
                            Text(title, Modifier.fillMaxWidth().clickable {
                                choosing=false
                                scope.launch {
                                    val already = db.profiles().byPackage(pkg)
                                    if (already != null) {settings.setSelected(already.id);return@launch}
                                    if (!InputLogic.canAddProfile(profiles.size, premiumOn)) { Toast.makeText(this@MainActivity,"O plano gratuito permite 2 perfis",Toast.LENGTH_LONG).show();page=Tab.PREMIUM;return@launch }
                                    settings.setSelected(db.profiles().insert(GameProfile(packageName=pkg,title=title)))
                                }
                            }.padding(vertical=12.dp))
                        } }
                    }
                }, confirmButton={TextButton(onClick={choosing=false}){Text("FECHAR")}})
            }
            if (pendingStart != null) AlertDialog(onDismissRequest={pendingStart=null},
                title={Text("ATIVAR MAPEAMENTO")}, text={Text("Para converter teclas físicas em gestos, ative MOBILADOR PRO X — Controles em Acessibilidade. O Android pode limitar esse acesso. Depois volte e toque em INICIAR MAPEADOR novamente.")},
                confirmButton={TextButton(onClick={pendingStart=null;startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}){Text("ABRIR ACESSIBILIDADE")}},
                dismissButton={TextButton(onClick={pendingStart=null}){Text("CANCELAR")}})
        }
    }
}

@Composable private fun StatusChip(title:String, connected:Boolean, modifier:Modifier=Modifier) {
    Row(modifier.clip(RoundedCornerShape(13.dp)).background(CardColor).border(1.dp,Color(0xFF302B54),RoundedCornerShape(13.dp)).padding(11.dp), verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).clip(RoundedCornerShape(20.dp)).background(if(connected) Blue else Pink))
        Spacer(Modifier.width(8.dp)); Text(title, fontSize=11.sp, fontWeight=FontWeight.Bold); Spacer(Modifier.weight(1f))
        Text(if(connected) "CONECTADO" else "AUSENTE", color=if(connected) Blue else Grey, fontSize=9.sp)
    }
}
@Composable private fun Header(title:String,desc:String){Column(Modifier.padding(bottom=14.dp)){Text(title,color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Black);Text(desc,color=Grey,fontSize=12.sp)}}
@Composable private fun Panel(modifier:Modifier=Modifier, content:@Composable ColumnScope.()->Unit) {
    Column(modifier.clip(RoundedCornerShape(22.dp)).background(CardColor).border(1.dp,Color(0xFF2F2854),RoundedCornerShape(22.dp)).padding(16.dp),content=content)
}
@Composable private fun PrimaryButton(text:String, modifier:Modifier=Modifier, onClick:()->Unit){
    Button(onClick=onClick,modifier=modifier.height(52.dp),shape=RoundedCornerShape(14.dp), colors=ButtonDefaults.buttonColors(containerColor=Violet)) { Text(text,fontWeight=FontWeight.Black,letterSpacing=1.sp) }
}
@Composable private fun GamesPanel(profiles:List<GameProfile>,selected:GameProfile?, onAdd:()->Unit, onChoose:(GameProfile)->Unit,onLaunch:(GameProfile)->Unit,onRemove:(GameProfile)->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=18.dp)) {
        Header("SEUS JOGOS", "Perfis individuais, comandos reais e acesso rápido")
        Panel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment=Alignment.CenterVertically){
                Box(Modifier.size(74.dp).clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(Violet,Color(0xFF3631A4)))),contentAlignment=Alignment.Center){Icon(Icons.Filled.SportsEsports,null,tint=Color.White,modifier=Modifier.size(38.dp))}
                Spacer(Modifier.width(16.dp))
                Column { Text("PRONTO PARA JOGAR?",fontWeight=FontWeight.Black,fontSize=17.sp); Spacer(Modifier.height(5.dp));Text(selected?.title?:"Adicione seu primeiro jogo",color=Blue,fontSize=14.sp) }
            }
            Spacer(Modifier.height(16.dp))
            PrimaryButton("▶  INICIAR MAPEADOR",Modifier.fillMaxWidth()){ if (selected != null) onLaunch(selected) else onAdd() }
            Spacer(Modifier.height(8.dp))
            Text("O serviço será ativado somente com sua permissão. A bolha X aparece ao entrar no jogo selecionado.",color=Grey,fontSize=11.sp)
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){ Text("BIBLIOTECA",fontWeight=FontWeight.ExtraBold,fontSize=16.sp);Spacer(Modifier.weight(1f));TextButton(onClick=onAdd){Icon(Icons.Filled.Add,null);Text("ADICIONAR")}}
        profiles.forEach { profile ->
            Panel(Modifier.fillMaxWidth().padding(bottom=10.dp).clickable { onChoose(profile) }) {
                Row(verticalAlignment=Alignment.CenterVertically){
                    GameIcon(profile.packageName)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {Text(profile.title,fontSize=16.sp,fontWeight=FontWeight.Bold);Text(if(profile.id==selected?.id) "● PERFIL SELECIONADO" else "TOQUE PARA SELECIONAR",color=if(profile.id==selected?.id) Blue else Grey,fontSize=10.sp)}
                    IconButton(onClick={onRemove(profile)}) { Icon(Icons.Filled.DeleteOutline,"Excluir",tint=Grey) }
                }
            }
        }
        if (profiles.isEmpty()) Text("Seus jogos aparecerão aqui depois de adicioná-los.",color=Grey,fontSize=13.sp)
        Spacer(Modifier.height(24.dp))
    }
}
@Composable private fun GameIcon(pkg:String) {
    val context=LocalContext.current
    val bitmap=remember(pkg){runCatching {
        val drawable=context.packageManager.getApplicationIcon(pkg)
        val bmp=Bitmap.createBitmap(96,96,Bitmap.Config.ARGB_8888)
        drawable.setBounds(0,0,96,96);drawable.draw(android.graphics.Canvas(bmp));bmp
    }.getOrNull()}
    if(bitmap!=null) Image(bitmap.asImageBitmap(),null,Modifier.size(57.dp).clip(RoundedCornerShape(13.dp)))
    else Icon(Icons.Filled.SportsEsports,null,Modifier.size(57.dp),tint=Violet)
}
@Composable private fun ControlsPanel(profile:GameProfile?, db:MapperDatabase) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=18.dp)) {
        Header("EDITOR KEYMAP", "Toque duplo sobre o jogo para criar um botão")
        if(profile==null){Text("Selecione um jogo na aba JOGOS",color=Grey);return@Column}
        val controlList by remember(profile.id) { db.controls().observe(profile.id) }.collectAsState(initial=emptyList())
        Panel(Modifier.fillMaxWidth()) {
            Text("COMO EDITAR",color=Blue,fontWeight=FontWeight.Black)
            Spacer(Modifier.height(8.dp))
            Text("1. Inicie o jogo com o mapeador ativo.\n2. Toque na bolha X > EDITAR KEYMAP.\n3. Toque duas vezes em uma área vazia.\n4. Pressione uma tecla física.\n5. Arraste o botão; segure para redimensionar, alternar TAP/HOLD ou excluir.\n6. Toque SALVAR / SAIR.",color=Color.White,fontSize=13.sp,lineHeight=22.sp)
        }
        Spacer(Modifier.height(16.dp));Text("CONTROLES SALVOS · ${controlList.size}",fontWeight=FontWeight.Bold,color=Blue)
        controlList.forEach { item ->
            Row(Modifier.fillMaxWidth().padding(top=8.dp).clip(RoundedCornerShape(12.dp)).background(CardColor).padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                Icon(Icons.Filled.Keyboard,null,tint=Violet);Spacer(Modifier.width(12.dp))
                Text(KeyEvent.keyCodeToString(item.keyCode).removePrefix("KEYCODE_"),Modifier.weight(1f),fontWeight=FontWeight.Bold)
                Text(item.action,color=Blue,fontSize=12.sp)
            }
        }
        Text("Mapeamentos HOLD usam gestos contínuos de acessibilidade e podem sofrer cancelamento pelo Android ou pelo jogo.",fontSize=11.sp,color=Grey,modifier=Modifier.padding(vertical=14.dp))
    }
}
@Composable private fun NumericSetting(name:String,description:String,value:Float,range:ClosedFloatingPointRange<Float>,unit:String,onDone:(Float)->Unit) {
    var local by remember(value) { mutableFloatStateOf(value) }
    Column(Modifier.padding(vertical=7.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(name,fontWeight=FontWeight.Bold,fontSize=14.sp);Text(description,color=Grey,fontSize=11.sp)};Text("${local.toInt()}$unit",color=Blue,fontWeight=FontWeight.Black)}
        Slider(value=local,onValueChange={local=it},onValueChangeFinished={onDone(local)},valueRange=range,colors=SliderDefaults.colors(thumbColor=Blue,activeTrackColor=Violet))
    }
}
@Composable private fun PrecisionPanel(profile:GameProfile?,premium:Boolean,save:(GameProfile)->Unit) {
    var calibrator by remember { mutableStateOf<AimCalibrationView?>(null) }
    var showTest by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=18.dp)) {
        Header("PRECISION AIM CONTROL", "Controle manual · Sem aimbot · Sem modificar o jogo")
        if(profile==null){Text("Adicione um jogo para calibrar.",color=Grey);return@Column}
        Panel(Modifier.fillMaxWidth()) {
            NumericSetting("CÂMERA HORIZONTAL (X)","Resposta do movimento esquerdo/direito",profile.sensitivityX,1f..200f,"%") {save(profile.copy(sensitivityX=it))}
            NumericSetting("CÂMERA VERTICAL (Y)","Resposta do movimento cima/baixo",profile.sensitivityY,1f..200f,"%") {save(profile.copy(sensitivityY=it))}
            NumericSetting("MOVIMENTO PARA CIMA", "Multiplicador somente do movimento físico ascendente",profile.upwardBoost,1f..200f,"%") { save(profile.copy(upwardBoost=it)) }
            if (premium) {
                NumericSetting("ACELERAÇÃO PRO", "0 desativa o ganho por velocidade",profile.acceleration,0f..2f,"x") { save(profile.copy(acceleration=it)) }
                NumericSetting("SUAVIZAÇÃO PRO", "Filtro para movimentos abruptos",profile.smoothing,0f..95f,"%") {save(profile.copy(smoothing=it))}
                NumericSetting("ZONA MORTA PRO", "Ignora pequenos movimentos involuntários",profile.deadzone,0f..20f,"px") {save(profile.copy(deadzone=it))}
            } else {
                Text("Curvas avançadas, aceleração e filtros personalizáveis: disponíveis após validação Premium no servidor.",color=Grey,fontSize=12.sp)
            }
            Row(verticalAlignment=Alignment.CenterVertically) { Text("Inverter X",Modifier.weight(1f));Switch(checked=profile.invertX,onCheckedChange={save(profile.copy(invertX=it))}) }
            Row(verticalAlignment=Alignment.CenterVertically) { Text("Inverter Y",Modifier.weight(1f));Switch(checked=profile.invertY,onCheckedChange={save(profile.copy(invertY=it))}) }
        }
        Spacer(Modifier.height(12.dp))
        Panel(Modifier.fillMaxWidth()) {
            Text("PERFIS DE TESTE POR ARMA", fontWeight=FontWeight.Black, color=Blue)
            Text("Predefinições de calibração manual. Não detectam sua arma no jogo.",fontSize=11.sp,color=Grey,modifier=Modifier.padding(vertical=8.dp))
            val presets=listOf(
                Triple("DESERT",115f,92f),Triple("UMP",85f,75f),
                Triple("XM8",70f,65f),Triple("SHOTGUN",96f,80f)
            )
            presets.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    pair.forEach { (name, sx, sy) ->
                        OutlinedButton(onClick={save(profile.copy(sensitivityX=sx,sensitivityY=sy))},
                            enabled=premium,modifier=Modifier.weight(1f)) {Text(name,fontSize=11.sp)}
                    }
                }
            }
            if (!premium) Text("Exige assinatura verificada; os ajustes X/Y manuais acima continuam gratuitos.",fontSize=11.sp,color=Pink)
        }
        Spacer(Modifier.height(12.dp))
        PrimaryButton(if(showTest) "FECHAR CALIBRAÇÃO" else "ABRIR TESTE DE MIRA",Modifier.fillMaxWidth()) {showTest=!showTest}
        if(showTest){
            Spacer(Modifier.height(12.dp))
            AndroidView(factory={ctx->AimCalibrationView(ctx,profile).also{calibrator=it}},update={it.profile=profile},modifier=Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(18.dp)))
            TextButton(onClick={calibrator?.requestFocus();calibrator?.requestPointerCapture()}) {Text("CAPTURAR MOUSE NESTA TELA")}
            TextButton(onClick={calibrator?.releasePointerCapture()}) {Text("LIBERAR MOUSE")}
            Text("A captura de mouse aqui funciona somente enquanto esta tela do app estiver em foco. O Android não fornece captura global equivalente dentro do Free Fire.",color=Grey,fontSize=11.sp)
        }
        Spacer(Modifier.height(20.dp))
    }
}
@Composable private fun SettingsPanel(profile:GameProfile?, speed:Int, applySystem:Boolean, enabled:Boolean, onSpeed:(Int)->Unit,onSystem:(Boolean)->Unit,onEnabled:(Boolean)->Unit,onSuspendKey:(Int)->Unit){
    var choosingKey by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=18.dp)) {
        Header("CONFIGURAÇÕES", "Entrada física, ponteiro e privacidade")
        Panel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment=Alignment.CenterVertically){Text("MAPEAMENTO ATIVO",Modifier.weight(1f),fontWeight=FontWeight.Bold);Switch(enabled, onEnabled)}
            NumericSetting("VELOCIDADE DO PONTEIRO", "-7 muito lento · +7 muito rápido",speed.toFloat(),-7f..7f,"") {onSpeed(it.toInt())}
            Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("APLICAR AO SISTEMA AO ENTRAR",fontSize=13.sp,fontWeight=FontWeight.Bold);Text("Exige permissão adicional; restaura ao sair. Alguns celulares ignoram esta configuração.",color=Grey,fontSize=11.sp)};Switch(applySystem,onSystem)}
        }
        Spacer(Modifier.height(14.dp))
        Panel(Modifier.fillMaxWidth()) {
            Text("TECLA PARA ALTERNAR VELOCIDADE",fontWeight=FontWeight.Black,color=Blue)
            Text(if(profile==null) "Selecione um jogo" else KeyEvent.keyCodeToString(profile.suspendKey).removePrefix("KEYCODE_"),fontSize=19.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=12.dp))
            OutlinedButton(onClick={choosingKey=true},enabled=profile!=null){Text("ESCOLHER TECLA")}
            Text("No jogo, esse atalho alterna entre velocidade configurada e velocidade normal. Não prende nem libera globalmente a câmera do Free Fire.",color=Grey,fontSize=11.sp)
        }
        Spacer(Modifier.height(14.dp))
        Panel(Modifier.fillMaxWidth()) {
            Text("PRIVACIDADE E PERMISSÕES",color=Blue,fontWeight=FontWeight.Black)
            Text("Acessibilidade é usada exclusivamente para converter teclas autorizadas em toques. Não há leitura de tela, adversários, contas ou memória do jogo. Desative a qualquer momento nas configurações do Android.",color=Grey,fontSize=12.sp)
        }
    }
    if(choosingKey){
        val options=listOf(KeyEvent.KEYCODE_F8,KeyEvent.KEYCODE_F9,KeyEvent.KEYCODE_CTRL_LEFT,KeyEvent.KEYCODE_ALT_LEFT,KeyEvent.KEYCODE_SHIFT_LEFT,KeyEvent.KEYCODE_TAB,KeyEvent.KEYCODE_CAPS_LOCK,KeyEvent.KEYCODE_X,KeyEvent.KEYCODE_C)
        AlertDialog(onDismissRequest={choosingKey=false},title={Text("TECLA DE ALTERNÂNCIA")},text={Column{options.forEach{key -> Text(KeyEvent.keyCodeToString(key).removePrefix("KEYCODE_"),modifier=Modifier.fillMaxWidth().clickable{onSuspendKey(key);choosingKey=false}.padding(vertical=10.dp))}}},confirmButton={TextButton(onClick={choosingKey=false}){Text("FECHAR")}})
    }
}
@Composable private fun PremiumPanel(entitled:Boolean,status:String,client:PremiumClient,activity:ComponentActivity,scope:kotlinx.coroutines.CoroutineScope,onUpload:()->Unit) {
    var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=18.dp)) {
        Header("PRO X PREMIUM", "Funcionalidades liberadas somente por validação no servidor")
        Panel(Modifier.fillMaxWidth()) {
            Text(if(entitled) "● PREMIUM ATIVO" else "○ PLANO GRATUITO",color=if(entitled) Blue else Pink,fontWeight=FontWeight.Black)
            Text(status,color=Grey,fontSize=12.sp,modifier=Modifier.padding(vertical=10.dp))
            Text("GRATUITO",fontWeight=FontWeight.Black,color=Color.White)
            Text("✓ 2 perfis, controles, configurações X/Y e editor de keymap",fontSize=12.sp,color=Grey)
            Spacer(Modifier.height(14.dp))
            Text("PREMIUM",fontWeight=FontWeight.Black,color=Blue)
            Text("✓ Perfis ilimitados e backup remoto\n✓ Recursos avançados conforme forem implementados e validados",fontSize=12.sp,color=Grey)
            Text("Preço: definido na oferta oficial do Google Play. Não há valor simulado.",fontSize=11.sp,color=Grey,modifier=Modifier.padding(top=10.dp))
        }
        Spacer(Modifier.height(14.dp))
        if(!client.configured){
            Panel(Modifier.fillMaxWidth()){Text("ASSINATURAS NÃO CONFIGURADAS",color=Pink,fontWeight=FontWeight.Black);Text("Para ativar compras e backup em nuvem, é preciso implantar o servidor incluído no ZIP e configurar um produto real no Google Play Console. Os controles de pagamento permanecem indisponíveis até lá.",fontSize=12.sp,color=Grey)}
        }else{
            Panel(Modifier.fillMaxWidth()){
                OutlinedTextField(email,{email=it},label={Text("E-mail")},singleLine=true,modifier=Modifier.fillMaxWidth())
                OutlinedTextField(password,{password=it},label={Text("Senha")},singleLine=true,modifier=Modifier.fillMaxWidth(), visualTransformation=androidx.compose.ui.text.input.PasswordVisualTransformation())
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    TextButton(onClick={scope.launch{client.login(email,password)}}){Text("ENTRAR")}
                    TextButton(onClick={scope.launch{client.login(email,password,true)}}){Text("CADASTRAR")}
                }
                PrimaryButton("ASSINAR PELO GOOGLE PLAY",Modifier.fillMaxWidth()) {client.subscribe(activity)}
                TextButton(onClick={scope.launch{client.refresh()}}){Text("VERIFICAR ASSINATURA")}
                if(entitled) OutlinedButton(onClick=onUpload) {Text("ENVIAR BACKUP PARA NUVEM")}
                TextButton(onClick=client::signOut){Text("SAIR DA CONTA")}
            }
        }
    }
}
