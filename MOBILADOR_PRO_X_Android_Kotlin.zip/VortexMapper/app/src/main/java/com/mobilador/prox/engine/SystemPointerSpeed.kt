package com.mobilador.prox.engine

import android.content.Context
import android.os.Build
import android.provider.Settings

/** Only touches the public Settings.System setting with explicit WRITE_SETTINGS grant. OEMs may ignore it. */
class SystemPointerSpeed(private val context: Context) {
    private var original: Int? = null
    fun applyIfPermitted(speed: Int): Boolean {
        if (!Settings.System.canWrite(context)) return false
        return runCatching {
            if (original == null) original = Settings.System.getInt(context.contentResolver, "pointer_speed", 0)
            Settings.System.putInt(context.contentResolver, "pointer_speed", speed.coerceIn(-7, 7))
        }.getOrDefault(false)
    }
    fun restore() {
        val old = original ?: return
        if (Settings.System.canWrite(context)) runCatching {
            Settings.System.putInt(context.contentResolver, "pointer_speed", old)
        }
        original = null
    }
}
