package com.mobilador.prox
import com.mobilador.prox.engine.*
import org.junit.Assert.*
import org.junit.Test

class InputLogicTest {
    @Test fun hoverNeverClicks() {
        assertFalse(InputLogic.isClick(7, true)) // ACTION_HOVER_MOVE
        assertFalse(InputLogic.isClick(2, true)) // ACTION_MOVE
        assertFalse(InputLogic.isClick(0, false))
        assertTrue(InputLogic.isClick(0, true))
    }
    @Test fun repeatsAndReleases() {
        val s = HeldKeyState()
        assertTrue(s.onDown(29, 0)); assertFalse(s.onDown(29, 0)); assertFalse(s.onDown(29, 3))
        assertTrue(s.onUp(29)); assertFalse(s.isPressed(29)); assertFalse(s.onUp(29))
        assertTrue(s.onDown(29, 0)); s.clear(); assertTrue(s.snapshot().isEmpty())
    }
    @Test fun positionsStayOnDisplay() {
        assertEquals(0.03f, InputLogic.normalize(-1f), 0.00001f)
        assertEquals(0.97f, InputLogic.normalize(9f), 0.00001f)
    }
    @Test fun entitlementGatesLimit() {
        assertFalse(InputLogic.canAddProfile(2, false))
        assertTrue(InputLogic.canAddProfile(100, true))
    }
    @Test fun independentCameraAxesAndUpwardMovement() {
        assertEquals(0f, InputLogic.aimDelta(1f, 100f, 2f, 0f, false), 0.001f)
        assertEquals(10f, InputLogic.aimDelta(10f, 100f, 0f, 0f, false), 0.001f)
        assertEquals(-20f, InputLogic.aimDelta(-10f, 100f, 0f, 0f, false, 200f), 0.001f)
        assertEquals(-10f, InputLogic.aimDelta(10f, 100f, 0f, 0f, true), 0.001f)
    }
}
