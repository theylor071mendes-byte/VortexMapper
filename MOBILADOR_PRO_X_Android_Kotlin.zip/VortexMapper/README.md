# MOBILADOR PRO X — versão de desenvolvimento (beta)

Aplicativo Android em **Kotlin + Jetpack Compose** com editor de teclado para jogos, perfil local por jogo (Room), preferências (DataStore), indicador USB/Bluetooth e painel flutuante de acessibilidade. **Código-fonte para compilar; APK ainda não compilado nem validado em dispositivo real.**

## O que funciona no código

- Selecionar aplicativos instalados e criar até **2 perfis** no modo gratuito.
- Iniciar o aplicativo escolhido e exibir uma bolha flutuante quando o serviço percebe o jogo em primeiro plano.
- Abrir **EDITAR KEYMAP**, tocar 2 vezes na tela, pressionar uma tecla física e salvar a posição relativa.
- Arrastar controles; pressionar e manter o botão no editor para alterar tamanho e modo TAP/HOLD ou excluir.
- Interceptar teclas mapeadas pelo serviço de acessibilidade habilitado pelo usuário e enviar gestos via `dispatchGesture`. TAP = toque curto; HOLD = gesto contínuo de melhor esforço; o Android pode cancelar gestos.
- Evitar ativação de teclas repetidas. Não criar toques só por evento `HOVER` ou movimento do mouse.
- Alternar com F8 (ou tecla configurada) a velocidade nativa do ponteiro **somente se** o usuário conceder `WRITE_SETTINGS`. A velocidade escolhida é aplicada ao entrar no jogo e tentamos restaurá-la ao sair. O comportamento depende do fabricante e não equivale a captura de câmera.
- Ajustar X, Y, movimento para cima, inversão de eixo no **teste de calibração dentro do próprio aplicativo**, que usa captura de mouse apenas enquanto essa janela está em foco. Presets por arma no teste exigem estado Premium validado pelo servidor.
- Indicadores de teclado e mouse detectados pelo Android, com suporte a USB OTG ou Bluetooth quando o aparelho reconhecer.
- Preservar perfis Room e preferências DataStore após fechar o app.
- A tela Premium inclui login, assinatura Google Play Billing e backup no servidor **apenas quando o proprietário configurar um backend HTTPS e uma assinatura real na Play Store**. Sem backend, permanece indisponível. A validação do direito Premium é remota, não um botão local. Não existe cobrança pronta ou preço fictício.

## Limitações importantes

- **Não implementa captura global relativa do mouse nem controle garantido da câmera no Free Fire**. APIs públicas Android não oferecem transferência transparente do `requestPointerCapture()` de um app para outro. Sensibilidades X/Y na aba Mira se aplicam ao teste de mira dentro deste app, não alteram o motor do jogo.
- `dispatchGesture` pode competir com toques físicos e cancelar outras injeções; o comportamento com vários HOLDs é experimental. Não prometemos latência zero, ausência de cliques fantasmas ou compatibilidade com todos os jogos/anticheats.
- Não são implementados: ajuste específico para cada arma ativo dentro do Free Fire, curva gráfica de resposta personalizada, estatísticas de latência medidas, importação/exportação local, assinatura funcionando sem configuração do backend e recuperação de conta. A tela Premium não promete desbloqueá-los imediatamente.
- O Android restringe Serviços de Acessibilidade instalados via APK. O Play Protect pode avisar/bloquear. **Não desative proteções para forçar instalação sem revisar e confiar no código.**
- Em caso de encerramento abrupto do processo, a velocidade nativa do ponteiro pode não ser restaurada; abra Configurações do sistema e ajuste manualmente caso ocorra.
- Permissões explícitas: INTERNET para Premium, WRITE_SETTINGS opcional para ponteiro, e serviço de acessibilidade habilitado manualmente. Não faz root, injeção em jogo nem leitura de memória.

## Compilar em Android Studio

1. Instale Android Studio com JDK 17, SDK Android API 35 e Build Tools 35.0.0.
2. **Abra a pasta `VortexMapper/`**, onde está `settings.gradle.kts`.
3. Sincronize Gradle (AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9) e execute **Build > Build APK(s)**.
4. O debug APK fica em `app/build/outputs/apk/debug/app-debug.apk`.
5. Habilite explicitamente o serviço em Configurações > Acessibilidade, se o Android permitir.

## Pelo GitHub (somente celular)

Se já existe no seu repositório o workflow que extrai `VortexMapper_Android_Projeto.zip` e faz `cd VortexMapper && gradle :app:assembleDebug`, **substitua o ZIP antigo pelo novo com o mesmo nome** e faça Commit. Acesse *Actions*, abra a execução e baixe o arquivo da seção *Artifacts* quando verde. A compilação não está garantida até que o GitHub execute o Gradle de verdade. Não envie só o ZIP dentro de outro ZIP.

Para um repositório novo, extraia o conteúdo da pasta `VortexMapper/` para a raiz (incluindo `.github/workflows/build-apk.yml`). Isso configura Actions para build e testes. Os arquivos em `.github` podem ficar ocultos no gerenciador de arquivos do celular.

## Premium (exige sua infraestrutura)

Confira `server/README.md` e `server/.env.example`. É obrigatório configurar um servidor seguro, produto de assinatura real do Google Play Console, conta de serviço da Google Play Developer API e compilação com `-PPROX_API_URL=https://seu-backend`. O app não inclui chaves, cartões, servidor hospedado, nem credenciais. Não armazene chaves no GitHub. Os endpoints `/billing/verify`, `/entitlement`, `/profiles` conferem a assinatura no servidor.

## Testes

Há testes unitários de regras em `app/src/test/` para hover sem clique, repetição, soltura, coordenadas, limites gratuitos e respostas X/Y. Execute `gradle :app:testDebugUnitTest`. Os testes de tela, jogo real, latência, Android 14+ e compra real ainda precisam ser realizados em dispositivos e contas de teste.

Este é um projeto de desenvolvimento com código verificável; não se trata de mapeador comercial auditado ou certificado.
