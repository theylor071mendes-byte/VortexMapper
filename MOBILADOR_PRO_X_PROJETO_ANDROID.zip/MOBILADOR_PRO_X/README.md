# MOBILADOR PRO X — projeto Android em Kotlin

**Status: código-fonte de uma versão inicial funcional em nível de API, ainda sem validação por APK em dispositivo físico.**

Aplicativo Android para mapear **teclas de teclado físico em gestos de toque**, utilizando o serviço oficial `AccessibilityService.dispatchGesture`, editor visual e perfis locais. Não contém injeção, root, modificações de Free Fire, anti-cheat bypass, aimbot ou leitura de adversários.

## Organização

| Local | Conteúdo |
|---|---|
| `app/src/main/java/.../MainActivity.kt` | Interface Jetpack Compose: início, editor, calibração, perfis, premium, ajustes |
| `app/src/main/java/.../service/` | Serviço de acessibilidade, overlay de jogo/editor e motor de gestos com continuação |
| `app/src/main/java/.../data/Storage.kt` | Banco Room, modelos, DataStore |
| `app/src/main/java/.../input/InputLogic.kt` | Máquina de estados, escala de coordenadas e processador X/Y |
| `app/src/main/java/.../billing/PlayPremium.kt` | Google Play Billing e validação pelo servidor |
| `server/` | Backend Node.js que verifica assinatura no Google Play Developer API |
| `app/src/test/` | Testes locais JVM |
| `tools/bootstrap-src/` | Fonte do iniciador verificado do Gradle Wrapper (explicado abaixo) |

## Abrir no Android Studio (Windows / Linux / macOS)

1. Descompacte o ZIP, mantendo a pasta `MOBILADOR_PRO_X`.
2. Instale Android Studio atual com **SDK Platform Android API 35**, Build Tools, Android SDK e **JDK 17 ou 21** (recomendado JDK 17 para esta configuração).
3. Em **File > Open**, escolha a pasta que possui `settings.gradle.kts`.
4. Permita o download das dependências e a sincronização Gradle (**é necessária conexão à internet**).
5. Se o Android Studio não reconhecer o wrapper criado neste ambiente, rode `gradlew.bat --version` no Terminal (Windows) ou `./gradlew --version` (Linux/macOS), que baixa e verifica o wrapper **oficial** Gradle 8.7 (Android Gradle Plugin 8.6.1). Reabra/sincronize depois.
6. Selecione um aparelho Android com USB debug ativo (recomendado Android 10+) e execute ▶ **Run app**.
7. Para gerar o APK debug, use **Build > Build APK(s)**, ou `./gradlew assembleDebug`. O resultado fica em `app/build/outputs/apk/debug/app-debug.apk` **apenas depois de uma compilação bem-sucedida**.

**Nota sobre o wrapper:** este ambiente não tinha Gradle instalado nem acesso ao download dos binários oficiais. Por isso, `gradle/wrapper/gradle-wrapper.jar` é um **iniciador próprio, não o JAR oficial**: baixa `gradle-8.7-wrapper.jar`, verifica o SHA-256 publicado pelo Gradle e executa-o; em seguida, o wrapper oficial baixa a distribuição 8.7 com SHA-256 fixado. O código-fonte desse iniciador acompanha o projeto. Alternativamente, em uma máquina com Gradle instalado, rode `gradle wrapper --gradle-version 8.7` para gerar o wrapper convencional. Nenhum APK foi compilado aqui.

## Primeiro uso e ativação dos gestos

1. Conecte teclado/mouse por Bluetooth ou USB OTG. O botão **Atualizar conexão** consulta o Android `InputDevice`.
2. Em **Perfis**, escolha seu jogo, com o identificador de pacote exato. Exemplo: Free Fire `com.dts.freefireth` ou Free Fire MAX `com.dts.freefiremax` (confirme a variante instalada no seu aparelho).
3. Em **Controles**, dê dois toques na tela de prévia e pressione a tecla física; depois arraste os marcadores. É possível alternar o modo de cada controle entre toque simples e tecla mantida.
4. Abra a tela inicial e toque **INICIAR MAPEADOR**. Na primeira vez, o Android levará a Configurações de Acessibilidade. Habilite voluntariamente **MOBILADOR PRO X — mapeamento**. Volte ao app e inicie novamente.
5. Abra o jogo do perfil. No painel flutuante, toque **EDITAR POSIÇÕES** para ajustar sobre a imagem do jogo. Dê dois toques numa região vazia para adicionar outro controle; pressione uma tecla física. Arraste um círculo para mover, toque para selecionar e use **MENOR / MAIOR / APAGAR**. Feche o editor.
6. Toque **PARAR MAPEADOR** no painel quando terminar. Desative o serviço nas configurações do Android se não quiser mais o acesso ao teclado.

**Permissões:** Android AccessibilityService precisa de consentimento explícito, `canPerformGestures` e `canRequestFilterKeyEvents`. O serviço escuta alterações de janela apenas para conferir o pacote do jogo selecionado e só envia toques nesse pacote. Não requer permissão SYSTEM_ALERT_WINDOW porque utiliza `TYPE_ACCESSIBILITY_OVERLAY` permitido ao serviço de acessibilidade.

## O que realmente está implementado

- Tema escuro roxo/azul e telas Compose; painel sobreposto com botão minimizar, área arrastável, edição e desligamento.
- Serviço de teclas físicas com filtragem, evitando pressões repetidas e key-up órfão, e sequenciamento de gestos de toque com `StrokeDescription.continueStroke` para pressionamento contínuo. O tempo real dos gestos depende do Android, jogo e dispositivo; outras ações de toque podem cancelá-los.
- Perfis Room persistentes, seleção por pacote de jogo e até 2 no plano gratuito, coordenadas proporcionais 0..1, editor na tela e editor flutuante.
- Dois toques para adicionar somente na área de edição; passar o cursor sobre o marcador não clica.
- Calibração real dentro do próprio aplicativo com X/Y, suavização, zona morta, aceleração, inversão Y; presets básicos de partida.
- Velocidade de calibração e tecla configurável para alterar o **estado do painel**. O painel não trava o cursor do sistema; a alternância de "câmera" é apenas visual e está identificada como tal.
- Premium: integração com Google Play Billing, verificação obrigatória no backend e permissões locais bloqueadas quando o servidor está ausente; dois benefícios Premium implementados: número de perfis ilimitados, importação/exportação JSON, além de sliders avançados de calibração.

## Limitações importantes (não simuladas)

- **Mouse no Free Fire:** os aplicativos comuns Android, sem acesso especial ao sistema, não recebem necessariamente eventos relativos globais do mouse enquanto outro jogo está em primeiro plano. Portanto não há suspensão real de cursor, mouse-look global, nem injeção dos valores X/Y na câmera do Free Fire. A tela de calibração aplica X/Y aos movimentos recebidos **dentro do MOBILADOR**, e não dentro do jogo.
- **Teclas/gestos:** `dispatchGesture` é uma API de acessibilidade assíncrona e pode cancelar gestos físicos em andamento. Alguns jogos podem ignorar eventos simulados, remapear entradas ou proibir esse uso pelas suas regras. Teclas simultâneas foram consideradas no código, mas dependem dos limites de multitouch e das regras de continuação do Android e requerem teste real.
- **Editor/posicionamento:** mudanças de resolução são mitigadas por proporções; barras do sistema, entalhes, fullscreen, diferentes áreas úteis do jogo e rotações precisam ser calibrados novamente em alguns aparelhos.
- **Premium:** assinatura Play Store e validação pelo servidor **não funcionarão** até cadastrar app/produto, configurar credenciais privadas, hospedar o servidor em HTTPS e informar sua URL no Gradle. Preços aparecem apenas quando obtidos diretamente da loja. Nenhum botão libera o Premium sem verificação.
- **Ainda não implementados:** sincronização em nuvem, login em múltiplos dispositivos, curvas personalizadas com editor gráfico, estatísticas de latência medidas em dispositivo, presets específicos persistentes por arma e captura global do mouse. Não são apresentados como funcionais.
- **Google Play:** o uso de acessibilidade para mapeamento em jogos pode requerer revisão das políticas da plataforma e do jogo; publicar ou distribuir não é garantia de aprovação.

## Configurar a assinatura Premium com validação real

0. Você deve ser dono de uma conta Play Console e do pacote `com.mobilador.prox`, e cadastrar o produto recorrente **`mobilador_premium_monthly`**, com preço e oferta/base plan ativos. Configure testadores de licença na Play Console. Sem isso, o app informa que a assinatura não está configurada.
1. Habilite **Google Play Android Developer API** na conta Google Cloud vinculada ao Play Console e conceda à service account acesso às assinaturas do aplicativo.
2. No servidor (Node.js 20+), dentro de `server/`: execute `npm install`. Defina as variáveis do `.env.example` no serviço de hospedagem (o arquivo `.env.example` **não é carregado automaticamente**). O arquivo de credenciais JSON é privado e **nunca pode ir para APK, ZIP público ou repositório**.
3. Suba `npm start` e coloque uma camada HTTPS (proxy reverso) e regras de firewall na frente do serviço, roteando `/v1/verify`. O serviço só escuta `127.0.0.1` por padrão. Configure `DB_FILE` em disco persistente.
4. No Android Studio: configure `billingApiUrl=https://seu-dominio.example` em `~/.gradle/gradle.properties` ou passe `-PbillingApiUrl=https://seu-dominio.example` na execução do Gradle. Compile uma nova versão assinada de teste e distribua pela trilha de teste do Play Console.
5. Após comprar, o cliente recebe um purchase token do Play; o servidor valida com `purchases.subscriptionsv2.get`, confere o pacote, o ID do produto, situação e validade; impede que o mesmo token seja usado em duas instalações diferentes. Depois disso o app ativa o Premium. O cliente não decide sozinho.

**Nota de segurança/contas:** neste protótipo, compras são vinculadas à instalação usando um identificador aleatório local. A reinstalação ou troca de aparelho exige um fluxo futuro de conta autenticada e restauração. Para produção, acrescente login seguro, sistema de restauração de compra, notificações Play RTDN, revogação em tempo real, rate limiting compartilhado, monitoramento e políticas de cobrança. Sem essa infraestrutura, não comercialize assinaturas para clientes finais.

## Testes

- JVM no Android Studio: `./gradlew testDebugUnitTest` — máquina de estados de teclas, prevenção de repetições, escalas de resolução, X/Y independentes.
- Backend: `cd server && npm test` — rejeição de assinaturas pendentes/expiradas e produto incompatível.
- Teste manual obrigatório no aparelho: dobrar toque somente no editor, usar teclas seguradas e soltas, pressionar várias teclas simultâneas, mover mouse sobre marcadores, botão de parar, girar a tela, persistência de Room/DataStore, comportamento com outros serviços de acessibilidade e segundo jogo, sincronização de status com a Play Store.
- **Estado real dos testes neste ZIP:** fonte `InputLogic.kt` compilada com `kotlinc` isoladamente; testes de backend `node --test` passaram. Nenhum teste instrumentado, build Android/Gradle ou APK executado aqui porque o SDK Android e o Gradle não estão presentes neste ambiente.

## Referências oficiais

- Android AccessibilityService: https://developer.android.com/reference/android/accessibilityservice/AccessibilityService
- Configuração e key events: https://developer.android.com/reference/android/accessibilityservice/AccessibilityServiceInfo
- Google Play Billing: https://developer.android.com/google/play/billing/integrate
- Google Play SubscriptionV2: https://developer.android.com/google/play/billing/lifecycle/subscriptions
- Gradle release checksums: https://gradle.org/release-checksums/
