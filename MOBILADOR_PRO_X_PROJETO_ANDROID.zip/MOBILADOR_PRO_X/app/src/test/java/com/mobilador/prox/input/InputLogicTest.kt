package com.mobilador.prox.input

import org.junit.Assert.*
import org.junit.Test

class InputLogicTest {
    @Test fun ignoresDuplicateAndUnpairedEvents() {
        val m = KeyStateMachine()
        assertEquals(KeyStateMachine.Result.PRESS, m.onKey(32, true))
        assertEquals(KeyStateMachine.Result.IGNORED, m.onKey(32, true, 1))
        assertEquals(KeyStateMachine.Result.IGNORED, m.onKey(32, true))
        assertEquals(KeyStateMachine.Result.RELEASE, m.onKey(32, false))
        assertEquals(KeyStateMachine.Result.IGNORED, m.onKey(32, false))
    }
    @Test fun multipleKeysAndStopReleasesState() {
        val m = KeyStateMachine()
        m.onKey(29,true); m.onKey(51,true)
        assertEquals(setOf(29,51),m.clear())
        assertFalse(m.isHeld(29))
        assertEquals(KeyStateMachine.Result.IGNORED,m.onKey(51,false))
    }
    @Test fun normalizedCoordinatesSurviveResolutionChange() {
        val fraction = PositionMath.normalize(540f,1080f)
        assertEquals(0.5f, fraction, 0.00001f)
        assertEquals(720f, PositionMath.denormalize(fraction,1440), 0.00001f)
    }
    @Test fun doubleTapRequiresEditorAndTwoActualTaps() {
        val detector=EditorDoubleTap()
        assertFalse(detector.acceptTap(1000,100f,100f,false,40f))
        assertFalse(detector.acceptTap(1050,100f,100f,true,40f))
        assertTrue(detector.acceptTap(1200,105f,103f,true,40f))
        assertFalse(detector.acceptTap(2000,100f,100f,true,40f))
        assertFalse(detector.acceptTap(2010,300f,300f,true,40f))
    }
    @Test fun xyAreIndependentAndInvertYWorks() {
        val a = AimProcessor().move(10f,10f,50,150,0,0,0,false)
        assertEquals(5f,a.first,0.01f)
        assertEquals(15f,a.second,0.01f)
        val b = AimProcessor().move(10f,10f,100,100,0,0,0,true)
        assertTrue(b.second < 0f)
    }
}
