package com.mobilador.prox.billing

import android.app.Activity
import android.app.Application
import android.content.Context
import com.android.billingclient.api.*
import com.mobilador.prox.BuildConfig
import com.mobilador.prox.data.SettingsStore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Always fail closed: subscription is NEVER unlocked by locally changing a Boolean. */
data class PremiumStatus(val active: Boolean=false, val price: String="", val ready:Boolean=false,
                         val detail:String="Verificação do Premium indisponível")
class PlayPremium(private val app: Application, private val scope: CoroutineScope) : PurchasesUpdatedListener {
    companion object { const val PRODUCT_ID="mobilador_premium_monthly" }
    val status = MutableStateFlow(PremiumStatus())
    private var details: ProductDetails?=null
    private val configured = BuildConfig.BILLING_API_URL.startsWith("https://")
    private val client = BillingClient.newBuilder(app)
        .setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .enableAutoServiceReconnection()
        .build()
    init {
        if (configured) connect()
        else status.value=PremiumStatus(detail="Informe billingApiUrl e configure a assinatura no Google Play Console.")
    }
    private fun connect() {
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingServiceDisconnected() {
                status.value=PremiumStatus(detail="Google Play indisponível; tentando reconectar na próxima consulta.")
            }
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryProduct(); refresh()
                } else status.value=PremiumStatus(detail="Falha Play Billing: ${result.debugMessage}")
            }
        })
    }
    private fun queryProduct() {
        val query=QueryProductDetailsParams.newBuilder().setProductList(
            listOf(QueryProductDetailsParams.Product.newBuilder()
                .setProductId(PRODUCT_ID).setProductType(BillingClient.ProductType.SUBS).build())
        ).build()
        client.queryProductDetailsAsync(query) { result, found ->
            details=if(result.responseCode==BillingClient.BillingResponseCode.OK)
                found.productDetailsList.firstOrNull() else null
            val offer=details?.subscriptionOfferDetails?.firstOrNull()
            val price=offer?.pricingPhases?.pricingPhaseList?.lastOrNull()?.formattedPrice ?: ""
            status.value=status.value.copy(price=price,ready=offer!=null,
                detail=if (offer!=null) "Preço e oferta consultados no Google Play." else "Assinatura ainda não publicada para esta conta/testador.")
        }
    }
    fun purchase(activity: Activity) {
        if (!configured) return
        val d=details ?: run { status.value=status.value.copy(detail="Oferta não disponível.");return }
        val offer=d.subscriptionOfferDetails?.firstOrNull() ?: return
        val params=BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(
            BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d)
                .setOfferToken(offer.offerToken).build())).build()
        val result=client.launchBillingFlow(activity,params)
        if (result.responseCode!=BillingClient.BillingResponseCode.OK)
            status.value=status.value.copy(detail="Não foi possível abrir o pagamento: ${result.debugMessage}")
    }
    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            verifyPurchases(purchases)
        } else if(result.responseCode != BillingClient.BillingResponseCode.USER_CANCELED) {
            status.value=status.value.copy(active=false,detail="Compra não confirmada: ${result.debugMessage}")
        }
    }
    fun refresh() {
        if(!configured || !client.isReady) return
        client.queryPurchasesAsync(QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.SUBS).build()) { result,purchases ->
            if(result.responseCode==BillingClient.BillingResponseCode.OK) verifyPurchases(purchases)
            else status.value=status.value.copy(active=false,detail="Falha ao restaurar assinatura no Google Play.")
        }
    }
    private fun verifyPurchases(purchases: List<Purchase>) {
        val paid=purchases.firstOrNull { it.purchaseState==Purchase.PurchaseState.PURCHASED &&
            it.products.contains(PRODUCT_ID) }
        if (paid==null) {
            status.value=status.value.copy(active=false,detail="Nenhuma assinatura ativa encontrada.")
            return
        }
        scope.launch {
            val allowed=withContext(Dispatchers.IO) { verifyAtServer(paid.purchaseToken) }
            status.value=status.value.copy(active=allowed,
                detail=if(allowed) "Assinatura verificada com o Google Play pelo servidor." else
                    "Assinatura ainda não validada pelo servidor; Premium bloqueado.")
            if (allowed && !paid.isAcknowledged) {
                client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(paid.purchaseToken).build()) { response ->
                    if(response.responseCode != BillingClient.BillingResponseCode.OK)
                        status.value=status.value.copy(detail="Premium validado; confirmação da compra será repetida.")
                }
            }
        }
    }
    private suspend fun verifyAtServer(token: String): Boolean = try {
        val id=SettingsStore(app).ensureInstallId()
        val endpoint=URL(BuildConfig.BILLING_API_URL.trimEnd('/')+"/v1/verify")
        val conn=endpoint.openConnection() as HttpURLConnection
        try {
            conn.requestMethod="POST"
            conn.connectTimeout=8000;conn.readTimeout=8000
            conn.setRequestProperty("Content-Type","application/json")
            conn.doOutput=true
            val data=JSONObject().put("purchaseToken",token).put("installId",id)
            conn.outputStream.use { it.write(data.toString().toByteArray(Charsets.UTF_8)) }
            conn.responseCode==200 && JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                .optBoolean("active",false)
        } finally {conn.disconnect()}
    } catch (_:Exception) {false}
    fun close() { client.endConnection() }
}
