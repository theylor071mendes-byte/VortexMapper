package com.mobilador.prox

import android.content.Intent
import android.hardware.input.InputManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.InputDevice
import android.view.KeyEvent as AndroidKeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.lifecycleScope
import com.mobilador.prox.data.*
import com.mobilador.prox.input.AimProcessor
import com.mobilador.prox.input.PositionMath
import com.mobilador.prox.service.MappingService
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val bg=Color(0xFF080C19)
private val surface=Color(0xFF171A30)
private val vivid=Color(0xFF926CFF)
private val cyan=Color(0xFF52DFFE)
private val muted=Color(0xFFADB2CC)
private val premiumGrad=Brush.linearGradient(listOf(Color(0xFF8A50ED),Color(0xFF1468BB)))
private val scheme=darkColorScheme(primary=vivid,secondary=cyan,background=bg,surface=surface,
    onPrimary=Color.White,onBackground=Color.White,onSurface=Color.White)

class MainActivity: ComponentActivity() {
    private val devicesListener = object: InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId:Int) { model?.refreshDevices() }
        override fun onInputDeviceRemoved(deviceId:Int) { model?.refreshDevices() }
        override fun onInputDeviceChanged(deviceId:Int) { model?.refreshDevices() }
    }
    private var model: MainViewModel?=null
    private val inputs by lazy { getSystemService(INPUT_SERVICE) as InputManager }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=android.graphics.Color.rgb(8,12,25)
        window.navigationBarColor=android.graphics.Color.rgb(8,12,25)
        setContent { MaterialTheme(colorScheme=scheme) {
            val vm:MainViewModel=viewModel()
            LaunchedEffect(vm) {model=vm}
            MobiladorUi(vm, onStart={
                val service=MappingService.instance
                if(service==null) startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
                else service.startMapping()
            },onStop={ MappingService.instance?.stopMapping() },
                onOpenGame={ pkg ->
                    val intent=packageManager.getLaunchIntentForPackage(pkg)
                    if(intent!=null) startActivity(intent)
                    else vm.notice.value="Jogo não encontrado. Confirme o nome do pacote do perfil."
                },onBuy={vm.premium.purchase(this)})
        } }
    }
    override fun onResume() {super.onResume();model?.premium?.refresh();model?.refreshDevices();inputs.registerInputDeviceListener(devicesListener,null)}
    override fun onPause() { inputs.unregisterInputDeviceListener(devicesListener);super.onPause() }
}

private enum class Page(val label:String) { HOME("Início"), KEYS("Controles"), AIM("Mira"), PROFILES("Perfis"), PREMIUM("Premium"), SETTINGS("Ajustes") }
@Composable
private fun MobiladorUi(vm:MainViewModel,onStart:()->Unit,onStop:()->Unit,onOpenGame:(String)->Unit,onBuy:()->Unit) {
    val config by vm.settings.collectAsState()
    val controls by vm.controls.collectAsState()
    val profiles by vm.profiles.collectAsState()
    val premium by vm.premium.status.collectAsState()
    val running by MappingService.running.collectAsState()
    val peripherals by vm.devices.collectAsState()
    val notice by vm.notice.collectAsState()
    val active=profiles.firstOrNull { it.id==config.activeProfile }
    var page by remember { mutableStateOf(Page.HOME) }
    var drawer by remember { mutableStateOf(false) }
    var help by remember { mutableStateOf(false) }
    val scope=rememberCoroutineScope()
    val context=LocalContext.current
    var exportBuffer by remember {mutableStateOf("")}
    val exportLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri:Uri? ->
        if(uri!=null && exportBuffer.isNotEmpty() && premium.active) {
            try { context.contentResolver.openOutputStream(uri)?.use { it.write(exportBuffer.toByteArray()) }
                vm.notice.value="Perfil exportado para o arquivo selecionado."
            } catch(e:Exception){ vm.notice.value="Falha ao exportar: ${e.message}" }
        }
    }
    val importLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri:Uri? ->
        if(uri!=null && premium.active) scope.launch {
            try {
                val str=withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                }
                if(str.length>300_000) vm.notice.value="Arquivo muito grande"
                else vm.importJson(str)
            }catch(e:Exception){vm.notice.value="Falha ao importar: ${e.message}"}
        }
    }
    Column(Modifier.fillMaxSize().background(bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick={drawer=!drawer}) {Icon(Icons.Default.Menu,"Menu",tint=cyan)}
            Column(Modifier.weight(1f)) {
                Text("MOBILADOR",fontWeight=FontWeight.Black,fontSize=19.sp,letterSpacing=1.8.sp)
                Text("PRO X  •  CONTROLE AVANÇADO",fontSize=9.sp,color=muted,letterSpacing=2.sp)
            }
            Surface(shape=RoundedCornerShape(40.dp),color=if(premium.active) Color(0xFF2E234E) else surface) {
                Text(if(premium.active) "✦ PREMIUM" else "GRÁTIS",modifier=Modifier.padding(10.dp),fontSize=11.sp,color=cyan)
            }
        }
        AnimatedVisibility(visible=drawer) {
            Card(Modifier.fillMaxWidth().padding(horizontal=16.dp),colors=CardDefaults.cardColors(containerColor=surface)) {
                Page.entries.forEach { entry ->
                    TextButton(onClick={page=entry;drawer=false},modifier=Modifier.fillMaxWidth()) {
                        Text(entry.label,Modifier.fillMaxWidth(),color=if(entry==page) cyan else Color.White)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=15.dp,vertical=5.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            Page.entries.forEach { entry ->
                val chosen=entry==page
                Surface(shape=RoundedCornerShape(14.dp),color=if(chosen) vivid else surface,
                    modifier=Modifier.clickable{page=entry}) {
                    Text(entry.label,Modifier.padding(horizontal=13.dp,vertical=9.dp),fontSize=12.sp,
                        color=if(chosen) Color.White else muted)
                }
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal=18.dp,vertical=12.dp),
            verticalArrangement=Arrangement.spacedBy(15.dp)) {
            when(page) {
                Page.HOME -> HomePage(running,active,peripherals,controls.size,onStart,onStop,{
                    active?.gamePackage?.let(onOpenGame)
                },onRefresh={vm.refreshDevices()},onHelp={help=true})
                Page.KEYS -> KeysPage(controls,vm)
                Page.AIM -> AimPage(config,vm,premium.active)
                Page.PROFILES -> ProfilesPage(profiles,config.activeProfile,vm)
                Page.PREMIUM -> PremiumPage(premium,onBuy,onExport={scope.launch {
                    try { exportBuffer=vm.exportJson();exportLauncher.launch("mobilador_perfil.json") }
                    catch(e:Exception){vm.notice.value=e.message ?: "Premium não ativo"}
                }},onImport={importLauncher.launch(arrayOf("application/json","text/plain"))})
                Page.SETTINGS -> SettingsPage(config,vm)
            }
            if (notice.isNotBlank()) Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF242040))) {
                Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text(notice,Modifier.weight(1f),fontSize=12.sp,color=cyan)
                    TextButton(onClick={vm.notice.value=""}) {Text("OK")}
                }
            }
            Spacer(Modifier.height(18.dp))
        }
    }
    if(help) AlertDialog(onDismissRequest={help=false},title={Text("Permissão necessária")},
        text={Text("O serviço de acessibilidade recebe teclas físicas e envia gestos de toque nas posições que você configurar. Ative manualmente em Configurações > Acessibilidade. O painel só aparece quando você iniciar o mapeamento. Alguns jogos e versões do Android podem bloquear gestos. Não captura movimento relativo global do mouse.")},
        confirmButton={TextButton(onClick={help=false}){Text("Entendi")}})
}
@Composable private fun Frame(title:String,subtitle:String?=null,content:@Composable ColumnScope.()->Unit) {
    Card(colors=CardDefaults.cardColors(containerColor=surface),shape=RoundedCornerShape(21.dp),modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Text(title,fontWeight=FontWeight.Bold,fontSize=17.sp)
            if(subtitle!=null) Text(subtitle,fontSize=12.sp,color=muted,lineHeight=18.sp)
            content()
        }
    }
}
@Composable private fun HeroButton(label:String,onClick:()->Unit,enabled:Boolean=true) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
        .background(if(enabled) premiumGrad else Brush.linearGradient(listOf(Color.DarkGray,Color.DarkGray)))
        .clickable(enabled=enabled,onClick=onClick).padding(18.dp),contentAlignment=Alignment.Center) {
        Text(label,fontSize=15.sp,fontWeight=FontWeight.Black,color=Color.White,letterSpacing=1.sp)
    }
}
@Composable private fun HomePage(running:Boolean,active:Profile?,devices:String,count:Int,onStart:()->Unit,onStop:()->Unit,
    onOpen:()->Unit,onRefresh:()->Unit,onHelp:()->Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(
        Brush.linearGradient(listOf(Color(0xFF352160),Color(0xFF142C4C))))
        .padding(23.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("MOBILADOR PRO X",fontSize=24.sp,fontWeight=FontWeight.Black)
        Text("Mapeamento por teclas físicas e gestos Android",color=Color(0xFFD6CFFE))
        Text(if(running) "● SERVIÇO EM EXECUÇÃO" else "○ SERVIÇO PARADO",fontSize=11.sp,color=if(running) cyan else muted)
        HeroButton(if(running) "DESATIVAR MAPEADOR" else "INICIAR MAPEADOR",if(running) onStop else onStart)
        if(running) OutlinedButton(onClick=onOpen,modifier=Modifier.fillMaxWidth()) {Text("ABRIR JOGO")}
    }
    Frame("PERFIL ATIVO") {
        Text(active?.name ?: "Carregando perfil...",fontSize=17.sp,color=cyan)
        Text(active?.gamePackage ?: "",color=muted,fontSize=12.sp)
        Text("$count controles configurados",color=muted)
    }
    Frame("PERIFÉRICOS", "Detecta dispositivos reconhecidos pelo Android, via Bluetooth ou USB OTG.") {
        Text(devices,color=cyan,fontSize=13.sp)
        OutlinedButton(onClick=onRefresh){Text("Atualizar conexão")}
    }
    Frame("COMO FUNCIONA") {
        Text("1. Escolha o perfil do jogo e configure teclas em Controles.\n2. Ative o serviço de acessibilidade.\n3. Inicie o mapeador e abra o jogo.\n4. No painel flutuante, toque em EDITAR para posicionar os botões sobre a imagem real do jogo.",lineHeight=22.sp,color=muted,fontSize=13.sp)
        TextButton(onClick=onHelp) {Text("Permissões e limitações")}
    }
}
@Composable private fun KeysPage(controls:List<Control>,vm:MainViewModel) {
    var desired by remember {mutableStateOf<Offset?>(null)}
    var selected by remember {mutableStateOf<Control?>(null)}
    Text("EDITOR DE CONTROLES",fontSize=22.sp,fontWeight=FontWeight.Bold)
    Text("Dê dois toques na área de edição, depois pressione uma tecla física. Arraste os marcadores para mover.",fontSize=12.sp,color=muted)
    BoxWithConstraints(Modifier.fillMaxWidth().height(380.dp).clip(RoundedCornerShape(18.dp))
        .background(Brush.linearGradient(listOf(Color(0xFF1C2750),Color(0xFF21183D))))
        .border(1.dp,vivid,RoundedCornerShape(18.dp))) {
        val w=constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val h=constraints.maxHeight.toFloat().coerceAtLeast(1f)
        Box(Modifier.fillMaxSize().pointerInput(Unit) {
            detectTapGestures(onDoubleTap={ point ->
                desired=Offset(PositionMath.normalize(point.x,size.width.toFloat()),
                    PositionMath.normalize(point.y,size.height.toFloat()))
            })
        }) {
            Text("ÁREA DE CALIBRAÇÃO",Modifier.align(Alignment.Center),fontSize=13.sp,
                color=Color.White.copy(alpha=.25f),letterSpacing=2.sp)
        }
        controls.forEach { c ->
            var pos by remember(c.id,c.x,c.y) {mutableStateOf(Offset(c.x,c.y))}
            Box(Modifier.offset { IntOffset((pos.x*w).roundToInt()-22.dp.roundToPx(),
                (pos.y*h).roundToInt()-22.dp.roundToPx()) }
                .size(44.dp).clip(CircleShape).background(if(selected?.id==c.id) cyan else vivid)
                .border(2.dp,Color.White,CircleShape)
                .pointerInput(c.id,w,h) {
                    detectDragGestures(onDragEnd={vm.update(c.copy(x=pos.x,y=pos.y))}) {change,delta ->
                        change.consume();pos=Offset((pos.x+delta.x/w).coerceIn(0f,1f),
                            (pos.y+delta.y/h).coerceIn(0f,1f))
                    }
                }.clickable {selected=c},contentAlignment=Alignment.Center) {
                Text(c.keyLabel.take(4),fontSize=10.sp,fontWeight=FontWeight.Black,color=Color.White)
            }
        }
    }
    Frame("TECLAS CONFIGURADAS", "Controles normalizados se adaptam às resoluções; calibração final deve ser feita sobre o jogo.") {
        if(controls.isEmpty()) Text("Nenhuma tecla adicionada.",color=muted)
        controls.forEach {c ->
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(c.keyLabel,fontWeight=FontWeight.Bold,fontSize=13.sp)
                    Text("${(c.x*100).roundToInt()}% × ${(c.y*100).roundToInt()}%",fontSize=11.sp,color=muted)
                }
                TextButton(onClick={vm.update(c.copy(isHold=!c.isHold))}) {Text(if(c.isHold) "Segurar" else "Toque",fontSize=12.sp)}
                IconButton(onClick={vm.delete(c)}){Icon(Icons.Default.Delete,"Excluir",tint=Color(0xFFFF779C))}
            }
        }
    }
    if(desired!=null) BindDialog(onCancel={desired=null},onKey={key,label ->
        desired?.let { vm.addControl(it.x,it.y,key,label) };desired=null
    })
}
@Composable private fun BindDialog(onCancel:()->Unit,onKey:(Int,String)->Unit) {
    val focus=remember {FocusRequester()}
    AlertDialog(onDismissRequest=onCancel,title={Text("ADICIONAR CONTROLE")},
        text={ Box(Modifier.fillMaxWidth().focusRequester(focus).onPreviewKeyEvent { e ->
            if(e.type==KeyEventType.KeyDown && e.nativeKeyEvent.repeatCount==0) {
                val k=e.nativeKeyEvent.keyCode
                if(k!=AndroidKeyEvent.KEYCODE_BACK) {
                    onKey(k,AndroidKeyEvent.keyCodeToString(k).removePrefix("KEYCODE_"));true
                } else false
            } else false
        }.focusable().padding(16.dp)) {
            Text("Pressione a tecla no teclado físico...",color=cyan)
        } },confirmButton={TextButton(onClick=onCancel){Text("Cancelar")}})
    LaunchedEffect(Unit) {focus.requestFocus()}
}
@Composable private fun Range(title:String,value:Int,min:Int,max:Int,onChange:(Int)->Unit,postfix:String="%") {
    Column {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(title,fontSize=13.sp,color=muted)
            Text("$value$postfix",fontWeight=FontWeight.Bold,color=cyan,fontSize=13.sp)
        }
        Slider(value=value.toFloat(),onValueChange={onChange(it.roundToInt())},valueRange=min.toFloat()..max.toFloat())
    }
}
@Composable private fun AimPage(config:Settings,vm:MainViewModel,pro:Boolean) {
    Text("PRECISION AIM CONTROL",fontWeight=FontWeight.Black,fontSize=21.sp)
    Text("Ajuste manual dos eixos para calibrar movimentos. Não aplica mira automática nem altera o Free Fire.",fontSize=12.sp,color=muted)
    Frame("SENSIBILIDADE") {
        Range("Horizontal X",config.sensitivityX,1,200,vm::setX)
        Range("Vertical Y",config.sensitivityY,1,200,vm::setY)
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text("Inverter eixo vertical",Modifier.weight(1f),fontSize=13.sp)
            Switch(checked=config.invertY,onCheckedChange=vm::setInvert)
        }
    }
    Frame("AJUSTES AVANÇADOS",if(pro) "Premium validado — ajustes ativos na calibração" else "Disponíveis após a validação Premium") {
        if(pro) {
            Range("Suavização",config.smoothing,0,100,vm::setSmooth)
            Range("Aceleração",config.acceleration,0,100,vm::setAcceleration)
            Range("Zona morta",config.deadzone,0,40,vm::setDeadzone,"")
        } else Text("✦ Suavização, aceleração e zona morta personalizáveis",color=muted,fontSize=12.sp)
    }
    Frame("PRESETS DE PARTIDA", "Valores iniciais ilustrativos, ajustáveis. Aplicados apenas ao processamento na área de calibração.") {
        val presets=listOf(Triple("SMG / UMP",110,105),Triple("AR / XM8",90,85),
            Triple("Shotgun",120,110),Triple("Pistola / Desert",95,90))
        presets.forEach { (label,x,y) ->
            OutlinedButton(onClick={vm.setX(x);vm.setY(y)},modifier=Modifier.fillMaxWidth()) {Text("$label  •  X $x / Y $y")}
        }
    }
    Frame("LABORATÓRIO DE MIRA", "Arraste ou mova o mouse pressionando o botão esquerdo nesta área para ver o processamento real X/Y.") {
        AimTest(config)
    }
}
@OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)
@Composable private fun AimTest(settings:Settings) {
    val aim=remember {AimProcessor()}
    var dot by remember {mutableStateOf(Offset(0.5f,0.5f))}
    var previous by remember {mutableStateOf<Offset?>(null)}
    var movement by remember {mutableStateOf(Offset.Zero)}
    BoxWithConstraints(Modifier.fillMaxWidth().height(240.dp).clip(RoundedCornerShape(16.dp))
        .background(Color(0xFF0D142B)).border(1.dp,cyan.copy(alpha=.4f),RoundedCornerShape(16.dp))
        .pointerInteropFilter {ev ->
            when(ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {previous=Offset(ev.x,ev.y);aim.reset();true}
                MotionEvent.ACTION_MOVE -> {
                    val p=previous
                    if(p!=null) {
                        val (mx,my)=aim.move((ev.x-p.x)*settings.cursorSpeed/100f,(ev.y-p.y)*settings.cursorSpeed/100f,settings.sensitivityX,
                            settings.sensitivityY,settings.acceleration,settings.smoothing,
                            settings.deadzone,settings.invertY)
                        movement=Offset(mx,my)
                        dot=Offset((dot.x+mx/500f).coerceIn(.03f,.97f),(dot.y+my/300f).coerceIn(.04f,.96f))
                    }
                    previous=Offset(ev.x,ev.y);true
                }
                MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL -> {previous=null;true}
                else -> false
            }
        }) {
        Canvas(Modifier.fillMaxSize()) {
            val p=Offset(size.width*dot.x,size.height*dot.y)
            drawLine(cyan.copy(alpha=.3f),Offset(p.x,0f),Offset(p.x,size.height),1.dp.toPx())
            drawLine(cyan.copy(alpha=.3f),Offset(0f,p.y),Offset(size.width,p.y),1.dp.toPx())
            drawCircle(vivid,radius=17.dp.toPx(),center=p)
            drawCircle(Color.White,radius=4.dp.toPx(),center=p)
        }
        Text("ΔX ${"%.1f".format(movement.x)}   ΔY ${"%.1f".format(movement.y)}",
            Modifier.align(Alignment.BottomStart).padding(10.dp),fontSize=11.sp,color=muted)
    }
    TextButton(onClick={dot=Offset(.5f,.5f);aim.reset();movement=Offset.Zero}) {Text("Reiniciar calibração")}
}
@Composable private fun ProfilesPage(profiles:List<Profile>,id:Long,vm:MainViewModel) {
    var name by remember {mutableStateOf("")}
    var target by remember {mutableStateOf("com.dts.freefireth")}
    Text("GERENCIADOR DE PERFIS",fontWeight=FontWeight.Bold,fontSize=21.sp)
    Frame("MEUS JOGOS") {
        profiles.forEach { p ->
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                RadioButton(selected=p.id==id,onClick={vm.active(p.id)})
                Column(Modifier.weight(1f).clickable {vm.active(p.id)}) {
                    Text(p.name,fontSize=14.sp,fontWeight=FontWeight.SemiBold)
                    Text(p.gamePackage,fontSize=10.sp,color=muted)
                }
                IconButton(onClick={vm.deleteProfile(p.id)}) {Icon(Icons.Default.Delete,"Excluir",tint=muted)}
            }
        }
    }
    Frame("NOVO PERFIL", "Grátis: até 2 perfis. Premium validado: ilimitados.") {
        OutlinedTextField(value=name,onValueChange={name=it},label={Text("Nome")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(value=target,onValueChange={target=it},label={Text("Pacote Android do jogo")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            TextButton(onClick={target="com.dts.freefireth"}){Text("Free Fire",fontSize=11.sp)}
            TextButton(onClick={target="com.dts.freefiremax"}){Text("Free Fire MAX",fontSize=11.sp)}
        }
        HeroButton("CRIAR PERFIL",{vm.createProfile(name,target);name=""})
    }
}
@Composable private fun PremiumPage(status:com.mobilador.prox.billing.PremiumStatus,onBuy:()->Unit,
    onExport:()->Unit,onImport:()->Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(premiumGrad).padding(23.dp),
        verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("✦ MOBILADOR PREMIUM",fontWeight=FontWeight.Black,fontSize=23.sp)
        Text(if(status.active) "ASSINATURA VERIFICADA" else "ACESSO A RECURSOS AVANÇADOS",fontWeight=FontWeight.SemiBold)
        Text(status.price.ifBlank {"Preço definido e exibido pelo Google Play após configuração"},fontSize=15.sp)
        HeroButton(if(status.active) "PREMIUM ATIVO" else "ASSINAR PELO GOOGLE PLAY",onBuy,enabled=status.ready && !status.active)
    }
    Frame("COMPARAÇÃO DOS PLANOS") {
        Text("GRATUITO  •  2 perfis, mapeamento de teclas, editor, X/Y e calibração",fontSize=13.sp)
        HorizontalDivider(color=muted.copy(alpha=.3f))
        Text("PREMIUM  •  Perfis ilimitados, importação/exportação JSON, controles extras de calibração",fontSize=13.sp,color=cyan)
    }
    Frame("IMPORTAR / EXPORTAR",if(status.active) "Recursos ativados com confirmação do servidor." else "Desbloqueados apenas após compra confirmada.") {
        OutlinedButton(onClick=onExport,enabled=status.active,modifier=Modifier.fillMaxWidth()) {Text("EXPORTAR PERFIL (JSON)")}
        OutlinedButton(onClick=onImport,enabled=status.active,modifier=Modifier.fillMaxWidth()) {Text("IMPORTAR PERFIL (JSON)")}
    }
    Frame("STATUS DO PAGAMENTO") {Text(status.detail,color=muted,fontSize=12.sp)}
    Text("Backup na nuvem, sincronização entre contas e estatísticas de latência não estão implementados nesta versão.",fontSize=12.sp,color=muted)
}
@Composable private fun SettingsPage(config:Settings,vm:MainViewModel) {
    Text("CONFIGURAÇÕES",fontWeight=FontWeight.Bold,fontSize=21.sp)
    Frame("CONTROLE DO MOUSE", "O Android não permite travar/mover livremente o cursor de terceiros com este serviço. A tecla escolhida alterna apenas o estado do painel flutuante.") {
        Range("Velocidade no laboratório",config.cursorSpeed,10,200,vm::setSpeed)
        Text("Tecla de alternância",fontSize=13.sp,color=muted)
        listOf(AndroidKeyEvent.KEYCODE_CTRL_LEFT to "Ctrl esquerda",
            AndroidKeyEvent.KEYCODE_ALT_LEFT to "Alt esquerda",
            AndroidKeyEvent.KEYCODE_F8 to "F8").forEach { (code,text) ->
            Row(verticalAlignment=Alignment.CenterVertically) {
                RadioButton(selected=config.suspendKey==code,onClick={vm.setSuspendKey(code)})
                Text(text)
            }
        }
    }
    Frame("PRIVACIDADE E PERMISSÕES") {
        Text("O serviço filtra teclas enquanto o mapeamento está ativo e só dispara gestos para o pacote do jogo selecionado. Não lê senhas, tela ou arquivos dos jogos. Interrompa o serviço pelo painel ou pelo Android a qualquer momento.",fontSize=12.sp,lineHeight=18.sp,color=muted)
    }
}
