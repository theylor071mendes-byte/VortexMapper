package com.mobilador.prox.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.*
import android.widget.*
import android.view.accessibility.AccessibilityEvent
import com.mobilador.prox.data.*
import com.mobilador.prox.input.KeyStateMachine
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class MappingService : AccessibilityService() {
    companion object {
        @Volatile var instance: MappingService? = null
            private set
        val running = MutableStateFlow(false)
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var window: WindowManager
    private lateinit var dao: ProfileDao
    private lateinit var prefs: SettingsStore
    private lateinit var engine: TouchGestureEngine
    private var config = com.mobilador.prox.data.Settings()
    private var bindings = emptyList<Control>()
    private var activeProfile: Profile? = null
    private var foregroundPackage: String? = null
    private var mappingEnabled = false
    private var editing = false
    private var cameraMode = false // visible status only; Android doesn't expose global relative mouse capture
    private val keyMachine = KeyStateMachine()
    private val consumed = mutableSetOf<Int>()
    private var floating: View? = null
    private var editor: EditorOverlayView? = null
    private var floatingParams: WindowManager.LayoutParams? = null
    private var panelExpanded = true
    private var capture: Pair<Float,Float>? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        window = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        dao = MapperDb.get(this).dao()
        prefs = SettingsStore(this)
        engine = TouchGestureEngine(this)
        scope.launch {
            prefs.flow.collectLatest { setting ->
                if (config.activeProfile != setting.activeProfile) {
                    releaseKeys()
                }
                config = setting
            }
        }
        scope.launch {
            prefs.flow.map { it.activeProfile }.distinctUntilChanged().flatMapLatest { id ->
                if (id == 0L) flowOf(emptyList()) else dao.observeControls(id)
            }.collect { bindings = it; editor?.setControls(it) }
        }
        scope.launch {
            combine(dao.observeProfiles(), prefs.flow) { profiles, settings ->
                profiles.firstOrNull { it.id == settings.activeProfile }
            }.collect { profile ->
                if (activeProfile?.id != profile?.id) releaseKeys()
                activeProfile = profile
                updateAllowed()
                editor?.setControls(bindings)
            }
        }
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString()
            if (pkg != null && pkg != "com.android.systemui") {
                if (pkg != foregroundPackage) {
                    foregroundPackage = pkg
                    updateAllowed()
                }
            }
        }
    }
    override fun onInterrupt() { releaseKeys() }
    override fun onDestroy() {
        if (::window.isInitialized && ::engine.isInitialized) stopMapping()
        scope.cancel()
        instance = null
        super.onDestroy()
    }
    private fun updateAllowed() {
        val allowed = mappingEnabled && !editing && activeProfile?.gamePackage == foregroundPackage
        engine.allowed = allowed
        if (!allowed) releaseKeys()
    }
    private fun refreshScreenSize() {
        if (!::window.isInitialized || !::engine.isInitialized) return
        @Suppress("DEPRECATION")
        val display = window.defaultDisplay
        val p = Point()
        @Suppress("DEPRECATION")
        display.getRealSize(p)
        engine.screenDimensions(p.x, p.y)
    }
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        refreshScreenSize()
    }
    private fun releaseKeys() {
        keyMachine.clear()
        consumed.clear()
        if (::engine.isInitialized) engine.stop()
    }
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!mappingEnabled) return false
        val key = event.keyCode
        val down = event.action == KeyEvent.ACTION_DOWN
        if (!down && event.action != KeyEvent.ACTION_UP) return false
        if (editing && capture != null && down && event.repeatCount == 0 && key != KeyEvent.KEYCODE_BACK) {
            val point = capture!!; capture = null
            val profileId = config.activeProfile
            if (profileId > 0) scope.launch {
                dao.addControl(Control(profileId=profileId,keyCode=key,
                    keyLabel=KeyEvent.keyCodeToString(key).removePrefix("KEYCODE_"), x=point.first,y=point.second))
                editor?.setStatus("Controle adicionado. Arraste para mover.")
            }
            consumed.add(key)
            editor?.setStatus("Salvando tecla...")
            return true
        }
        if (key in consumed && !down) { consumed.remove(key); return true }
        if (editing) return false
        if (!editing && activeProfile?.gamePackage != foregroundPackage) return false
        if (key == config.suspendKey) {
            if (down && event.repeatCount == 0) {
                cameraMode = !cameraMode
                updatePanel()
            }
            return true
        }
        val control = bindings.firstOrNull { it.keyCode == key } ?: return false
        if (down) refreshScreenSize()
        val result = keyMachine.onKey(key, down, event.repeatCount)
        when (result) {
            KeyStateMachine.Result.PRESS -> engine.down(control)
            KeyStateMachine.Result.RELEASE -> engine.up(key)
            KeyStateMachine.Result.IGNORED -> Unit
        }
        return true
    }
    fun startMapping() {
        if (!::engine.isInitialized) return
        mappingEnabled = true
        refreshScreenSize()
        running.value = true
        showPanel()
        updateAllowed()
        Toast.makeText(this,"Mapeamento habilitado. Abra o jogo associado ao perfil.",Toast.LENGTH_LONG).show()
    }
    fun stopMapping() {
        editing = false
        mappingEnabled = false
        cameraMode = false
        running.value = false
        if (::engine.isInitialized) engine.allowed = false
        releaseKeys()
        removeEditor()
        removePanel()
    }
    private fun px(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()
    private fun background(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(27,20,57),Color.rgb(10,19,37))
    ).apply { cornerRadius=px(16).toFloat(); setStroke(px(1),Color.rgb(122,71,229)) }
    private fun label(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        setText(text); setTextColor(Color.WHITE); textSize=12f
        setPadding(px(10),px(12),px(10),px(12)); setOnClickListener { onClick() }
    }
    private fun showPanel() {
        removePanel()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background=background()
            elevation = px(9).toFloat()
        }
        val bar = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val drag = label("✦ MOBILADOR",{}).apply { setTypeface(null, Typeface.BOLD) }
        drag.setOnTouchListener(object: View.OnTouchListener {
            var oldX=0f; var oldY=0f; var originX=0;var originY=0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val p = floatingParams ?: return false
                when(e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { oldX=e.rawX;oldY=e.rawY;originX=p.x;originY=p.y; return true }
                    MotionEvent.ACTION_MOVE -> {
                        p.x=originX+(e.rawX-oldX).toInt();p.y=originY+(e.rawY-oldY).toInt()
                        try { window.updateViewLayout(root,p) } catch (_: Exception) {}
                        return true
                    }
                }
                return true
            }
        })
        bar.addView(drag)
        bar.addView(label("▣") { panelExpanded = !panelExpanded; updatePanel() })
        root.addView(bar)
        floating = root
        floatingParams=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START;x=px(14);y=px(90) }
        try { window.addView(root,floatingParams) } catch (_: Exception) { floating=null }
        updatePanel()
    }
    private fun updatePanel() {
        val root = floating as? LinearLayout ?: return
        while(root.childCount>1) root.removeViewAt(1)
        if (!panelExpanded) return
        root.addView(label(if(cameraMode) "MODO CÂMERA*" else "CURSOR LIVRE*") {
            cameraMode=!cameraMode;updatePanel()
        })
        root.addView(label("EDITAR POSIÇÕES") { enterEditor() })
        root.addView(label("PARAR MAPEADOR") { stopMapping() })
        root.addView(label("* Alterna estado do painel; não bloqueia cursor no jogo.") {})
    }
    private fun enterEditor() {
        if (editing) return
        editing=true; releaseKeys();updateAllowed()
        removePanel()
        val overlay = EditorOverlayView(this,
            onClose={ exitEditor() },
            onCreate={ x,y -> capture=x to y; editor?.setStatus("Pressione uma tecla física para posicionar o controle") },
            onMove={ c -> scope.launch { dao.updateControl(c) } },
            onDelete={ c -> scope.launch { dao.deleteControl(c.id) } },
            onResize={ c -> scope.launch { dao.updateControl(c) } }
        )
        editor=overlay
        overlay.setControls(bindings)
        val params=WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        try { window.addView(overlay,params) } catch (_: Exception) { editor=null; exitEditor() }
    }
    private fun exitEditor() {
        capture=null;editing=false;removeEditor();showPanel();updateAllowed()
    }
    private fun removeEditor() { editor?.let { try { window.removeView(it) } catch (_:Exception) {} }; editor=null }
    private fun removePanel() { floating?.let { try { window.removeView(it) } catch (_:Exception) {} }; floating=null }
}
