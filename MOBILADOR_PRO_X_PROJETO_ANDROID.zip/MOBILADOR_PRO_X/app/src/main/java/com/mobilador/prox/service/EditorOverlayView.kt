package com.mobilador.prox.service

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import com.mobilador.prox.data.Control
import com.mobilador.prox.input.PositionMath
import com.mobilador.prox.input.EditorDoubleTap
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/** Full-screen editing surface is only present during explicit edit mode. */
class EditorOverlayView(context: Context,
    private val onClose: () -> Unit,
    private val onCreate: (Float,Float) -> Unit,
    private val onMove: (Control) -> Unit,
    private val onDelete: (Control) -> Unit,
    private val onResize: (Control) -> Unit
): View(context) {
    private var controls: List<Control> = emptyList()
    private var status = "Dois toques na tela adicionam um controle"
    private var selected: Control? = null
    private var dragging = false
    private val doubleTap = EditorDoubleTap()
    private val brush = Paint(Paint.ANTI_ALIAS_FLAG)
    private val density = resources.displayMetrics.density
    private fun dp(n: Float)=n*density
    fun setControls(value: List<Control>) {
        controls=value
        selected=selected?.let { s -> value.find { it.id == s.id } }
        invalidate()
    }
    fun setStatus(message: String) { status=message;invalidate() }
    private fun text(canvas: Canvas, s: String,x: Float,y: Float,size: Float=14f,color:Int=Color.WHITE) {
        brush.color=color;brush.textSize=dp(size);brush.style=Paint.Style.FILL
        canvas.drawText(s,x,y,brush)
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.argb(80,4,6,18))
        brush.color=Color.argb(244,22,17,53)
        canvas.drawRoundRect(RectF(dp(8f),dp(10f),width-dp(8f),dp(93f)),dp(16f),dp(16f),brush)
        text(canvas,"MOBILADOR • EDITOR",dp(20f),dp(37f),17f)
        text(canvas,"FECHAR ×",width-dp(95f),dp(37f),13f,0xFF57DEFF.toInt())
        text(canvas,status.take(58),dp(20f),dp(70f),12f)
        controls.forEach { control ->
            val x=PositionMath.denormalize(control.x,width)
            val y=PositionMath.denormalize(control.y,height)
            val radius=(control.size*min(width,height)).coerceIn(dp(18f),dp(70f))
            brush.color=if (selected?.id==control.id) 0xAA31E6F4.toInt() else 0xAA6D3EE8.toInt()
            canvas.drawCircle(x,y,radius,brush)
            brush.color=Color.WHITE
            brush.style=Paint.Style.STROKE; brush.strokeWidth=dp(2f)
            canvas.drawCircle(x,y,radius,brush)
            brush.style=Paint.Style.FILL
            val label=control.keyLabel.take(9)
            brush.textSize=dp(12f)
            canvas.drawText(label,x-brush.measureText(label)/2f,y+dp(4f),brush)
        }
        val s=selected
        if(s != null) {
            brush.color=0xEF1B1536.toInt()
            canvas.drawRoundRect(RectF(dp(8f),height-dp(90f),width-dp(8f),height-dp(8f)),dp(16f),dp(16f),brush)
            text(canvas,"SELECIONADO: ${s.keyLabel}",dp(17f),height-dp(56f),13f)
            text(canvas,"MENOR −",dp(18f),height-dp(24f),14f,0xFF57DEFF.toInt())
            text(canvas,"MAIOR +",width*0.43f,height-dp(24f),14f,0xFF57DEFF.toInt())
            text(canvas,"APAGAR",width-dp(85f),height-dp(24f),14f,0xFFFF7B99.toInt())
        }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x=e.x; val y=e.y
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (y>dp(8f) && y<dp(58f) && x>width-dp(105f)) { onClose();return true }
                val s=selected
                if (s!=null && y>height-dp(93f)) {
                    when {
                        x<width*0.33f -> { val c=s.copy(size=(s.size-0.012f).coerceAtLeast(0.035f));selected=c;onResize(c) }
                        x<width*0.73f -> { val c=s.copy(size=(s.size+0.012f).coerceAtMost(0.22f));selected=c;onResize(c) }
                        else -> {onDelete(s);selected=null}
                    }
                    invalidate();return true
                }
                selected=controls.reversed().firstOrNull { c ->
                    hypot(x-PositionMath.denormalize(c.x,width),y-PositionMath.denormalize(c.y,height))
                        <=(c.size*min(width,height)).coerceAtLeast(dp(22f))
                }
                dragging=selected!=null
                invalidate();return true
            }
            MotionEvent.ACTION_MOVE -> {
                if(dragging) selected?.let { c ->
                    selected=c.copy(x=PositionMath.normalize(x,width),y=PositionMath.normalize(y,height))
                    controls=controls.map { if(it.id==c.id) selected!! else it }
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if(dragging) { selected?.let(onMove);dragging=false;return true }
                if(y>dp(95f) && y<height-dp(98f)) {
                    if(doubleTap.acceptTap(System.currentTimeMillis(),x,y,true,dp(55f))) {
                        onCreate(PositionMath.normalize(x,width),PositionMath.normalize(y,height))
                    }
                }
                return true
            }
        }
        return true
    }
}
