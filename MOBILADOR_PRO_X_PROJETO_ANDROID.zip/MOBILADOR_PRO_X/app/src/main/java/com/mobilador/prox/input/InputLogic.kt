package com.mobilador.prox.input

import kotlin.math.abs
import kotlin.math.sign

// Pure logic that can be unit tested without Android hardware.
class KeyStateMachine {
    private val held = mutableSetOf<Int>()
    enum class Result { PRESS, RELEASE, IGNORED }
    fun onKey(key: Int, down: Boolean, repeat: Int = 0): Result {
        if (down) return if (repeat == 0 && held.add(key)) Result.PRESS else Result.IGNORED
        return if (held.remove(key)) Result.RELEASE else Result.IGNORED
    }
    fun clear(): Set<Int> = held.toSet().also { held.clear() }
    fun isHeld(key: Int) = key in held
}
object PositionMath {
    fun normalize(px: Float, dimension: Float) = if (dimension <= 0f) 0.5f else (px / dimension).coerceIn(0.0f, 1.0f)
    fun denormalize(frac: Float, dimension: Int) = frac.coerceIn(0f,1f) * dimension
}
class AimProcessor {
    private var previousX = 0f
    private var previousY = 0f
    fun reset() { previousX = 0f; previousY = 0f }
    fun move(dx: Float, dy: Float, x: Int, y: Int, acceleration: Int, smoothing: Int, deadzone: Int, invertY: Boolean): Pair<Float,Float> {
        fun transform(d: Float, sensitivity: Int): Float {
            if (abs(d) < deadzone * 0.12f) return 0f
            return sign(d) * abs(d) * (sensitivity / 100f) * (1f + acceleration / 100f * (abs(d) / 100f).coerceAtMost(3f))
        }
        val tx = transform(dx,x)
        val ty = transform(if (invertY) -dy else dy,y)
        val weight = 1f - (smoothing.coerceIn(0,100) * 0.008f)
        previousX += (tx - previousX) * weight
        previousY += (ty - previousY) * weight
        return previousX to previousY
    }
}

/** Double-tap detector is never active outside an explicit editor. Hover/move do not call this. */
class EditorDoubleTap {
    private var time=0L
    private var lastX=0f
    private var lastY=0f
    fun acceptTap(t: Long,x:Float,y:Float,editorEnabled:Boolean,maxDistance:Float):Boolean {
        if(!editorEnabled) { time=0;return false }
        val matched = time>0 && t-time in 1..350 &&
            kotlin.math.hypot(x-lastX,y-lastY)<maxDistance
        time=if(matched) 0 else t
        lastX=x;lastY=y
        return matched
    }
}
