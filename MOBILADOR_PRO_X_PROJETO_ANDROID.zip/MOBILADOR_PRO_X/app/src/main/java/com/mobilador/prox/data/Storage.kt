package com.mobilador.prox.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first
import java.util.UUID

@Entity(tableName = "profiles")
data class Profile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val gamePackage: String = "com.dts.freefireth", // informational only; no package inspection
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "controls", foreignKeys = [ForeignKey(entity = Profile::class, parentColumns = ["id"], childColumns = ["profileId"], onDelete = ForeignKey.CASCADE)], indices = [Index("profileId")])
data class Control(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val keyCode: Int,
    val keyLabel: String,
    val x: Float,  // normalized 0..1
    val y: Float,
    val size: Float = 0.09f,
    val isHold: Boolean = true
)

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles ORDER BY createdAt ASC") fun observeProfiles(): Flow<List<Profile>>
    @Query("SELECT * FROM controls WHERE profileId = :profileId ORDER BY id ASC") fun observeControls(profileId: Long): Flow<List<Control>>
    @Query("SELECT * FROM controls WHERE profileId = :profileId ORDER BY id ASC") suspend fun getControls(profileId: Long): List<Control>
    @Insert suspend fun addProfile(profile: Profile): Long
    @Insert suspend fun addControl(control: Control): Long
    @Update suspend fun updateControl(control: Control)
    @Query("DELETE FROM controls WHERE id = :id") suspend fun deleteControl(id: Long)
    @Query("DELETE FROM profiles WHERE id = :id") suspend fun deleteProfile(id: Long)
}

@Database(entities = [Profile::class, Control::class], version = 1, exportSchema = true)
abstract class MapperDb: RoomDatabase() {
    abstract fun dao(): ProfileDao
    companion object {
        @Volatile private var instance: MapperDb? = null
        fun get(context: Context) = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, MapperDb::class.java, "mobilador.sqlite").build().also { instance = it }
        }
    }
}

private val Context.prefs by preferencesDataStore("mobilador_settings")
data class Settings(
    val activeProfile: Long = 0,
    val sensitivityX: Int = 100,
    val sensitivityY: Int = 100,
    val cursorSpeed: Int = 100,
    val smoothing: Int = 0,
    val acceleration: Int = 0,
    val deadzone: Int = 0,
    val invertY: Boolean = false,
    val suspendKey: Int = android.view.KeyEvent.KEYCODE_CTRL_LEFT,
    val installId: String = ""
)
class SettingsStore(private val context: Context) {
    private object Keys {
        val active = longPreferencesKey("active_profile")
        val x = intPreferencesKey("x")
        val y = intPreferencesKey("y")
        val speed = intPreferencesKey("cursor_speed")
        val smoothing = intPreferencesKey("smoothing")
        val acceleration = intPreferencesKey("acceleration")
        val deadzone = intPreferencesKey("deadzone")
        val invertY = booleanPreferencesKey("invert_y")
        val suspendKey = intPreferencesKey("suspend_key")
        val installId = stringPreferencesKey("install_id")
    }
    val flow: Flow<Settings> = context.prefs.data.map { p ->
        Settings(p[Keys.active] ?: 0L, p[Keys.x] ?: 100, p[Keys.y] ?: 100,
            p[Keys.speed] ?: 100, p[Keys.smoothing] ?: 0, p[Keys.acceleration] ?: 0,
            p[Keys.deadzone] ?: 0, p[Keys.invertY] ?: false,
            p[Keys.suspendKey] ?: android.view.KeyEvent.KEYCODE_CTRL_LEFT,
            p[Keys.installId] ?: "")
    }
    suspend fun ensureInstallId(): String {
        val existing = context.prefs.data.map { it[Keys.installId] }.first()
        if (existing != null) return existing
        val id = UUID.randomUUID().toString()
        context.prefs.edit { it[Keys.installId] = id }
        return id
    }
    suspend fun setActive(id: Long) { context.prefs.edit { it[Keys.active] = id } }
    suspend fun setX(v: Int) { context.prefs.edit { it[Keys.x] = v.coerceIn(1, 200) } }
    suspend fun setY(v: Int) { context.prefs.edit { it[Keys.y] = v.coerceIn(1, 200) } }
    suspend fun setSpeed(v: Int) { context.prefs.edit { it[Keys.speed] = v.coerceIn(10, 200) } }
    suspend fun setSmoothing(v: Int) { context.prefs.edit { it[Keys.smoothing] = v.coerceIn(0, 100) } }
    suspend fun setAcceleration(v: Int) { context.prefs.edit { it[Keys.acceleration] = v.coerceIn(0, 100) } }
    suspend fun setDeadzone(v: Int) { context.prefs.edit { it[Keys.deadzone] = v.coerceIn(0, 40) } }
    suspend fun setInvertY(v: Boolean) { context.prefs.edit { it[Keys.invertY] = v } }
    suspend fun setSuspendKey(v: Int) { context.prefs.edit { it[Keys.suspendKey] = v } }
}
