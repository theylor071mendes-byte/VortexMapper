package com.mobilador.prox.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.mobilador.prox.data.Control
import com.mobilador.prox.input.PositionMath

/**
 * Uses official AccessibilityService gesture continuation for held keys.
 * System gesture dispatch is asynchronous and can cancel physical touch gestures.
 * No synthetic gestures are sent until the foreground package is allowed.
 */
class TouchGestureEngine(private val service: AccessibilityService) {
    private val handler = Handler(Looper.getMainLooper())
    private val pressed = LinkedHashMap<Int, Control>()
    private val previous = LinkedHashMap<Int, GestureDescription.StrokeDescription>()
    private val taps = ArrayDeque<Control>()
    private var working = false
    private var width = 1
    private var height = 1
    var allowed: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                if (!value) stop()
            }
        }

    fun screenDimensions(w: Int, h: Int) { width = w.coerceAtLeast(1); height = h.coerceAtLeast(1) }
    fun down(control: Control) {
        if (!allowed) return
        if (control.isHold) pressed[control.keyCode] = control
        else taps.addLast(control)
        runNext()
    }
    fun up(keyCode: Int) { pressed.remove(keyCode); runNext() }
    fun stop() {
        pressed.clear(); taps.clear()
        // Existing continued strokes are finalized after the in-flight callback.
        runNext()
    }
    private fun path(c: Control): Path = Path().apply {
        moveTo(PositionMath.denormalize(c.x,width), PositionMath.denormalize(c.y,height))
    }
    private fun runNext() {
        if (working) return
        if (previous.isEmpty() && pressed.isEmpty() && taps.isEmpty()) return
        val builder = GestureDescription.Builder()
        val next = LinkedHashMap<Int, GestureDescription.StrokeDescription>()
        try {
            // Include every continuing touch in the same gesture, so a new key doesn't
            // implicitly cancel held keys. Release produces a terminating continuation.
            for ((key, stroke) in previous) {
                val stillDown = pressed.containsKey(key) && allowed
                val duration = if (stillDown) 40L else 1L
                val cont = stroke.continueStroke(Path().apply {
                    val c = pressed[key]
                    if (c != null) moveTo(PositionMath.denormalize(c.x,width),PositionMath.denormalize(c.y,height))
                    else {
                        // Strokes remember their original coordinate; keep previous path here.
                        val old = lastLocations[key]
                        moveTo(old?.first ?: width/2f, old?.second ?: height/2f)
                    }
                }, 0L, duration, stillDown)
                builder.addStroke(cont)
                if (stillDown) next[key] = cont else lastLocations.remove(key)
            }
            for ((key, c) in pressed) if (!previous.containsKey(key)) {
                val stroke = GestureDescription.StrokeDescription(path(c),0L,40L,true)
                builder.addStroke(stroke); next[key] = stroke
                lastLocations[key] = PositionMath.denormalize(c.x,width) to PositionMath.denormalize(c.y,height)
            }
            // Single-shot keys: one tap per physical keydown, no repeated clicks.
            while (taps.isNotEmpty()) {
                val c = taps.removeFirst()
                builder.addStroke(GestureDescription.StrokeDescription(path(c),0L,40L,false))
            }
            previous.clear(); previous.putAll(next)
            working = true
            val accepted = service.dispatchGesture(builder.build(), object: AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    working = false
                    runNext()
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    working = false
                    previous.clear(); lastLocations.clear()
                    // Don't aggressively retry: another service or the user's touch may own the screen.
                    pressed.clear(); taps.clear()
                }
            }, handler)
            if (!accepted) { working = false; previous.clear(); lastLocations.clear(); pressed.clear() }
        } catch (ex: Exception) {
            Log.w("MobiladorTouch", "Gesture dispatch not supported: ${ex.message}")
            working = false; previous.clear(); lastLocations.clear(); pressed.clear(); taps.clear()
        }
    }
    private val lastLocations = mutableMapOf<Int, Pair<Float,Float>>()
}
