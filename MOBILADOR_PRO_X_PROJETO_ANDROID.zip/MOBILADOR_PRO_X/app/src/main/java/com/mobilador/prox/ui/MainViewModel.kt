package com.mobilador.prox.ui

import android.app.Application
import android.hardware.input.InputManager
import android.view.InputDevice
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mobilador.prox.billing.PlayPremium
import com.mobilador.prox.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = MapperDb.get(app).dao()
    private val settingsStore = SettingsStore(app)
    val settings = settingsStore.flow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Settings())
    val profiles = db.observeProfiles().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val controls = settings.flatMapLatest { s ->
        if(s.activeProfile>0) db.observeControls(s.activeProfile) else flowOf(emptyList())
    }.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val premium = PlayPremium(app,viewModelScope)
    val devices=MutableStateFlow("Nenhum teclado/mouse externo detectado")
    val notice=MutableStateFlow("")
    init {
        viewModelScope.launch {
            if(db.observeProfiles().first().isEmpty()) {
                val id=db.addProfile(Profile(name="Free Fire",gamePackage="com.dts.freefireth"))
                settingsStore.setActive(id)
            }
            settingsStore.ensureInstallId()
        }
        refreshDevices()
    }
    fun refreshDevices() {
        val text=InputDevice.getDeviceIds().mapNotNull { InputDevice.getDevice(it) }
            .filter { (it.sources and InputDevice.SOURCE_KEYBOARD)==InputDevice.SOURCE_KEYBOARD ||
                      (it.sources and InputDevice.SOURCE_MOUSE)==InputDevice.SOURCE_MOUSE }
            .filter { !it.isVirtual }
            .distinctBy { it.id }
            .joinToString(" • ") { d ->
                val kinds=listOfNotNull(
                    if(d.supportsSource(InputDevice.SOURCE_MOUSE)) "mouse" else null,
                    if(d.supportsSource(InputDevice.SOURCE_KEYBOARD)) "teclado" else null)
                "${d.name} (${kinds.joinToString("/")})"
            }
        devices.value=text.ifBlank {"Nenhum teclado/mouse físico detectado"}
    }
    fun active(id:Long) {viewModelScope.launch {settingsStore.setActive(id)}}
    fun createProfile(name:String,pkg:String) = viewModelScope.launch {
        if (name.isBlank() || pkg.isBlank()) {notice.value="Informe nome e pacote do jogo.";return@launch}
        if(!premium.status.value.active && db.observeProfiles().first().size>=2) {
            notice.value="O plano gratuito permite dois perfis.";return@launch
        }
        val id=db.addProfile(Profile(name=name.take(40),gamePackage=pkg.trim()))
        settingsStore.setActive(id)
        notice.value="Perfil criado"
    }
    fun deleteProfile(id:Long) =viewModelScope.launch {
        val current=db.observeProfiles().first()
        if(current.size<=1) {notice.value="Mantenha pelo menos um perfil.";return@launch}
        db.deleteProfile(id)
        if(settings.value.activeProfile==id) settingsStore.setActive(current.first { it.id!=id }.id)
    }
    fun addControl(x:Float,y:Float,key:Int,label:String) =viewModelScope.launch {
        val id=settings.value.activeProfile
        if(id!=0L) db.addControl(Control(profileId=id,keyCode=key,keyLabel=label,
            x=x.coerceIn(0f,1f),y=y.coerceIn(0f,1f)))
    }
    fun update(c:Control) =viewModelScope.launch { db.updateControl(c.copy(x=c.x.coerceIn(0f,1f),y=c.y.coerceIn(0f,1f))) }
    fun delete(c:Control)=viewModelScope.launch {db.deleteControl(c.id)}
    fun setX(v:Int)=viewModelScope.launch {settingsStore.setX(v)}
    fun setY(v:Int)=viewModelScope.launch {settingsStore.setY(v)}
    fun setSpeed(v:Int)=viewModelScope.launch {settingsStore.setSpeed(v)}
    fun setSmooth(v:Int)=viewModelScope.launch {settingsStore.setSmoothing(v)}
    fun setAcceleration(v:Int)=viewModelScope.launch {settingsStore.setAcceleration(v)}
    fun setDeadzone(v:Int)=viewModelScope.launch {settingsStore.setDeadzone(v)}
    fun setInvert(v:Boolean)=viewModelScope.launch {settingsStore.setInvertY(v)}
    fun setSuspendKey(v:Int)=viewModelScope.launch {settingsStore.setSuspendKey(v)}

    suspend fun exportJson():String {
        require(premium.status.value.active) {"Importação/exportação requer Premium validado"}
        val p=profiles.value.first { it.id==settings.value.activeProfile }
        val a=JSONArray()
        db.getControls(p.id).forEach { c -> a.put(JSONObject()
            .put("keyCode",c.keyCode).put("keyLabel",c.keyLabel).put("x",c.x.toDouble())
            .put("y",c.y.toDouble()).put("size",c.size.toDouble()).put("hold",c.isHold)) }
        return JSONObject().put("format",1).put("name",p.name)
            .put("gamePackage",p.gamePackage).put("controls",a).toString(2)
    }
    fun importJson(json:String) =viewModelScope.launch {
        if (!premium.status.value.active) {notice.value="Acesso Premium não validado.";return@launch}
        try {
            val o=JSONObject(json)
            require(o.getInt("format")==1)
            val a=o.getJSONArray("controls")
            require(a.length()<=200)
            val name=o.getString("name").take(40)
            val pkg=o.getString("gamePackage").take(150)
            require(name.isNotBlank() && Regex("[A-Za-z0-9_.]+$").matches(pkg))
            val id=db.addProfile(Profile(name=name,gamePackage=pkg))
            for(i in 0 until a.length()) {
                val c=a.getJSONObject(i)
                db.addControl(Control(profileId=id,keyCode=c.getInt("keyCode").coerceIn(1,400),
                    keyLabel=c.getString("keyLabel").take(30),
                    x=c.getDouble("x").toFloat().coerceIn(0f,1f),
                    y=c.getDouble("y").toFloat().coerceIn(0f,1f),
                    size=c.getDouble("size").toFloat().coerceIn(.035f,.22f),
                    isHold=c.getBoolean("hold")))
            }
            settingsStore.setActive(id);notice.value="Perfil importado"
        } catch(e:Exception) {notice.value="JSON inválido: ${e.message}"}
    }
    override fun onCleared() {premium.close();super.onCleared()}
}
