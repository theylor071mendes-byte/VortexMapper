import {test} from 'node:test';
import assert from 'node:assert/strict';
import {isActiveSubscription} from './entitlement.js';
const product='mobilador_premium_monthly';
const make = (state,productId=product,expiry='2035-01-01T00:00:00Z')=>({subscriptionState:state,lineItems:[{productId,expiryTime:expiry}]});
test('active subscription unlocks after actual verification',()=>assert.equal(isActiveSubscription(make('SUBSCRIPTION_STATE_ACTIVE'),product,Date.now()),true));
test('pending subscriptions never unlock',()=>assert.equal(isActiveSubscription(make('SUBSCRIPTION_STATE_PENDING'),product),false));
test('expired subscriptions never unlock',()=>assert.equal(isActiveSubscription(make('SUBSCRIPTION_STATE_ACTIVE',product,'2020-01-01T00:00:00Z'),product),false));
test('mismatched product never unlocks',()=>assert.equal(isActiveSubscription(make('SUBSCRIPTION_STATE_ACTIVE','wrong'),product),false));
