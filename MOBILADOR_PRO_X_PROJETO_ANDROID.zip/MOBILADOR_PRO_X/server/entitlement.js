export function isActiveSubscription(subscription, productId, now = Date.now()) {
  const validStates = new Set([
    'SUBSCRIPTION_STATE_ACTIVE',
    'SUBSCRIPTION_STATE_IN_GRACE_PERIOD',
    'SUBSCRIPTION_STATE_CANCELED'
  ]);
  if (!validStates.has(subscription?.subscriptionState)) return false;
  return !!subscription?.lineItems?.some(item => item.productId === productId &&
    Number.isFinite(Date.parse(item.expiryTime)) && Date.parse(item.expiryTime) > now);
}
