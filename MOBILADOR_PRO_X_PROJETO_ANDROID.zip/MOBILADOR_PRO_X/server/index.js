import express from 'express';
import helmet from 'helmet';
import Database from 'better-sqlite3';
import {google} from 'googleapis';
import crypto from 'node:crypto';
import {isActiveSubscription} from './entitlement.js';

// Install behind TLS termination (HTTPS reverse proxy); never expose plain HTTP directly.
const PKG = process.env.ANDROID_PACKAGE || 'com.mobilador.prox';
const PRODUCT = process.env.SUBSCRIPTION_PRODUCT || 'mobilador_premium_monthly';
const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(express.json({limit:'12kb'}));
const db = new Database(process.env.DB_FILE || './entitlements.sqlite');
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS purchases (
  token_hash TEXT PRIMARY KEY, installation TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)`);
const find = db.prepare('SELECT installation FROM purchases WHERE token_hash = ?');
const insert = db.prepare('INSERT OR IGNORE INTO purchases(token_hash,installation) VALUES(?,?)');
const auth = new google.auth.GoogleAuth({scopes:['https://www.googleapis.com/auth/androidpublisher']});
const publisher = google.androidpublisher({version:'v3',auth});
const limits = new Map();
app.post('/v1/verify', async (req,res) => {
  res.setHeader('Cache-Control','no-store');
  const {purchaseToken,installId} = req.body || {};
  if(typeof purchaseToken !== 'string' || purchaseToken.length < 20 || purchaseToken.length > 4096 ||
     typeof installId !== 'string' || !/^[0-9a-f-]{36}$/i.test(installId)) return res.status(400).json({active:false});
  // Per-installation rate limiting; use Redis / load balancer limits for a multi-node rollout.
  const now=Date.now(), prev=limits.get(installId) || {at:now,n:0};
  if(now-prev.at>60000) {prev.at=now;prev.n=0;}
  prev.n++;
  limits.set(installId,prev);
  if(prev.n>30) return res.status(429).json({active:false});
  const digest=crypto.createHash('sha256').update(purchaseToken).digest('hex');
  const installationHash=crypto.createHash('sha256').update(installId).digest('hex');
  try {
    const bound=find.get(digest);
    if(bound && bound.installation!==installationHash) return res.status(403).json({active:false});
    const {data} = await publisher.purchases.subscriptionsv2.get({packageName:PKG,token:purchaseToken});
    const active=isActiveSubscription(data,PRODUCT);
    if(!active) return res.json({active:false});
    insert.run(digest,installationHash);
    // If a new installation raced another, deny both until binding is resolved.
    if(find.get(digest)?.installation !== installationHash) return res.status(403).json({active:false});
    return res.json({active:true});
  } catch(err) {
    console.error('Google Play purchase validation failed:',err?.code || err?.message);
    return res.status(503).json({active:false});
  }
});
app.get('/health',(_req,res)=>res.json({ok:true}));
app.listen(Number(process.env.PORT || 8080),'127.0.0.1',()=>console.log('Premium verifier listening on localhost'));
