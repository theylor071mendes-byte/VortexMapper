package org.gradle.wrapper;

import java.io.*;
import java.net.URI;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/**
 * Original minimal launcher to fetch the OFFICIAL Gradle wrapper JAR with pinned SHA-256.
 * The launcher is not the standard Gradle wrapper JAR; it installs that JAR on first run.
 * This project was produced in a build environment without access to Maven/Gradle hosts.
 */
public final class GradleWrapperMain {
    private static final String OFFICIAL_URL="https://services.gradle.org/distributions/gradle-8.7-wrapper.jar";
    private static final String SHA256="cb0da6751c2b753a16ac168bb354870ebb1e162e9083f116729cec9c781156b8";
    public static void main(String[] args) throws Exception {
        Path root=Path.of(System.getProperty("user.dir"));
        Path dir=root.resolve("gradle/wrapper");
        Files.createDirectories(dir);
        Path official=dir.resolve("gradle-wrapper-real.jar");
        if (!Files.exists(official) || !sha(official).equals(SHA256)) {
            System.out.println("Obtendo wrapper oficial Gradle 8.7 (SHA-256 verificado)...");
            Path temporary=Files.createTempFile(dir,"wrapper-",".tmp");
            try {
                try(InputStream in=URI.create(OFFICIAL_URL).toURL().openStream()) {
                    Files.copy(in,temporary,StandardCopyOption.REPLACE_EXISTING);
                }
                if(!sha(temporary).equals(SHA256)) throw new SecurityException("Checksum do wrapper oficial incorreto!");
                Files.move(temporary,official,StandardCopyOption.REPLACE_EXISTING);
            } finally {Files.deleteIfExists(temporary);}
        }
        Path prop=dir.resolve("gradle-wrapper.properties");
        Path alternate=dir.resolve("gradle-wrapper-real.properties");
        Files.copy(prop,alternate,StandardCopyOption.REPLACE_EXISTING);
        ArrayList<String> cmd=new ArrayList<>();
        cmd.add(Path.of(System.getProperty("java.home"),"bin",System.getProperty("os.name").startsWith("Windows")?"java.exe":"java").toString());
        cmd.add("-cp");cmd.add(official.toString());cmd.add("org.gradle.wrapper.GradleWrapperMain");
        cmd.addAll(Arrays.asList(args));
        ProcessBuilder builder=new ProcessBuilder(cmd).directory(root.toFile()).inheritIO();
        int result=builder.start().waitFor();
        System.exit(result);
    }
    private static String sha(Path file) throws Exception {
        MessageDigest digest=MessageDigest.getInstance("SHA-256");
        try(InputStream in=Files.newInputStream(file)) {
            byte[] buffer=new byte[8192];int n;
            while((n=in.read(buffer))!=-1) digest.update(buffer,0,n);
        }
        return HexFormat.of().formatHex(digest.digest());
    }
}
